
fn read_guest_str(caller: &mut Caller<'_, DmodHostState>, ptr: i32, len: i32) -> Option<String> {
    if ptr <= 0 || len <= 0 || len > 65536 {
        return None;
    }
    let Some(wasmi::Extern::Memory(mem)) = caller.get_export("memory") else {
        return None;
    };
    let mut buf = vec![0u8; len as usize];
    mem.read(&*caller, ptr as usize, &mut buf).ok()?;
    String::from_utf8(buf).ok()
}
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use wasmi::{Caller, Engine, Extern, Instance, Linker, Module, Store};

#[derive(Clone, Debug, serde::Deserialize, serde::Serialize)]
pub struct DmodManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    #[serde(default)]
    pub author: Option<String>,
    #[serde(default)]
    pub description: Option<String>,
    #[serde(default = "default_entry")]
    pub entry: String,
    #[serde(default)]
    pub api_version: Option<u32>,
    #[serde(default)]
    pub depends_on: Vec<String>,
    #[serde(default)]
    pub load_after: Vec<String>,
}

fn default_entry() -> String {
    "mod.wasm".to_string()
}

#[derive(Clone, Debug, Default)]
pub struct DmodHudRect {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub argb: u32,
}

#[derive(Clone, Debug, Default)]
pub struct DmodHudText {
    pub x: f32,
    pub y: f32,
    pub text: String,
    pub argb: u32,
    pub scale: f32,
}

#[derive(Clone, Debug)]
pub struct DmodSettingButton {
    pub id: i32,
    pub mod_id: String,
    pub key: String,
    pub label: String,
}

#[derive(Clone, Debug)]
pub struct DmodHudSprite {
    pub name: String,
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub u1: f32,
    pub v1: f32,
    pub u2: f32,
    pub v2: f32,
    pub argb: u32,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct DmodFoodInfo {
    pub is_food: bool,
    pub nutrition: u32,
    pub saturation: f32,
    pub can_always_eat: bool,
    pub is_rotten: bool,
    pub regen_hp: f32,
}

#[derive(Clone, Copy, Debug)]
pub struct DmodWorldLine {
    pub a: [f64; 3],
    pub b: [f64; 3],
    pub rgba: [f32; 4],
}

#[derive(Clone, Debug, Default)]
pub struct DmodSlotState {
    pub slot_id: i32,
    pub item_id: i32,
    pub count: i32,
    pub max_stack: i32,
    pub is_result: bool,
    pub is_player_inv: bool,
    pub item_name: String,
}

#[derive(Clone, Copy, Debug)]
pub struct DmodContainerOp {
    pub slot: i32,
    pub button: i32,
    pub action: i32,
}

static DMOD_FLUID_FLOW_BLOCKED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
static DMOD_FIRE_SPREAD_BLOCKED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
static DMOD_BLOCK_CHANGES: std::sync::OnceLock<std::sync::Mutex<Vec<([i32; 3], u32, u32)>>> = std::sync::OnceLock::new();
static DMOD_FLUID_CHANGES: std::sync::OnceLock<std::sync::Mutex<Vec<([i32; 3], i32, i32)>>> = std::sync::OnceLock::new();

pub fn push_world_block_change(pos: [i32; 3], old_id: u32, new_id: u32) {
    let q = DMOD_BLOCK_CHANGES.get_or_init(|| std::sync::Mutex::new(Vec::new()));
    if let Ok(mut g) = q.lock() {
        if g.len() < 256 { g.push((pos, old_id, new_id)); }
    }
}

pub fn push_world_fluid_change(pos: [i32; 3], from_lvl: i32, to_lvl: i32) {
    let q = DMOD_FLUID_CHANGES.get_or_init(|| std::sync::Mutex::new(Vec::new()));
    if let Ok(mut g) = q.lock() {
        if g.len() < 256 { g.push((pos, from_lvl, to_lvl)); }
    }
}

pub fn is_fluid_flow_blocked() -> bool {
    DMOD_FLUID_FLOW_BLOCKED.load(std::sync::atomic::Ordering::Relaxed)
}

pub fn is_fire_spread_blocked() -> bool {
    DMOD_FIRE_SPREAD_BLOCKED.load(std::sync::atomic::Ordering::Relaxed)
}

#[derive(Clone, Debug)]
pub struct DmodWorldText {
    pub text: String,
    pub pos: [f64; 3],
    pub rot: [f32; 2],
    pub scale: f32,
    pub color: u32,
    pub glowing: bool,
}

#[derive(Clone, Debug)]
pub struct DmodWorldCuboid {
    pub sprite: String,
    pub pos: [f64; 3],
    pub size: [f32; 3],
    pub rot: [f32; 3],
    pub tint: u32,
}

pub struct DmodWorldModel {
    pub model: String,
    pub pos: [f64; 3],
    pub rot: [f32; 3],
    pub scale: [f32; 3],
    pub tint: u32,
}

#[derive(Clone, Debug)]
pub struct DmodScreenButton {
    pub id: i32,
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub label: String,
}

pub struct DmodHostState {
    pub mod_id: String,
    pub fps: i32,
    pub window_width: i32,
    pub window_height: i32,
    pub in_world: bool,
    pub screen_id: i32,
    pub world_time: i64,
    pub player_flags: i32,
    pub player_hp: f32,
    pub player_max_hp: f32,
    pub player_pos: [f64; 3],
    pub player_vel: [f64; 3],
    pub player_rot: [f32; 2],
    pub mouse_delta: [f32; 2],
    pub keys_held: HashSet<i32>,
    pub mouse_buttons_held: HashSet<i32>,

    pub camera_yaw_offset: f32,
    pub camera_pitch_offset: f32,
    pub camera_roll_deg: f32,
    pub camera_pos_offset: [f32; 3],
    pub fov_scale: f32,
    pub hud_rects: Vec<DmodHudRect>,
    pub hud_sprites: Vec<DmodHudSprite>,
    pub hud_texts: Vec<DmodHudText>,
    pub player_saturation: f32,
    pub player_exhaustion: f32,
    pub player_absorption: f32,
    pub tick_count: i64,
    pub is_hardcore: bool,
    pub player_status_mask: i32,
    pub player_armor: i32,
    pub mounted_with_health: bool,
    pub held_food: [DmodFoodInfo; 2],
    pub slot_foods: Vec<DmodFoodInfo>,
    pub debug_lines: Vec<String>,
    pub world_lines: Vec<DmodWorldLine>,
    pub chat_messages: Vec<String>,
    pub setting_buttons: Vec<DmodSettingButton>,
    pub next_button_id: i32,
    pub sound_clicks: u32,
    pub pending_sounds: Vec<(String, f32, f32)>,
    pub pending_stop_sounds: bool,
    pub kv_file: Option<PathBuf>,
    pub player_xp_level: i32,
    pub player_xp_progress: f32,

    pub motion_blur_enabled: bool,
    pub motion_blur_strength: f32,
    pub fog_density: f32,
    pub fog_color: [f32; 4],
    pub sky_override: Option<[f32; 3]>,
    pub vignette: [f32; 4],
    pub gamma: f32,
    pub saturation: f32,
    pub grayscale: bool,
    pub fullbright: bool,
    pub player_hunger: i32,
    pub player_air: i32,
    pub player_gamemode: i32,
    pub selected_slot: i32,
    pub dimension: i32,
    pub light_level: i32,
    pub particle_density: f32,
    pub render_distance: i32,
    pub culling_flags: i32,
    pub fps_limit: i32,
    pub is_multiplayer: bool,
    pub kv_store: HashMap<String, String>,
    pub container_type: i32,
    pub container_slot_count: i32,
    pub hovered_slot: i32,
    pub cursor_x: f32,
    pub cursor_y: f32,
    pub shift_down: bool,
    pub ctrl_down: bool,
    pub alt_down: bool,
    pub carried_item_id: i32,
    pub carried_item_count: i32,
    pub carried_max_stack: i32,
    pub carried_item_name: String,
    pub slots: Vec<DmodSlotState>,
    pub pending_container_ops: Vec<DmodContainerOp>,
    pub mouse_tweaks_flags: u32,
    pub targeted_block: [i32; 5],
    pub targeted_face: i32,
    pub targeted_block_name: String,
    pub targeted_entity_id: i32,
    pub targeted_entity_health: f32,
    pub targeted_entity_name: String,
    pub biome_name: String,
    pub sky_light: i32,
    pub block_light: i32,
    pub pending_chat_sends: Vec<String>,
    pub pending_velocity_add: Option<[f32; 3]>,
    pub pending_player_angles: Option<[f32; 2]>,
    pub pending_hotbar_slot: Option<i32>,
    pub pending_swing_arm: bool,
    pub subscribed_events: u32,
    pub custom_blocks: Vec<(String, f32, i32)>,
    pub custom_items: Vec<(String, i32)>,
    pub pending_payloads: Vec<(String, Vec<u8>)>,
    pub loaded_mod_ids: HashSet<String>,
    pub difficulty: i32,
    pub is_raining: bool,
    pub is_thundering: bool,
    pub gui_ticks: i32,
    pub world_was_in: bool,
    pub server_address: String,
    pub client_commands: Vec<String>,
    pub keybinds: Vec<(String, String, String, i32)>,
    pub tooltip_extra_lines: Vec<(String, u32)>,
    pub attachments: HashMap<String, String>,
    pub attachments_file: Option<PathBuf>,
    pub data_pack_files: Vec<(String, Vec<u8>)>,
    pub pending_particles: Vec<(String, [f64; 3], [f64; 3])>,
    pub world_models: Vec<DmodWorldModel>,
    pub screen_buttons: Vec<DmodScreenButton>,
    pub pending_world_commands: Vec<String>,
    pub pending_world_sounds: Vec<(String, [f64; 3], f32, f32)>,
    pub world_cuboids: Vec<DmodWorldCuboid>,
    pub local_blocks: HashMap<(i32, i32, i32), String>,
    pub nearby_entity_count: i32,
    pub nearest_entity: Option<(i32, [f64; 3], f32)>,
    pub world_texts: Vec<DmodWorldText>,
    pub keybinds_file: Option<PathBuf>,
    pub slot_components: HashMap<(i32, String), String>,
    pub resource_assets: HashMap<String, Vec<u8>>,
    pub creative_tabs: Vec<(String, String, String)>,
    pub creative_tab_items: HashMap<String, Vec<String>>,
    pub payload_channels: HashMap<String, i32>,
    pub pending_imc: Vec<(String, String, String)>,
    pub mod_versions: HashMap<String, String>,
}

impl Default for DmodHostState {
    fn default() -> Self {
        Self {
            mod_id: String::new(),
            fps: 60,
            window_width: 1920,
            window_height: 1080,
            in_world: false,
            screen_id: 0,
            world_time: 0,
            player_flags: 0,
            player_hp: 20.0,
            player_max_hp: 20.0,
            player_pos: [0.0; 3],
            player_vel: [0.0; 3],
            player_rot: [0.0; 2],
            mouse_delta: [0.0; 2],
            keys_held: HashSet::new(),
            mouse_buttons_held: HashSet::new(),
            camera_yaw_offset: 0.0,
            camera_pitch_offset: 0.0,
            camera_roll_deg: 0.0,
            camera_pos_offset: [0.0; 3],
            fov_scale: 1.0,
            hud_rects: Vec::new(),
            hud_sprites: Vec::new(),
            hud_texts: Vec::new(),
            player_saturation: 5.0,
            player_exhaustion: 0.0,
            player_absorption: 0.0,
            tick_count: 0,
            is_hardcore: false,
            player_status_mask: 0,
            player_armor: 0,
            mounted_with_health: false,
            held_food: [DmodFoodInfo::default(); 2],
            slot_foods: Vec::new(),
            debug_lines: Vec::new(),
            world_lines: Vec::new(),
            chat_messages: Vec::new(),
            setting_buttons: Vec::new(),
            next_button_id: 0,
            sound_clicks: 0,
            pending_sounds: Vec::new(),
            pending_stop_sounds: false,
            kv_file: None,
            player_xp_level: 0,
            player_xp_progress: 0.0,
            motion_blur_enabled: false,
            motion_blur_strength: 0.0,
            fog_density: 0.0,
            fog_color: [0.0; 4],
            sky_override: None,
            vignette: [0.0; 4],
            gamma: 1.0,
            saturation: 1.0,
            grayscale: false,
            fullbright: false,
            player_hunger: 20,
            player_air: 300,
            player_gamemode: 0,
            selected_slot: 0,
            dimension: 0,
            light_level: 15,
            particle_density: 1.0,
            render_distance: 0,
            culling_flags: 7,
            fps_limit: 0,
            is_multiplayer: false,
            kv_store: HashMap::new(),
            container_type: 0,
            container_slot_count: 0,
            hovered_slot: -1,
            cursor_x: 0.0,
            cursor_y: 0.0,
            shift_down: false,
            ctrl_down: false,
            alt_down: false,
            carried_item_id: 0,
            carried_item_count: 0,
            carried_max_stack: 64,
            carried_item_name: String::new(),
            slots: Vec::new(),
            pending_container_ops: Vec::new(),
            mouse_tweaks_flags: 0x0F,
            targeted_block: [0; 5],
            targeted_face: 0,
            targeted_block_name: String::new(),
            targeted_entity_id: -1,
            targeted_entity_health: 0.0,
            targeted_entity_name: String::new(),
            biome_name: String::from("minecraft:plains"),
            sky_light: 15,
            block_light: 0,
            pending_chat_sends: Vec::new(),
            pending_velocity_add: None,
            pending_player_angles: None,
            pending_hotbar_slot: None,
            pending_swing_arm: false,
            subscribed_events: 0,
            custom_blocks: Vec::new(),
            custom_items: Vec::new(),
            pending_payloads: Vec::new(),
            loaded_mod_ids: HashSet::new(),
            difficulty: 2,
            is_raining: false,
            is_thundering: false,
            gui_ticks: 0,
            world_was_in: false,
            server_address: String::new(),
            client_commands: Vec::new(),
            keybinds: Vec::new(),
            tooltip_extra_lines: Vec::new(),
            attachments: HashMap::new(),
            attachments_file: None,
            data_pack_files: Vec::new(),
            pending_particles: Vec::new(),
            world_models: Vec::new(),
            screen_buttons: Vec::new(),
            pending_world_commands: Vec::new(),
            pending_world_sounds: Vec::new(),
            world_cuboids: Vec::new(),
            local_blocks: HashMap::new(),
            nearby_entity_count: 0,
            nearest_entity: None,
            world_texts: Vec::new(),
            keybinds_file: None,
            slot_components: HashMap::new(),
            resource_assets: HashMap::new(),
            creative_tabs: Vec::new(),
            creative_tab_items: HashMap::new(),
            payload_channels: HashMap::new(),
            pending_imc: Vec::new(),
            mod_versions: HashMap::new(),
        }
    }
}

pub struct DmodInstance {
    pub manifest: DmodManifest,
    pub store: Store<DmodHostState>,
    pub instance: Instance,
    pub active: bool,
}

pub struct DmodManager {
    pub game_dir: PathBuf,
    pub instances: Vec<DmodInstance>,
    pub disabled_ids: HashSet<String>,
    pub installed_manifests: Vec<DmodManifest>,
    pub tick_count: i32,
    pub cached_debug_lines: Vec<String>,
    pub load_errors: HashMap<String, String>,
    pub camera_yaw_offset: f32,
    pub camera_pitch_offset: f32,
    pub camera_roll_deg: f32,
    pub camera_pos_offset: [f32; 3],
    pub fov_scale: f32,
    pub fog_density: f32,
    pub fog_color: [f32; 4],
    pub sky_override: Option<[f32; 3]>,
    pub vignette: [f32; 4],
    pub fullbright_override: bool,
    pub gamma_override: Option<f32>,
    pub last_container_hash: u64,
}

fn add_host_funcs(
    linker: &mut Linker<DmodHostState>,
    module_name: &str,
    variant_mask: u8,
) -> Result<(), wasmi::Error> {
    if (variant_mask & 1) == 0 {
        linker.func_wrap(
            module_name,
            "log",
            |caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| {
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut buf = vec![0u8; (len.max(0) as usize).min(4096)];
                    if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                        if let Ok(msg) = std::str::from_utf8(&buf) {
                            log::info!("[dmod:{}] {}", caller.data().mod_id, msg);
                        }
                    }
                }
                Ok(())
            },
        )?;
    } else {
        linker.func_wrap(
            module_name,
            "log",
            |caller: Caller<'_, DmodHostState>, _level: i32, ptr: i32, len: i32| {
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut buf = vec![0u8; (len.max(0) as usize).min(4096)];
                    if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                        if let Ok(msg) = std::str::from_utf8(&buf) {
                            log::info!("[dmod:{}] {}", caller.data().mod_id, msg);
                        }
                    }
                }
                Ok(())
            },
        )?;
    }

    linker.func_wrap(
        module_name,
        "log_level",
        |caller: Caller<'_, DmodHostState>, _level: i32, ptr: i32, len: i32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(4096)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    if let Ok(msg) = std::str::from_utf8(&buf) {
                        log::info!("[dmod:{}] {}", caller.data().mod_id, msg);
                    }
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(module_name, "get_api_version", |_caller: Caller<'_, DmodHostState>| -> i32 {
        5
    })?;

    linker.func_wrap(module_name, "get_fps", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().fps
    })?;

    linker.func_wrap(module_name, "get_frame_time_ms", |caller: Caller<'_, DmodHostState>| -> f32 {
        let fps = caller.data().fps.max(1) as f32;
        1000.0 / fps
    })?;

    linker.func_wrap(module_name, "get_time_ms", |_caller: Caller<'_, DmodHostState>| -> i64 {
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_millis() as i64)
    })?;

    linker.func_wrap(
        module_name,
        "get_window_size",
        |mut caller: Caller<'_, DmodHostState>, out_w: i32, out_h: i32| {
            let w = caller.data().window_width;
            let h = caller.data().window_height;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let _ = mem.write(&mut caller, out_w as usize, &w.to_le_bytes());
                let _ = mem.write(&mut caller, out_h as usize, &h.to_le_bytes());
            }
            Ok(())
        },
    )?;

    linker.func_wrap(module_name, "is_in_world", |caller: Caller<'_, DmodHostState>| -> i32 {
        if caller.data().in_world { 1 } else { 0 }
    })?;

    linker.func_wrap(module_name, "get_screen_id", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().screen_id
    })?;

    linker.func_wrap(module_name, "get_world_time", |caller: Caller<'_, DmodHostState>| -> i64 {
        caller.data().world_time
    })?;

    linker.func_wrap(module_name, "get_player_flags", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().player_flags
    })?;

    linker.func_wrap(
        module_name,
        "get_player_health",
        |mut caller: Caller<'_, DmodHostState>, out_hp: i32, out_max: i32| {
            let hp = caller.data().player_hp;
            let max_hp = caller.data().player_max_hp;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let _ = mem.write(&mut caller, out_hp as usize, &hp.to_le_bytes());
                let _ = mem.write(&mut caller, out_max as usize, &max_hp.to_le_bytes());
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_pos",
        |mut caller: Caller<'_, DmodHostState>, out_xyz: i32| {
            let pos = caller.data().player_pos;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 24];
                bytes[0..8].copy_from_slice(&pos[0].to_le_bytes());
                bytes[8..16].copy_from_slice(&pos[1].to_le_bytes());
                bytes[16..24].copy_from_slice(&pos[2].to_le_bytes());
                let _ = mem.write(&mut caller, out_xyz as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_vel",
        |mut caller: Caller<'_, DmodHostState>, out_xyz: i32| {
            let vel = caller.data().player_vel;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 24];
                bytes[0..8].copy_from_slice(&vel[0].to_le_bytes());
                bytes[8..16].copy_from_slice(&vel[1].to_le_bytes());
                bytes[16..24].copy_from_slice(&vel[2].to_le_bytes());
                let _ = mem.write(&mut caller, out_xyz as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_rot",
        |mut caller: Caller<'_, DmodHostState>, out_rot: i32| {
            let rot = caller.data().player_rot;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 8];
                bytes[0..4].copy_from_slice(&rot[0].to_le_bytes());
                bytes[4..8].copy_from_slice(&rot[1].to_le_bytes());
                let _ = mem.write(&mut caller, out_rot as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_mouse_delta",
        |mut caller: Caller<'_, DmodHostState>, out_xy: i32| {
            let d = caller.data().mouse_delta;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 8];
                bytes[0..4].copy_from_slice(&d[0].to_le_bytes());
                bytes[4..8].copy_from_slice(&d[1].to_le_bytes());
                let _ = mem.write(&mut caller, out_xy as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_key_down",
        |caller: Caller<'_, DmodHostState>, key: i32| -> i32 {
            if caller.data().keys_held.contains(&key) { 1 } else { 0 }
        },
    )?;

    if (variant_mask & 8) == 0 {
        linker.func_wrap(
            module_name,
            "set_camera_pose",
            |mut caller: Caller<'_, DmodHostState>, yaw: f32, pitch: f32, roll: f32| {
                caller.data_mut().camera_yaw_offset = yaw;
                caller.data_mut().camera_pitch_offset = pitch;
                caller.data_mut().camera_roll_deg = roll;
                Ok(())
            },
        )?;
    } else {
        linker.func_wrap(
            module_name,
            "set_camera_pose",
            |mut caller: Caller<'_, DmodHostState>,
             dx: f32,
             dy: f32,
             dz: f32,
             yaw: f32,
             pitch: f32,
             roll: f32| {
                caller.data_mut().camera_pos_offset = [dx, dy, dz];
                caller.data_mut().camera_yaw_offset = yaw;
                caller.data_mut().camera_pitch_offset = pitch;
                caller.data_mut().camera_roll_deg = roll;
                Ok(())
            },
        )?;
    }

    linker.func_wrap(
        module_name,
        "set_camera_pose_full",
        |mut caller: Caller<'_, DmodHostState>,
         dx: f32,
         dy: f32,
         dz: f32,
         yaw: f32,
         pitch: f32,
         roll: f32| {
            caller.data_mut().camera_pos_offset = [dx, dy, dz];
            caller.data_mut().camera_yaw_offset = yaw;
            caller.data_mut().camera_pitch_offset = pitch;
            caller.data_mut().camera_roll_deg = roll;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "add_camera_shake",
        |mut caller: Caller<'_, DmodHostState>, pitch: f32, yaw: f32, roll: f32| {
            caller.data_mut().camera_pitch_offset += pitch;
            caller.data_mut().camera_yaw_offset += yaw;
            caller.data_mut().camera_roll_deg += roll;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_fov_scale",
        |mut caller: Caller<'_, DmodHostState>, scale: f32| {
            caller.data_mut().fov_scale = scale.clamp(0.1, 3.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "hud_rect",
        |mut caller: Caller<'_, DmodHostState>, x: f32, y: f32, w: f32, h: f32, argb: i32| {
            if caller.data().hud_rects.len() < 512 {
                caller.data_mut().hud_rects.push(DmodHudRect {
                    x,
                    y,
                    w,
                    h,
                    argb: argb as u32,
                });
            }
            Ok(())
        },
    )?;

    if (variant_mask & 2) == 0 {
        linker.func_wrap(
            module_name,
            "hud_text",
            |mut caller: Caller<'_, DmodHostState>,
             x: f32,
             y: f32,
             ptr: i32,
             len: i32,
             argb: i32,
             scale: f32| {
                if ptr < 0 || len <= 0 {
                    return Ok(());
                }
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut buf = vec![0u8; (len as usize).min(1024)];
                    if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                        if let Ok(text) = std::str::from_utf8(&buf) {
                            if caller.data().hud_texts.len() < 512 {
                                caller.data_mut().hud_texts.push(DmodHudText {
                                    x,
                                    y,
                                    text: text.to_string(),
                                    argb: argb as u32,
                                    scale: if scale <= 0.0 { 1.0 } else { scale },
                                });
                            }
                        }
                    }
                }
                Ok(())
            },
        )?;
    } else {
        linker.func_wrap(
            module_name,
            "hud_text",
            |mut caller: Caller<'_, DmodHostState>,
             x: f32,
             y: f32,
             ptr: i32,
             len: i32,
             argb: i32,
             _shadow: i32| {
                if ptr < 0 || len <= 0 {
                    return Ok(());
                }
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut buf = vec![0u8; (len as usize).min(1024)];
                    if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                        if let Ok(text) = std::str::from_utf8(&buf) {
                            if caller.data().hud_texts.len() < 512 {
                                caller.data_mut().hud_texts.push(DmodHudText {
                                    x,
                                    y,
                                    text: text.to_string(),
                                    argb: argb as u32,
                                    scale: 1.0,
                                });
                            }
                        }
                    }
                }
                Ok(())
            },
        )?;
    }

    linker.func_wrap(
        module_name,
        "hud_text_scaled",
        |mut caller: Caller<'_, DmodHostState>,
         x: f32,
         y: f32,
         ptr: i32,
         len: i32,
         argb: i32,
         scale: f32,
         _shadow: i32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(1024)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    if let Ok(text) = std::str::from_utf8(&buf) {
                        let text = text.to_string();
                        caller.data_mut().hud_texts.push(DmodHudText {
                            x,
                            y,
                            text,
                            argb: argb as u32,
                            scale: if scale <= 0.0 { 1.0 } else { scale },
                        });
                    }
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "chat_local",
        |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(1024)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    if let Ok(msg) = std::str::from_utf8(&buf) {
                        caller.data_mut().chat_messages.push(msg.to_string());
                    }
                }
            }
            Ok(())
        },
    )?;

    if (variant_mask & 4) == 0 {
        linker.func_wrap(
            module_name,
            "register_setting_button",
            |mut caller: Caller<'_, DmodHostState>,
             id_ptr: i32,
             id_len: i32,
             label_ptr: i32,
             label_len: i32|
             -> i32 {
                let mut key = String::new();
                let mut label = String::new();
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut k_buf = vec![0u8; (id_len.max(0) as usize).min(128)];
                    if mem.read(&caller, id_ptr as usize, &mut k_buf).is_ok() {
                        if let Ok(k) = std::str::from_utf8(&k_buf) {
                            key = k.to_string();
                        }
                    }
                    let mut l_buf = vec![0u8; (label_len.max(0) as usize).min(128)];
                    if mem.read(&caller, label_ptr as usize, &mut l_buf).is_ok() {
                        if let Ok(l) = std::str::from_utf8(&l_buf) {
                            label = l.to_string();
                        }
                    }
                }
                let mod_id = caller.data().mod_id.clone();
                let btn_id = caller.data().next_button_id;
                caller.data_mut().next_button_id += 1;
                caller.data_mut().setting_buttons.push(DmodSettingButton {
                    id: btn_id,
                    mod_id,
                    key,
                    label,
                });
                btn_id
            },
        )?;
    } else {
        linker.func_wrap(
            module_name,
            "register_setting_button",
            |mut caller: Caller<'_, DmodHostState>, label_ptr: i32, label_len: i32| -> i32 {
                let mut label = String::new();
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let mut l_buf = vec![0u8; (label_len.max(0) as usize).min(128)];
                    if mem.read(&caller, label_ptr as usize, &mut l_buf).is_ok() {
                        if let Ok(l) = std::str::from_utf8(&l_buf) {
                            label = l.to_string();
                        }
                    }
                }
                let mod_id = caller.data().mod_id.clone();
                let btn_id = caller.data().next_button_id;
                caller.data_mut().next_button_id += 1;
                caller.data_mut().setting_buttons.push(DmodSettingButton {
                    id: btn_id,
                    mod_id,
                    key: format!("btn_{btn_id}"),
                    label,
                });
                btn_id
            },
        )?;
    }

    linker.func_wrap(
        module_name,
        "update_setting_button",
        |mut caller: Caller<'_, DmodHostState>, btn_id: i32, label_ptr: i32, label_len: i32| {
            let mut label = String::new();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut l_buf = vec![0u8; (label_len.max(0) as usize).min(128)];
                if mem.read(&caller, label_ptr as usize, &mut l_buf).is_ok() {
                    if let Ok(l) = std::str::from_utf8(&l_buf) {
                        label = l.to_string();
                    }
                }
            }
            if let Some(btn) = caller
                .data_mut()
                .setting_buttons
                .iter_mut()
                .find(|b| b.id == btn_id)
            {
                btn.label = label;
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_motion_blur",
        |mut caller: Caller<'_, DmodHostState>, enabled: i32, strength: f32| {
            caller.data_mut().motion_blur_enabled = enabled != 0;
            caller.data_mut().motion_blur_strength = strength.clamp(0.0, 1.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_fog_density",
        |mut caller: Caller<'_, DmodHostState>, density: f32| {
            caller.data_mut().fog_density = density.max(0.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_fog_color",
        |mut caller: Caller<'_, DmodHostState>, r: f32, g: f32, b: f32, a: f32| {
            caller.data_mut().fog_color = [r, g, b, a];
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_sky_color",
        |mut caller: Caller<'_, DmodHostState>, r: f32, g: f32, b: f32| {
            caller.data_mut().sky_override = Some([r, g, b]);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "reset_sky_color",
        |mut caller: Caller<'_, DmodHostState>| {
            caller.data_mut().sky_override = None;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_vignette",
        |mut caller: Caller<'_, DmodHostState>, r: f32, g: f32, b: f32, strength: f32| {
            caller.data_mut().vignette = [r, g, b, strength.clamp(0.0, 1.0)];
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_vignette_intensity",
        |mut caller: Caller<'_, DmodHostState>, strength: f32| {
            caller.data_mut().vignette[3] = strength.clamp(0.0, 1.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_gamma",
        |mut caller: Caller<'_, DmodHostState>, gamma: f32| {
            caller.data_mut().gamma = gamma.clamp(0.1, 10.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_saturation",
        |mut caller: Caller<'_, DmodHostState>, saturation: f32| {
            caller.data_mut().saturation = saturation.clamp(0.0, 3.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_grayscale",
        |mut caller: Caller<'_, DmodHostState>, enabled: i32| {
            caller.data_mut().grayscale = enabled != 0;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_fullbright",
        |mut caller: Caller<'_, DmodHostState>, enabled: i32| {
            caller.data_mut().fullbright = enabled != 0;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_builtin_shader",
        |_caller: Caller<'_, DmodHostState>, enabled: i32, strength: f32| {
            horizon_client_render::gfx::set_builtin_shader(enabled != 0, strength.clamp(0.0, 1.0));
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_dynamic_shadows",
        |_caller: Caller<'_, DmodHostState>, enabled: i32| {
            horizon_client_render::gfx::set_dynamic_shadows(enabled != 0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_vhs_fisheye",
        |_caller: Caller<'_, DmodHostState>, enabled: i32, strength: f32| {
            horizon_client_render::gfx::set_vhs_fisheye(enabled != 0);
            horizon_client_render::gfx::set_vhs_fisheye_strength(strength);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_post_affect_ui",
        |_caller: Caller<'_, DmodHostState>, enabled: i32| {
            horizon_client_render::gfx::set_post_affect_ui(enabled != 0);
        let _ = linker.func_wrap(
            module_name,
            "register_post_shader",
            |mut caller: Caller<'_, DmodHostState>, wgsl_ptr: i32, wgsl_len: i32| -> i32 {
                let src = read_guest_str(&mut caller, wgsl_ptr, wgsl_len);
                if src.is_empty() || src.len() > 65536 {
                    return 0;
                }
                horizon_client_render::gfx::register_custom_post_shader(src) as i32
            },
        );
        let _ = linker.func_wrap(
            module_name,
            "set_post_shader_enabled",
            |_caller: Caller<'_, DmodHostState>, enabled: i32, affect_ui: i32| {
                horizon_client_render::gfx::set_custom_post_enabled(enabled != 0, affect_ui != 0);
            },
        );
        let _ = linker.func_wrap(
            module_name,
            "set_post_shader_param",
            |_caller: Caller<'_, DmodHostState>, index: i32, value: f32| {
                if (0..8).contains(&index) {
                    horizon_client_render::gfx::set_custom_post_param(index as usize, value);
                }
            },
        );
        let _ = linker.func_wrap(
            module_name,
            "set_post_shader_strength",
            |_caller: Caller<'_, DmodHostState>, strength: f32| {
                horizon_client_render::gfx::set_custom_post_strength(strength);
            },
        );
        let _ = linker.func_wrap(
            module_name,
            "clear_post_shader",
            |_caller: Caller<'_, DmodHostState>| {
                horizon_client_render::gfx::clear_custom_post_shader();
            },
        );
        let _ = linker.func_wrap(
            module_name,
            "show_actionbar",
            |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| {
                let msg = read_guest_str(&mut caller, ptr, len);
                if !msg.is_empty() {
                    caller.data_mut().chat_messages.push(msg);
                }
            },
        );
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_resolution_scale",
        |_caller: Caller<'_, DmodHostState>, scale_percent: i32| {
            crate::entry::set_android_resolution_scale(scale_percent.clamp(10, 100) as u32);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_culling_flags",
        |mut caller: Caller<'_, DmodHostState>, flags: i32| {
            caller.data_mut().culling_flags = flags;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_fps_limit",
        |mut caller: Caller<'_, DmodHostState>, max_fps: i32| {
            caller.data_mut().fps_limit = max_fps;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_camera_pos",
        |mut caller: Caller<'_, DmodHostState>, out_xyz: i32| {
            let pos = caller.data().player_pos;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 24];
                bytes[0..8].copy_from_slice(&pos[0].to_le_bytes());
                bytes[8..16].copy_from_slice(&pos[1].to_le_bytes());
                bytes[16..24].copy_from_slice(&pos[2].to_le_bytes());
                let _ = mem.write(&mut caller, out_xyz as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_camera_rot",
        |mut caller: Caller<'_, DmodHostState>, out_rot: i32| {
            let rot = caller.data().player_rot;
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut bytes = [0u8; 8];
                bytes[0..4].copy_from_slice(&rot[0].to_le_bytes());
                bytes[4..8].copy_from_slice(&rot[1].to_le_bytes());
                let _ = mem.write(&mut caller, out_rot as usize, &bytes);
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_camera_pos_offset",
        |mut caller: Caller<'_, DmodHostState>, x: f32, y: f32, z: f32| {
            caller.data_mut().camera_pos_offset = [x, y, z];
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_hunger",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().player_hunger },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_air",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().player_air },
    )?;

    linker.func_wrap(
        module_name,
        "get_player_gamemode",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().player_gamemode },
    )?;

    linker.func_wrap(
        module_name,
        "get_selected_slot",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().selected_slot },
    )?;

    linker.func_wrap(
        module_name,
        "set_selected_slot",
        |mut caller: Caller<'_, DmodHostState>, slot: i32| {
            let clamped = slot.clamp(0, 8);
            caller.data_mut().selected_slot = clamped;
            caller.data_mut().pending_hotbar_slot = Some(clamped);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_dimension",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().dimension },
    )?;

    linker.func_wrap(
        module_name,
        "get_light_level",
        |caller: Caller<'_, DmodHostState>, _x: i32, _y: i32, _z: i32| -> i32 {
            caller.data().light_level
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_block_id",
        |caller: Caller<'_, DmodHostState>, x: i32, y: i32, z: i32| -> i32 {
            let tb = caller.data().targeted_block;
            if tb[0] != 0 && tb[1] == x && tb[2] == y && tb[3] == z {
                tb[4]
            } else {
                0
            }
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_sneaking",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if (caller.data().player_flags & 4) != 0 { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_sprinting",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if (caller.data().player_flags & 2) != 0 { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_swimming",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if (caller.data().player_flags & 8) != 0 { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_gliding",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if (caller.data().player_flags & 16) != 0 { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_burning",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if (caller.data().player_flags & 32) != 0 { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "register_event_listener",
        |mut caller: Caller<'_, DmodHostState>, event_mask: i32| {
            caller.data_mut().subscribed_events |= event_mask as u32;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "register_custom_block",
        |mut caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32, hardness: f32, light_emission: i32| -> i32 {
            if id_ptr < 0 || id_len <= 0 {
                return -1;
            }
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (id_len as usize).min(256)];
                if mem.read(&caller, id_ptr as usize, &mut buf).is_ok() {
                    if let Ok(id_str) = std::str::from_utf8(&buf) {
                        let id = id_str.to_string();
                        let next_id = (caller.data().custom_blocks.len() as i32) + 10000;
                        caller.data_mut().custom_blocks.push((id, hardness.max(0.0), light_emission.clamp(0, 15)));
                        return next_id;
                    }
                }
            }
            -1
        },
    )?;

    linker.func_wrap(
        module_name,
        "register_custom_item",
        |mut caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32, max_stack: i32| -> i32 {
            if id_ptr < 0 || id_len <= 0 {
                return -1;
            }
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (id_len as usize).min(256)];
                if mem.read(&caller, id_ptr as usize, &mut buf).is_ok() {
                    if let Ok(id_str) = std::str::from_utf8(&buf) {
                        let id = id_str.to_string();
                        let next_id = (caller.data().custom_items.len() as i32) + 20000;
                        caller.data_mut().custom_items.push((id, max_stack.clamp(1, 64)));
                        return next_id;
                    }
                }
            }
            -1
        },
    )?;

    linker.func_wrap(
        module_name,
        "send_custom_payload",
        |mut caller: Caller<'_, DmodHostState>, ch_ptr: i32, ch_len: i32, data_ptr: i32, data_len: i32| -> i32 {
            if ch_ptr < 0 || ch_len <= 0 || data_ptr < 0 || data_len < 0 {
                return 0;
            }
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut ch_buf = vec![0u8; (ch_len as usize).min(128)];
                let mut payload = vec![0u8; (data_len as usize).min(32768)];
                if mem.read(&caller, ch_ptr as usize, &mut ch_buf).is_ok()
                    && mem.read(&caller, data_ptr as usize, &mut payload).is_ok()
                {
                    if let Ok(ch) = std::str::from_utf8(&ch_buf) {
                        if caller.data().pending_payloads.len() < 64 {
                            caller.data_mut().pending_payloads.push((ch.to_string(), payload));
                            return 1;
                        }
                    }
                }
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_loaded_mod_count",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            caller.data().loaded_mod_ids.len() as i32
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_mod_loaded",
        |caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32| -> i32 {
            if id_ptr < 0 || id_len <= 0 {
                return 0;
            }
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (id_len as usize).min(128)];
                if mem.read(&caller, id_ptr as usize, &mut buf).is_ok() {
                    if let Ok(id_str) = std::str::from_utf8(&buf) {
                        return i32::from(caller.data().loaded_mod_ids.contains(id_str.trim()));
                    }
                }
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_mouse_button_down",
        |caller: Caller<'_, DmodHostState>, btn: i32| -> i32 {
            if caller.data().mouse_buttons_held.contains(&btn) { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "hud_line",
        |mut caller: Caller<'_, DmodHostState>,
         x1: f32,
         y1: f32,
         x2: f32,
         y2: f32,
         width: f32,
         argb: i32| {
            let dx = x2 - x1;
            let dy = y2 - y1;
            let thickness = width.max(1.0);
            let dist = (dx * dx + dy * dy).sqrt();
            let steps = (dist / (thickness * 0.75).max(1.0)).ceil().clamp(1.0, 256.0) as i32;
            let rects = &mut caller.data_mut().hud_rects;
            for s in 0..=steps {
                let t = if steps == 0 { 0.0 } else { s as f32 / steps as f32 };
                rects.push(DmodHudRect {
                    x: x1 + dx * t - thickness * 0.5,
                    y: y1 + dy * t - thickness * 0.5,
                    w: thickness,
                    h: thickness,
                    argb: argb as u32,
                });
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "hud_circle",
        |mut caller: Caller<'_, DmodHostState>, cx: f32, cy: f32, radius: f32, argb: i32| {
            let r = radius.clamp(0.5, 256.0);
            let bands = (r.ceil() as i32).clamp(1, 64);
            let rects = &mut caller.data_mut().hud_rects;
            for i in -bands..bands {
                let y0 = i as f32;
                let mid = (y0 + 0.5).abs();
                if mid < r {
                    let half_w = (r * r - mid * mid).sqrt();
                    rects.push(DmodHudRect {
                        x: cx - half_w,
                        y: cy + y0,
                        w: half_w * 2.0,
                        h: 1.0,
                        argb: argb as u32,
                    });
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "hud_texture",
        |mut caller: Caller<'_, DmodHostState>,
         ptr: i32,
         len: i32,
         x: f32,
         y: f32,
         w: f32,
         h: f32,
         u1: f32,
         v1: f32,
         u2: f32,
         v2: f32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(256)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    let name = String::from_utf8_lossy(&buf).into_owned();
                    caller.data_mut().hud_sprites.push(DmodHudSprite {
                        name, x, y, w, h, u1, v1, u2, v2, argb: u32::MAX,
                    });
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "hud_sprite",
        |mut caller: Caller<'_, DmodHostState>,
         ptr: i32,
         len: i32,
         x: f32,
         y: f32,
         w: f32,
         h: f32,
         u1: f32,
         v1: f32,
         u2: f32,
         v2: f32,
         argb: i32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(256)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    let name = String::from_utf8_lossy(&buf).into_owned();
                    caller.data_mut().hud_sprites.push(DmodHudSprite {
                        name, x, y, w, h, u1, v1, u2, v2, argb: argb as u32,
                    });
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(module_name, "get_player_saturation", |caller: Caller<'_, DmodHostState>| -> f32 {
        caller.data().player_saturation
    })?;
    linker.func_wrap(module_name, "get_player_exhaustion", |caller: Caller<'_, DmodHostState>| -> f32 {
        caller.data().player_exhaustion
    })?;
    linker.func_wrap(module_name, "get_player_absorption", |caller: Caller<'_, DmodHostState>| -> f32 {
        caller.data().player_absorption
    })?;
    linker.func_wrap(module_name, "get_tick_count", |caller: Caller<'_, DmodHostState>| -> i64 {
        caller.data().tick_count
    })?;
    linker.func_wrap(module_name, "is_hardcore", |caller: Caller<'_, DmodHostState>| -> i32 {
        i32::from(caller.data().is_hardcore)
    })?;
    linker.func_wrap(module_name, "get_player_status_mask", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().player_status_mask
    })?;
    linker.func_wrap(module_name, "get_player_armor", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().player_armor
    })?;
    linker.func_wrap(module_name, "is_mounted_with_health", |caller: Caller<'_, DmodHostState>| -> i32 {
        i32::from(caller.data().mounted_with_health)
    })?;
    linker.func_wrap(module_name, "get_difficulty", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().difficulty
    })?;
    linker.func_wrap(module_name, "get_gui_ticks", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().gui_ticks
    })?;
    linker.func_wrap(module_name, "is_raining", |caller: Caller<'_, DmodHostState>| -> i32 {
        i32::from(caller.data().is_raining)
    })?;
    linker.func_wrap(module_name, "is_thundering", |caller: Caller<'_, DmodHostState>| -> i32 {
        i32::from(caller.data().is_thundering)
    })?;
    linker.func_wrap(module_name, "get_server_address", |mut caller: Caller<'_, DmodHostState>, out_ptr: i32, max_len: i32| -> i32 {
        let addr = caller.data().server_address.clone();
        if addr.is_empty() || out_ptr <= 0 || max_len <= 0 { return 0; }
        let bytes = addr.as_bytes();
        let n = bytes.len().min(max_len as usize);
        if let Some(wasmi::Extern::Memory(mem)) = caller.get_export("memory") {
            if mem.write(&mut caller, out_ptr as usize, &bytes[..n]).is_ok() {
                return n as i32;
            }
        }
        0
    })?;
    linker.func_wrap(module_name, "register_client_command", |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| -> i32 {
        if let Some(name) = read_guest_str(&mut caller, ptr, len) {
            let clean = name.trim().trim_start_matches('/').to_ascii_lowercase();
            if !clean.is_empty() {
                let cmds = &mut caller.data_mut().client_commands;
                if !cmds.contains(&clean) { cmds.push(clean); }
                return 1;
            }
        }
        0
    })?;
    linker.func_wrap(module_name, "register_keybind", |mut caller: Caller<'_, DmodHostState>, id_p: i32, id_l: i32, lbl_p: i32, lbl_l: i32, cat_p: i32, cat_l: i32, key_code: i32| -> i32 {
        let id = read_guest_str(&mut caller, id_p, id_l).unwrap_or_default();
        let lbl = read_guest_str(&mut caller, lbl_p, lbl_l).unwrap_or_default();
        let cat = read_guest_str(&mut caller, cat_p, cat_l).unwrap_or_else(|| "key.categories.misc".to_string());
        if id.is_empty() { return 0; }
        let kbs = &mut caller.data_mut().keybinds;
        if let Some(existing) = kbs.iter_mut().find(|k| k.0 == id) {
            existing.1 = lbl; existing.2 = cat; existing.3 = key_code;
        } else {
            kbs.push((id, lbl, cat, key_code));
        }
        1
    })?;
    linker.func_wrap(module_name, "tooltip_add_line", |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32, argb: i32| {
        if let Some(text) = read_guest_str(&mut caller, ptr, len) {
            if !text.is_empty() {
                caller.data_mut().tooltip_extra_lines.push((text, argb as u32));
            }
        }
    })?;
    linker.func_wrap(module_name, "attachment_get", |mut caller: Caller<'_, DmodHostState>, k_p: i32, k_l: i32, out_p: i32, max_l: i32| -> i32 {
        let Some(key) = read_guest_str(&mut caller, k_p, k_l) else { return -1; };
        let val = caller.data().attachments.get(&key).cloned();
        let Some(v) = val else { return -1; };
        let bytes = v.as_bytes();
        let n = bytes.len().min(max_l.max(0) as usize);
        if n > 0 && out_p > 0 {
            if let Some(wasmi::Extern::Memory(mem)) = caller.get_export("memory") {
                if mem.write(&mut caller, out_p as usize, &bytes[..n]).is_ok() {
                    return n as i32;
                }
            }
        }
        0
    })?;
    linker.func_wrap(module_name, "attachment_set", |mut caller: Caller<'_, DmodHostState>, k_p: i32, k_l: i32, v_p: i32, v_l: i32| {
        let Some(key) = read_guest_str(&mut caller, k_p, k_l) else { return; };
        let val = read_guest_str(&mut caller, v_p, v_l).unwrap_or_default();
        let data = caller.data_mut();
        data.attachments.insert(key, val);
        if let Some(ref path) = data.attachments_file {
            if let Some(parent) = path.parent() { let _ = std::fs::create_dir_all(parent); }
            if let Ok(json) = serde_json::to_string_pretty(&data.attachments) {
                let _ = std::fs::write(path, json);
            }
        }
    })?;
    linker.func_wrap(module_name, "register_data_pack_json", |mut caller: Caller<'_, DmodHostState>, p_ptr: i32, p_len: i32, j_ptr: i32, j_len: i32| -> i32 {
        let Some(path) = read_guest_str(&mut caller, p_ptr, p_len) else { return 0; };
        let Some(json) = read_guest_str(&mut caller, j_ptr, j_len) else { return 0; };
        if path.is_empty() || json.is_empty() { return 0; }
        let files = &mut caller.data_mut().data_pack_files;
        if let Some(existing) = files.iter_mut().find(|(p, _)| p == &path) {
            existing.1 = json.into_bytes();
        } else {
            files.push((path, json.into_bytes()));
        }
        1
    })?;
    linker.func_wrap(module_name, "get_api_capabilities_mask", |_caller: Caller<'_, DmodHostState>| -> i64 {
        0x0000_0000_00FF_FFFF_i64
    })?;
    linker.func_wrap(module_name, "get_slot_durability", |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
        caller.data().slot_components
            .get(&(slot, "minecraft:damage".to_string()))
            .and_then(|v| v.parse::<i32>().ok())
            .unwrap_or(0)
    })?;
    linker.func_wrap(module_name, "get_slot_max_durability", |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
        caller.data().slot_components
            .get(&(slot, "minecraft:max_damage".to_string()))
            .and_then(|v| v.parse::<i32>().ok())
            .unwrap_or(0)
    })?;
    linker.func_wrap(module_name, "get_slot_enchantment_count", |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
        caller.data().slot_components
            .get(&(slot, "minecraft:enchantments".to_string()))
            .map(|raw| raw.matches(':').count() as i32)
            .unwrap_or(0)
    })?;
    linker.func_wrap(module_name, "get_slot_component_json", |mut caller: Caller<'_, DmodHostState>, slot: i32, k_ptr: i32, k_len: i32, o_ptr: i32, o_cap: i32| -> i32 {
        let Some(key) = read_guest_str(&mut caller, k_ptr, k_len) else { return 0; };
        let val = caller.data().slot_components.get(&(slot, key)).cloned().unwrap_or_default();
        if val.is_empty() { return 0; }
        write_guest_bytes(&mut caller, o_ptr, o_cap, val.as_bytes())
    })?;
    linker.func_wrap(module_name, "set_slot_component_json", |mut caller: Caller<'_, DmodHostState>, slot: i32, k_ptr: i32, k_len: i32, v_ptr: i32, v_len: i32| -> i32 {
        let Some(key) = read_guest_str(&mut caller, k_ptr, k_len) else { return 0; };
        let Some(val) = read_guest_str(&mut caller, v_ptr, v_len) else { return 0; };
        if key.is_empty() { return 0; }
        caller.data_mut().slot_components.insert((slot, key), val);
        1
    })?;
    linker.func_wrap(module_name, "register_resource_asset", |mut caller: Caller<'_, DmodHostState>, p_ptr: i32, p_len: i32, b_ptr: i32, b_len: i32| -> i32 {
        let Some(path) = read_guest_str(&mut caller, p_ptr, p_len) else { return 0; };
        if path.is_empty() || b_len <= 0 || b_len > 8 * 1024 * 1024 { return 0; }
        let mut buf = vec![0u8; b_len as usize];
        let ok = if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
            mem.read(&caller, b_ptr as usize, &mut buf).is_ok()
        } else {
            false
        };
        if !ok { return 0; }
        caller.data_mut().resource_assets.insert(path, buf);
        1
    })?;
    linker.func_wrap(module_name, "read_resource_asset", |mut caller: Caller<'_, DmodHostState>, p_ptr: i32, p_len: i32, o_ptr: i32, o_cap: i32| -> i32 {
        let Some(path) = read_guest_str(&mut caller, p_ptr, p_len) else { return 0; };
        let bytes = caller.data().resource_assets.get(&path).cloned().unwrap_or_default();
        if bytes.is_empty() { return 0; }
        write_guest_bytes(&mut caller, o_ptr, o_cap, &bytes)
    })?;
    linker.func_wrap(module_name, "register_recipe_json", |mut caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32, j_ptr: i32, j_len: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, id_ptr, id_len) else { return 0; };
        let Some(json) = read_guest_str(&mut caller, j_ptr, j_len) else { return 0; };
        if id.is_empty() || json.is_empty() { return 0; }
        let (ns, name) = id.split_once(':').unwrap_or(("diamond", id.as_str()));
        let path = format!("data/{ns}/recipe/{name}.json");
        caller.data_mut().data_pack_files.push((path, json.into_bytes()));
        1
    })?;
    linker.func_wrap(module_name, "register_loot_table_json", |mut caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32, j_ptr: i32, j_len: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, id_ptr, id_len) else { return 0; };
        let Some(json) = read_guest_str(&mut caller, j_ptr, j_len) else { return 0; };
        if id.is_empty() || json.is_empty() { return 0; }
        let (ns, name) = id.split_once(':').unwrap_or(("diamond", id.as_str()));
        let path = format!("data/{ns}/loot_table/{name}.json");
        caller.data_mut().data_pack_files.push((path, json.into_bytes()));
        1
    })?;
    linker.func_wrap(module_name, "register_tag_json", |mut caller: Caller<'_, DmodHostState>, r_ptr: i32, r_len: i32, id_ptr: i32, id_len: i32, j_ptr: i32, j_len: i32| -> i32 {
        let Some(reg) = read_guest_str(&mut caller, r_ptr, r_len) else { return 0; };
        let Some(id) = read_guest_str(&mut caller, id_ptr, id_len) else { return 0; };
        let Some(json) = read_guest_str(&mut caller, j_ptr, j_len) else { return 0; };
        if reg.is_empty() || id.is_empty() || json.is_empty() { return 0; }
        let (ns, name) = id.split_once(':').unwrap_or(("diamond", id.as_str()));
        let path = format!("data/{ns}/tags/{reg}/{name}.json");
        caller.data_mut().data_pack_files.push((path, json.into_bytes()));
        1
    })?;
    linker.func_wrap(module_name, "register_creative_tab", |mut caller: Caller<'_, DmodHostState>, id_ptr: i32, id_len: i32, t_ptr: i32, t_len: i32, ic_ptr: i32, ic_len: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, id_ptr, id_len) else { return 0; };
        let Some(title) = read_guest_str(&mut caller, t_ptr, t_len) else { return 0; };
        let Some(icon) = read_guest_str(&mut caller, ic_ptr, ic_len) else { return 0; };
        if id.is_empty() { return 0; }
        caller.data_mut().creative_tabs.push((id, title, icon));
        1
    })?;
    linker.func_wrap(module_name, "add_item_to_creative_tab", |mut caller: Caller<'_, DmodHostState>, tab_ptr: i32, tab_len: i32, item_ptr: i32, item_len: i32| -> i32 {
        let Some(tab) = read_guest_str(&mut caller, tab_ptr, tab_len) else { return 0; };
        let Some(item) = read_guest_str(&mut caller, item_ptr, item_len) else { return 0; };
        if tab.is_empty() || item.is_empty() { return 0; }
        caller.data_mut().creative_tab_items.entry(tab).or_default().push(item);
        1
    })?;
    linker.func_wrap(module_name, "register_payload_channel", |mut caller: Caller<'_, DmodHostState>, c_ptr: i32, c_len: i32, dir: i32| -> i32 {
        let Some(ch) = read_guest_str(&mut caller, c_ptr, c_len) else { return 0; };
        if ch.is_empty() { return 0; }
        caller.data_mut().payload_channels.insert(ch, dir.clamp(0, 2));
        1
    })?;
    linker.func_wrap(module_name, "is_payload_channel_registered", |mut caller: Caller<'_, DmodHostState>, c_ptr: i32, c_len: i32| -> i32 {
        let Some(ch) = read_guest_str(&mut caller, c_ptr, c_len) else { return 0; };
        if caller.data().payload_channels.contains_key(&ch) { 1 } else { 0 }
    })?;
    linker.func_wrap(module_name, "get_highest_block_y", |caller: Caller<'_, DmodHostState>, x: i32, z: i32| -> i32 {
        let mut highest = -64i32;
        for ((bx, by, bz), id) in &caller.data().local_blocks {
            if *bx == x && *bz == z && id != "minecraft:air" && *by > highest {
                highest = *by;
            }
        }
        highest
    })?;
    linker.func_wrap(module_name, "is_chunk_loaded", |caller: Caller<'_, DmodHostState>, cx: i32, cz: i32| -> i32 {
        if !caller.data().in_world { return 0; }
        let px = (caller.data().player_pos[0].floor() as i32).div_euclid(16);
        let pz = (caller.data().player_pos[2].floor() as i32).div_euclid(16);
        let rd = caller.data().render_distance.max(2);
        if (cx - px).abs() <= rd && (cz - pz).abs() <= rd { 1 } else { 0 }
    })?;
    linker.func_wrap(module_name, "get_day_count", |caller: Caller<'_, DmodHostState>| -> i32 {
        (caller.data().world_time / 24000).max(0) as i32
    })?;
    linker.func_wrap(module_name, "get_moon_phase", |caller: Caller<'_, DmodHostState>| -> i32 {
        ((caller.data().world_time / 24000).rem_euclid(8)) as i32
    })?;
    linker.func_wrap(module_name, "get_mod_version", |mut caller: Caller<'_, DmodHostState>, m_ptr: i32, m_len: i32, o_ptr: i32, o_cap: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, m_ptr, m_len) else { return 0; };
        let ver = caller.data().mod_versions.get(&id).cloned().unwrap_or_default();
        if ver.is_empty() { return 0; }
        write_guest_bytes(&mut caller, o_ptr, o_cap, ver.as_bytes())
    })?;
    linker.func_wrap(module_name, "send_imc_message", |mut caller: Caller<'_, DmodHostState>, t_ptr: i32, t_len: i32, m_ptr: i32, m_len: i32, p_ptr: i32, p_len: i32| -> i32 {
        let Some(target) = read_guest_str(&mut caller, t_ptr, t_len) else { return 0; };
        let Some(method) = read_guest_str(&mut caller, m_ptr, m_len) else { return 0; };
        let payload = read_guest_str(&mut caller, p_ptr, p_len).unwrap_or_default();
        if target.is_empty() || method.is_empty() { return 0; }
        let list = &mut caller.data_mut().pending_imc;
        if list.len() < 64 {
            list.push((target, method, payload));
            1
        } else {
            0
        }
    })?;
    linker.func_wrap(module_name, "spawn_particle", |mut caller: Caller<'_, DmodHostState>, n_ptr: i32, n_len: i32, x: f64, y: f64, z: f64, vx: f64, vy: f64, vz: f64| -> i32 {
        let Some(name) = read_guest_str(&mut caller, n_ptr, n_len) else { return 0; };
        if name.is_empty() { return 0; }
        let list = &mut caller.data_mut().pending_particles;
        if list.len() < 256 {
            list.push((name, [x, y, z], [vx, vy, vz]));
            return 1;
        }
        0
    })?;
    linker.func_wrap(module_name, "draw_world_model", |mut caller: Caller<'_, DmodHostState>, m_ptr: i32, m_len: i32, x: f64, y: f64, z: f64, rx: f32, ry: f32, rz: f32, sx: f32, sy: f32, sz: f32, tint: i32| -> i32 {
        let Some(model) = read_guest_str(&mut caller, m_ptr, m_len) else { return 0; };
        if model.is_empty() { return 0; }
        let list = &mut caller.data_mut().world_models;
        if list.len() < 512 {
            list.push(DmodWorldModel {
                model,
                pos: [x, y, z],
                rot: [rx, ry, rz],
                scale: [if sx == 0.0 { 1.0 } else { sx }, if sy == 0.0 { 1.0 } else { sy }, if sz == 0.0 { 1.0 } else { sz }],
                tint: (tint as u32) & 0x00FF_FFFF,
            });
            return 1;
        }
        0
    })?;
    linker.func_wrap(module_name, "screen_add_button", |mut caller: Caller<'_, DmodHostState>, id: i32, x: f32, y: f32, w: f32, h: f32, lbl_p: i32, lbl_l: i32| {
        let label = read_guest_str(&mut caller, lbl_p, lbl_l).unwrap_or_default();
        let btns = &mut caller.data_mut().screen_buttons;
        if btns.len() < 64 {
            btns.push(DmodScreenButton { id, x, y, w, h, label });
        }
    })?;
    linker.func_wrap(module_name, "set_block_at", |mut caller: Caller<'_, DmodHostState>, x: i32, y: i32, z: i32, id_p: i32, id_l: i32| -> i32 {
        let Some(bid) = read_guest_str(&mut caller, id_p, id_l) else { return 0; };
        let clean = bid.trim();
        if clean.is_empty() || clean.contains('\n') || clean.contains('\r') { return 0; }
        caller.data_mut().pending_world_commands.push(format!("setblock {x} {y} {z} {clean}"));
        1
    })?;
    linker.func_wrap(module_name, "spawn_entity", |mut caller: Caller<'_, DmodHostState>, t_p: i32, t_l: i32, x: f64, y: f64, z: f64| -> i32 {
        let Some(eid) = read_guest_str(&mut caller, t_p, t_l) else { return 0; };
        let clean = eid.trim();
        if clean.is_empty() || clean.contains('\n') || clean.contains('\r') { return 0; }
        caller.data_mut().pending_world_commands.push(format!("summon {clean} {x:.3} {y:.3} {z:.3}"));
        1
    })?;
    linker.func_wrap(module_name, "play_world_sound", |mut caller: Caller<'_, DmodHostState>, n_p: i32, n_l: i32, x: f64, y: f64, z: f64, vol: f32, pitch: f32| -> i32 {
        let Some(name) = read_guest_str(&mut caller, n_p, n_l) else { return 0; };
        if name.is_empty() { return 0; }
        caller.data_mut().pending_world_sounds.push((name, [x, y, z], vol.clamp(0.0, 4.0), pitch.clamp(0.25, 4.0)));
        1
    })?;
    linker.func_wrap(module_name, "draw_world_cuboid", |mut caller: Caller<'_, DmodHostState>, s_p: i32, s_l: i32, x: f64, y: f64, z: f64, w: f32, h: f32, d: f32, rx: f32, ry: f32, rz: f32, tint: i32| -> i32 {
        let Some(sprite) = read_guest_str(&mut caller, s_p, s_l) else { return 0; };
        if sprite.is_empty() { return 0; }
        let list = &mut caller.data_mut().world_cuboids;
        if list.len() < 1024 {
            list.push(DmodWorldCuboid {
                sprite,
                pos: [x, y, z],
                size: [w.max(0.001), h.max(0.001), d.max(0.001)],
                rot: [rx, ry, rz],
                tint: (tint as u32) & 0x00FF_FFFF,
            });
            return 1;
        }
        0
    })?;
    linker.func_wrap(module_name, "get_block_at", |mut caller: Caller<'_, DmodHostState>, x: i32, y: i32, z: i32, out_p: i32, max_l: i32| -> i32 {
        let name = caller.data().local_blocks.get(&(x, y, z)).cloned();
        let Some(s) = name else { return 0; };
        let bytes = s.as_bytes();
        let n = bytes.len().min(max_l.max(0) as usize);
        if n > 0 && out_p > 0 {
            if let Some(wasmi::Extern::Memory(mem)) = caller.get_export("memory") {
                if mem.write(&mut caller, out_p as usize, &bytes[..n]).is_ok() {
                    return n as i32;
                }
            }
        }
        0
    })?;
    linker.func_wrap(module_name, "get_nearby_entity_count", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().nearby_entity_count
    })?;
    linker.func_wrap(module_name, "get_nearest_entity", |mut caller: Caller<'_, DmodHostState>, out_p: i32| -> i32 {
        let Some((id, pos, dist)) = caller.data().nearest_entity else { return 0; };
        if out_p <= 0 { return 0; }
        let mut buf = [0u8; 32];
        buf[0..4].copy_from_slice(&id.to_le_bytes());
        buf[4..12].copy_from_slice(&pos[0].to_le_bytes());
        buf[12..20].copy_from_slice(&pos[1].to_le_bytes());
        buf[20..28].copy_from_slice(&pos[2].to_le_bytes());
        buf[28..32].copy_from_slice(&dist.to_le_bytes());
        if let Some(wasmi::Extern::Memory(mem)) = caller.get_export("memory") {
            if mem.write(&mut caller, out_p as usize, &buf).is_ok() {
                return 1;
            }
        }
        0
    })?;
    linker.func_wrap(module_name, "draw_world_text", |mut caller: Caller<'_, DmodHostState>, t_p: i32, t_l: i32, x: f64, y: f64, z: f64, yaw: f32, pitch: f32, scale: f32, color: i32, glowing: i32| -> i32 {
        let Some(text) = read_guest_str(&mut caller, t_p, t_l) else { return 0; };
        if text.is_empty() { return 0; }
        let list = &mut caller.data_mut().world_texts;
        if list.len() < 256 {
            list.push(DmodWorldText {
                text,
                pos: [x, y, z],
                rot: [yaw, pitch],
                scale: if scale <= 0.0 { 0.025 } else { scale },
                color: (color as u32) & 0x00FF_FFFF,
                glowing: glowing != 0,
            });
            return 1;
        }
        0
    })?;
    linker.func_wrap(module_name, "set_keybind", |mut caller: Caller<'_, DmodHostState>, id_p: i32, id_l: i32, key_code: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, id_p, id_l) else { return 0; };
        let data = caller.data_mut();
        let mut found = false;
        for kb in &mut data.keybinds {
            if kb.0 == id {
                kb.3 = key_code;
                found = true;
            }
        }
        if found {
            if let Some(ref path) = data.keybinds_file {
                let mut map: HashMap<String, i32> = std::fs::read_to_string(path)
                    .ok()
                    .and_then(|s| serde_json::from_str(&s).ok())
                    .unwrap_or_default();
                map.insert(id, key_code);
                if let Ok(json) = serde_json::to_string_pretty(&map) {
                    let _ = std::fs::write(path, json);
                }
            }
            return 1;
        }
        0
    })?;
    linker.func_wrap(module_name, "get_keybind", |mut caller: Caller<'_, DmodHostState>, id_p: i32, id_l: i32| -> i32 {
        let Some(id) = read_guest_str(&mut caller, id_p, id_l) else { return -1; };
        caller.data().keybinds.iter().find(|k| k.0 == id).map_or(-1, |k| k.3)
    })?;
    linker.func_wrap(module_name, "set_fluid_flow_blocked", |_caller: Caller<'_, DmodHostState>, blocked: i32| {
        DMOD_FLUID_FLOW_BLOCKED.store(blocked != 0, std::sync::atomic::Ordering::Relaxed);
    })?;
    linker.func_wrap(module_name, "set_fire_spread_blocked", |_caller: Caller<'_, DmodHostState>, blocked: i32| {
        DMOD_FIRE_SPREAD_BLOCKED.store(blocked != 0, std::sync::atomic::Ordering::Relaxed);
    })?;
    linker.func_wrap(module_name, "get_held_food_info", |mut caller: Caller<'_, DmodHostState>, hand: i32, out_ptr: i32| -> i32 {
        let info = caller.data().held_food.get(hand.clamp(0, 1) as usize).copied().unwrap_or_default();
        if !info.is_food {
            return 0;
        }
        let vals = [
            1i32,
            info.nutrition as i32,
            info.saturation.to_bits() as i32,
            i32::from(info.can_always_eat),
            i32::from(info.is_rotten),
            info.regen_hp.to_bits() as i32,
        ];
        if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
            let mut bytes = [0u8; 24];
            for (i, v) in vals.iter().enumerate() {
                bytes[i * 4..(i + 1) * 4].copy_from_slice(&v.to_le_bytes());
            }
            let _ = mem.write(&mut caller, out_ptr as usize, &bytes);
        }
        1
    })?;
    linker.func_wrap(module_name, "get_slot_food_info", |mut caller: Caller<'_, DmodHostState>, slot: i32, out_ptr: i32| -> i32 {
        let info = if slot >= 0 {
            caller.data().slot_foods.get(slot as usize).copied().unwrap_or_default()
        } else {
            DmodFoodInfo::default()
        };
        if !info.is_food {
            return 0;
        }
        let vals = [
            1i32,
            info.nutrition as i32,
            info.saturation.to_bits() as i32,
            i32::from(info.can_always_eat),
            i32::from(info.is_rotten),
            info.regen_hp.to_bits() as i32,
        ];
        if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
            let mut bytes = [0u8; 24];
            for (i, v) in vals.iter().enumerate() {
                bytes[i * 4..(i + 1) * 4].copy_from_slice(&v.to_le_bytes());
            }
            let _ = mem.write(&mut caller, out_ptr as usize, &bytes);
        }
        1
    })?;
    linker.func_wrap(module_name, "add_debug_line", |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| {
        if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
            let mut buf = vec![0u8; (len.max(0) as usize).min(512)];
            if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                let line = String::from_utf8_lossy(&buf).into_owned();
                caller.data_mut().debug_lines.push(line);
            }
        }
        Ok(())
    })?;

    linker.func_wrap(
        module_name,
        "draw_world_line",
        |mut caller: Caller<'_, DmodHostState>,
         x1: f32,
         y1: f32,
         z1: f32,
         x2: f32,
         y2: f32,
         z2: f32,
         argb: i32| {
            let u = argb as u32;
            let a = ((u >> 24) & 0xFF) as f32 / 255.0;
            let r = ((u >> 16) & 0xFF) as f32 / 255.0;
            let g = ((u >> 8) & 0xFF) as f32 / 255.0;
            let b = (u & 0xFF) as f32 / 255.0;
            caller.data_mut().world_lines.push(DmodWorldLine {
                a: [x1 as f64, y1 as f64, z1 as f64],
                b: [x2 as f64, y2 as f64, z2 as f64],
                rgba: [r, g, b, a],
            });
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "draw_world_box",
        |mut caller: Caller<'_, DmodHostState>,
         min_x: f32,
         min_y: f32,
         min_z: f32,
         max_x: f32,
         max_y: f32,
         max_z: f32,
         argb: i32| {
            let u = argb as u32;
            let a = ((u >> 24) & 0xFF) as f32 / 255.0;
            let r = ((u >> 16) & 0xFF) as f32 / 255.0;
            let g = ((u >> 8) & 0xFF) as f32 / 255.0;
            let b = (u & 0xFF) as f32 / 255.0;
            let rgba = [r, g, b, a];
            let (x0, y0, z0) = (min_x as f64, min_y as f64, min_z as f64);
            let (x1, y1, z1) = (max_x as f64, max_y as f64, max_z as f64);
            let edges = [
                ([x0, y0, z0], [x1, y0, z0]),
                ([x1, y0, z0], [x1, y0, z1]),
                ([x1, y0, z1], [x0, y0, z1]),
                ([x0, y0, z1], [x0, y0, z0]),
                ([x0, y1, z0], [x1, y1, z0]),
                ([x1, y1, z0], [x1, y1, z1]),
                ([x1, y1, z1], [x0, y1, z1]),
                ([x0, y1, z1], [x0, y1, z0]),
                ([x0, y0, z0], [x0, y1, z0]),
                ([x1, y0, z0], [x1, y1, z0]),
                ([x1, y0, z1], [x1, y1, z1]),
                ([x0, y0, z1], [x0, y1, z1]),
            ];
            let lines = &mut caller.data_mut().world_lines;
            for (pa, pb) in edges {
                lines.push(DmodWorldLine { a: pa, b: pb, rgba });
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "play_sound",
        |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32, vol: f32, pitch: f32| {
            let mut sound_id = String::new();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(256)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    sound_id = String::from_utf8_lossy(&buf).into_owned();
                }
            }
            if !sound_id.is_empty() {
                caller.data_mut().pending_sounds.push((sound_id, vol.clamp(0.0, 4.0), pitch.clamp(0.25, 4.0)));
            } else {
                caller.data_mut().sound_clicks += 1;
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "play_sound_local",
        |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32, vol: f32, pitch: f32| {
            let mut sound_id = String::new();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(256)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    sound_id = String::from_utf8_lossy(&buf).into_owned();
                }
            }
            if !sound_id.is_empty() {
                caller.data_mut().pending_sounds.push((sound_id, vol.clamp(0.0, 4.0), pitch.clamp(0.25, 4.0)));
            } else {
                caller.data_mut().sound_clicks += 1;
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "stop_all_sounds",
        |mut caller: Caller<'_, DmodHostState>| {
            caller.data_mut().pending_stop_sounds = true;
            Ok(())
        },
    )?;

    linker.func_wrap(module_name, "get_player_xp_level", |caller: Caller<'_, DmodHostState>| -> i32 {
        caller.data().player_xp_level
    })?;
    linker.func_wrap(module_name, "get_player_xp_progress", |caller: Caller<'_, DmodHostState>| -> f32 {
        caller.data().player_xp_progress
    })?;

    linker.func_wrap(
        module_name,
        "kv_get",
        |mut caller: Caller<'_, DmodHostState>,
         key_ptr: i32,
         key_len: i32,
         out_ptr: i32,
         out_max: i32|
         -> i32 {
            let mut key = String::new();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut k_buf = vec![0u8; (key_len.max(0) as usize).min(256)];
                if mem.read(&caller, key_ptr as usize, &mut k_buf).is_ok() {
                    if let Ok(k) = std::str::from_utf8(&k_buf) {
                        key = k.to_string();
                    }
                }
            }
            if let Some(val) = caller.data().kv_store.get(&key).cloned() {
                if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                    let bytes = val.as_bytes();
                    let write_len = bytes.len().min(out_max.max(0) as usize);
                    let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                    return write_len as i32;
                }
            }
            -1
        },
    )?;

    linker.func_wrap(
        module_name,
        "kv_set",
        |mut caller: Caller<'_, DmodHostState>,
         key_ptr: i32,
         key_len: i32,
         val_ptr: i32,
         val_len: i32| {
            let mut key = String::new();
            let mut val = String::new();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut k_buf = vec![0u8; (key_len.max(0) as usize).min(256)];
                if mem.read(&caller, key_ptr as usize, &mut k_buf).is_ok() {
                    if let Ok(k) = std::str::from_utf8(&k_buf) {
                        key = k.to_string();
                    }
                }
                let mut v_buf = vec![0u8; (val_len.max(0) as usize).min(4096)];
                if mem.read(&caller, val_ptr as usize, &mut v_buf).is_ok() {
                    if let Ok(v) = std::str::from_utf8(&v_buf) {
                        val = v.to_string();
                    }
                }
            }
            if !key.is_empty() {
                let data = caller.data_mut();
                data.kv_store.insert(key, val);
                if let Some(path) = data.kv_file.clone() {
                    if let Some(parent) = path.parent() {
                        let _ = std::fs::create_dir_all(parent);
                    }
                    if let Ok(text) = serde_json::to_string_pretty(&data.kv_store) {
                        let _ = std::fs::write(&path, text);
                    }
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_particle_density",
        |mut caller: Caller<'_, DmodHostState>, density: f32| {
            caller.data_mut().particle_density = density.clamp(0.0, 2.0);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_render_distance",
        |mut caller: Caller<'_, DmodHostState>, distance: i32| {
            caller.data_mut().render_distance = distance.clamp(2, 32);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_multiplayer",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if caller.data().is_multiplayer { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_open_container_type",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().container_type },
    )?;

    linker.func_wrap(
        module_name,
        "get_container_slot_count",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().container_slot_count },
    )?;

    linker.func_wrap(
        module_name,
        "get_hovered_slot",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().hovered_slot },
    )?;

    linker.func_wrap(
        module_name,
        "get_cursor_x",
        |caller: Caller<'_, DmodHostState>| -> f32 { caller.data().cursor_x },
    )?;

    linker.func_wrap(
        module_name,
        "get_cursor_y",
        |caller: Caller<'_, DmodHostState>| -> f32 { caller.data().cursor_y },
    )?;

    linker.func_wrap(
        module_name,
        "is_shift_down",
        |caller: Caller<'_, DmodHostState>| -> i32 { i32::from(caller.data().shift_down) },
    )?;

    linker.func_wrap(
        module_name,
        "is_ctrl_down",
        |caller: Caller<'_, DmodHostState>| -> i32 { i32::from(caller.data().ctrl_down) },
    )?;

    linker.func_wrap(
        module_name,
        "is_alt_down",
        |caller: Caller<'_, DmodHostState>| -> i32 { i32::from(caller.data().alt_down) },
    )?;

    linker.func_wrap(
        module_name,
        "get_slot_id_at_index",
        |caller: Caller<'_, DmodHostState>, idx: i32| -> i32 {
            caller
                .data()
                .slots
                .get(idx.max(0) as usize)
                .map_or(-1, |s| s.slot_id)
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_slot_item_id",
        |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map_or(0, |s| s.item_id)
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_slot_item_count",
        |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map_or(0, |s| s.count)
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_slot_max_stack",
        |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map_or(64, |s| s.max_stack)
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_slot_item_name",
        |mut caller: Caller<'_, DmodHostState>, slot: i32, out_ptr: i32, out_max: i32| -> i32 {
            let name = caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map(|s| s.item_name.clone())
                .unwrap_or_default();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let bytes = name.as_bytes();
                let write_len = bytes.len().min(out_max.max(0) as usize);
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                return write_len as i32;
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_slot_crafting_output",
        |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map_or(0, |s| i32::from(s.is_result))
        },
    )?;

    linker.func_wrap(
        module_name,
        "is_slot_player_inventory",
        |caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller
                .data()
                .slots
                .iter()
                .find(|s| s.slot_id == slot)
                .map_or(0, |s| i32::from(s.is_player_inv))
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_carried_item_id",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().carried_item_id },
    )?;

    linker.func_wrap(
        module_name,
        "get_carried_item_count",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().carried_item_count },
    )?;

    linker.func_wrap(
        module_name,
        "get_carried_max_stack",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().carried_max_stack },
    )?;

    linker.func_wrap(
        module_name,
        "get_carried_item_name",
        |mut caller: Caller<'_, DmodHostState>, out_ptr: i32, out_max: i32| -> i32 {
            let name = caller.data().carried_item_name.clone();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let bytes = name.as_bytes();
                let write_len = bytes.len().min(out_max.max(0) as usize);
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                return write_len as i32;
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "are_slots_compatible",
        |caller: Caller<'_, DmodHostState>, slot_a: i32, slot_b: i32| -> i32 {
            let d = caller.data();
            let id_of = |s: i32| -> i32 {
                if s < 0 {
                    d.carried_item_id
                } else {
                    d.slots.iter().find(|x| x.slot_id == s).map_or(0, |x| x.item_id)
                }
            };
            let a = id_of(slot_a);
            let b = id_of(slot_b);
            if a == 0 || b == 0 || a == b { 1 } else { 0 }
        },
    )?;

    linker.func_wrap(
        module_name,
        "container_click",
        |mut caller: Caller<'_, DmodHostState>, slot: i32, button: i32, action: i32| -> i32 {
            caller.data_mut().pending_container_ops.push(DmodContainerOp {
                slot,
                button,
                action,
            });
            1
        },
    )?;

    linker.func_wrap(
        module_name,
        "container_put_one",
        |mut caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller.data_mut().pending_container_ops.push(DmodContainerOp {
                slot,
                button: 1,
                action: 5,
            });
            1
        },
    )?;

    linker.func_wrap(
        module_name,
        "container_quick_move",
        |mut caller: Caller<'_, DmodHostState>, slot: i32| -> i32 {
            caller.data_mut().pending_container_ops.push(DmodContainerOp {
                slot,
                button: 0,
                action: 1,
            });
            1
        },
    )?;

    linker.func_wrap(
        module_name,
        "container_sort",
        |mut caller: Caller<'_, DmodHostState>| -> i32 {
            caller.data_mut().pending_container_ops.push(DmodContainerOp {
                slot: -1,
                button: 0,
                action: 7,
            });
            1
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_mouse_tweaks_config",
        |mut caller: Caller<'_, DmodHostState>, rmb: i32, lmb_item: i32, lmb_shift: i32, wheel: i32| {
            let mut flags = 0u32;
            if rmb != 0 { flags |= 1; }
            if lmb_item != 0 { flags |= 2; }
            if lmb_shift != 0 { flags |= 4; }
            if wheel != 0 { flags |= 8; }
            caller.data_mut().mouse_tweaks_flags = flags;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_x",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().targeted_block[1] },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_y",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().targeted_block[2] },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_z",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().targeted_block[3] },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_id",
        |caller: Caller<'_, DmodHostState>| -> i32 {
            if caller.data().targeted_block[0] != 0 {
                caller.data().targeted_block[4]
            } else {
                0
            }
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_face",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().targeted_face },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_block_name",
        |mut caller: Caller<'_, DmodHostState>, out_ptr: i32, out_max: i32| -> i32 {
            let name = caller.data().targeted_block_name.clone();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let bytes = name.as_bytes();
                let write_len = bytes.len().min(out_max.max(0) as usize);
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                return write_len as i32;
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "raycast_block",
        |mut caller: Caller<'_, DmodHostState>, _max_dist: f32, out_ptr: i32| -> i32 {
            let tb = caller.data().targeted_block;
            let face = caller.data().targeted_face;
            if tb[0] == 0 {
                return 0;
            }
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let words = [tb[1], tb[2], tb[3], face, tb[4]];
                let mut bytes = [0u8; 20];
                for (i, w) in words.iter().enumerate() {
                    bytes[i * 4..(i + 1) * 4].copy_from_slice(&w.to_le_bytes());
                }
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes);
            }
            1
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_entity_id",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().targeted_entity_id },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_entity_health",
        |caller: Caller<'_, DmodHostState>| -> f32 { caller.data().targeted_entity_health },
    )?;

    linker.func_wrap(
        module_name,
        "get_targeted_entity_name",
        |mut caller: Caller<'_, DmodHostState>, out_ptr: i32, out_max: i32| -> i32 {
            let name = caller.data().targeted_entity_name.clone();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let bytes = name.as_bytes();
                let write_len = bytes.len().min(out_max.max(0) as usize);
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                return write_len as i32;
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "get_sky_light_level",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().sky_light },
    )?;

    linker.func_wrap(
        module_name,
        "get_block_light_level",
        |caller: Caller<'_, DmodHostState>| -> i32 { caller.data().block_light },
    )?;

    linker.func_wrap(
        module_name,
        "get_biome_name",
        |mut caller: Caller<'_, DmodHostState>, out_ptr: i32, out_max: i32| -> i32 {
            let name = caller.data().biome_name.clone();
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let bytes = name.as_bytes();
                let write_len = bytes.len().min(out_max.max(0) as usize);
                let _ = mem.write(&mut caller, out_ptr as usize, &bytes[..write_len]);
                return write_len as i32;
            }
            0
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_player_angles",
        |mut caller: Caller<'_, DmodHostState>, yaw: f32, pitch: f32| {
            caller.data_mut().pending_player_angles = Some([yaw, pitch.clamp(-90.0, 90.0)]);
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "add_player_velocity",
        |mut caller: Caller<'_, DmodHostState>, vx: f32, vy: f32, vz: f32| {
            let prev = caller.data().pending_velocity_add.unwrap_or([0.0; 3]);
            caller.data_mut().pending_velocity_add = Some([prev[0] + vx, prev[1] + vy, prev[2] + vz]);
            Ok(())
        },
    )?;



    linker.func_wrap(
        module_name,
        "swing_arm",
        |mut caller: Caller<'_, DmodHostState>| {
            caller.data_mut().pending_swing_arm = true;
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "send_chat",
        |mut caller: Caller<'_, DmodHostState>, ptr: i32, len: i32| {
            if let Some(Extern::Memory(mem)) = caller.get_export("memory") {
                let mut buf = vec![0u8; (len.max(0) as usize).min(256)];
                if mem.read(&caller, ptr as usize, &mut buf).is_ok() {
                    if let Ok(s) = std::str::from_utf8(&buf) {
                        caller.data_mut().pending_chat_sends.push(s.to_string());
                    }
                }
            }
            Ok(())
        },
    )?;

    linker.func_wrap(
        module_name,
        "set_window_aspect",
        |_caller: Caller<'_, DmodHostState>, aspect_milli: i32, stretch: i32| {
            horizon_client_render::gfx::set_window_aspect_mode(
                aspect_milli.max(0) as u32,
                stretch != 0,
            );
            Ok(())
        },
    )?;
    let _ = linker.func_wrap(
        module_name,
        "get_player_health_f32",
            |caller: Caller<'_, DmodHostState>| -> f32 { caller.data().player_hp },
        );
        let _ = linker.func_wrap(
            module_name,
            "get_player_max_health",
            |caller: Caller<'_, DmodHostState>| -> f32 { caller.data().player_max_hp.max(1.0) },
        );
        let _ = linker.func_wrap(
            module_name,
            "is_player_on_ground",
            |caller: Caller<'_, DmodHostState>| -> i32 { if (caller.data().player_flags & 1) != 0 { 1 } else { 0 } },
        );
        let _ = linker.func_wrap(
            module_name,
            "is_player_sneaking",
            |caller: Caller<'_, DmodHostState>| -> i32 { if (caller.data().player_flags & 2) != 0 { 1 } else { 0 } },
        );
        let _ = linker.func_wrap(
            module_name,
            "is_player_sprinting",
            |caller: Caller<'_, DmodHostState>| -> i32 { if (caller.data().player_flags & 4) != 0 { 1 } else { 0 } },
        );
        let _ = linker.func_wrap(
            module_name,
            "is_player_in_water",
            |caller: Caller<'_, DmodHostState>| -> i32 { if (caller.data().player_flags & 8) != 0 { 1 } else { 0 } },
        );

    Ok(())
}

fn is_safe_relative_entry_path(entry: &str) -> bool {
    let trimmed = entry.trim();
    !trimmed.is_empty()
        && !trimmed.starts_with('/')
        && !trimmed.starts_with('\\')
        && !trimmed.contains("..")
        && !trimmed.contains(':')
}

fn load_dmod_bytes(path: &Path) -> Result<(DmodManifest, Vec<u8>), String> {
    const MAX_MANIFEST_BYTES: u64 = 256 * 1024;
    const MAX_WASM_BYTES: u64 = 16 * 1024 * 1024;

    if path.is_dir() {
        let manifest_path = path.join("dmod.json");
        let manifest_bytes = std::fs::read(&manifest_path).map_err(|e| e.to_string())?;
        if manifest_bytes.len() as u64 > MAX_MANIFEST_BYTES {
            return Err("dmod.json exceeds maximum allowed size".to_string());
        }
        let manifest: DmodManifest =
            serde_json::from_slice(&manifest_bytes).map_err(|e| e.to_string())?;
        if !is_safe_relative_entry_path(&manifest.entry) {
            return Err(format!("Unsafe manifest entry path: {}", manifest.entry));
        }
        let wasm_path = path.join(&manifest.entry);
        let wasm_bytes = std::fs::read(&wasm_path).map_err(|e| e.to_string())?;
        if wasm_bytes.len() as u64 > MAX_WASM_BYTES {
            return Err("WASM module exceeds maximum allowed size".to_string());
        }
        return Ok((manifest, wasm_bytes));
    }
    let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;

    let mut manifest_bytes = Vec::new();
    {
        let manifest_file = archive.by_name("dmod.json").map_err(|e| e.to_string())?;
        if manifest_file.size() > MAX_MANIFEST_BYTES {
            return Err("dmod.json in archive exceeds maximum allowed size".to_string());
        }
        std::io::Read::read_to_end(
            &mut std::io::Read::take(manifest_file, MAX_MANIFEST_BYTES),
            &mut manifest_bytes,
        )
        .map_err(|e| e.to_string())?;
    }
    let manifest: DmodManifest =
        serde_json::from_slice(&manifest_bytes).map_err(|e| e.to_string())?;
    if !is_safe_relative_entry_path(&manifest.entry) {
        return Err(format!("Unsafe manifest entry path: {}", manifest.entry));
    }

    let mut wasm_bytes = Vec::new();
    {
        let wasm_file = archive
            .by_name(&manifest.entry)
            .map_err(|e| e.to_string())?;
        if wasm_file.size() > MAX_WASM_BYTES {
            return Err("WASM module in archive exceeds maximum allowed size".to_string());
        }
        std::io::Read::read_to_end(
            &mut std::io::Read::take(wasm_file, MAX_WASM_BYTES),
            &mut wasm_bytes,
        )
        .map_err(|e| e.to_string())?;
    }
    Ok((manifest, wasm_bytes))
}

fn sort_discovered_mods_topologically(
    discovered: &mut Vec<(PathBuf, DmodManifest, Vec<u8>)>,
) {
    discovered.sort_by(|a, b| a.1.id.cmp(&b.1.id));
    let n = discovered.len();
    if n <= 1 {
        return;
    }
    let id_to_idx: HashMap<String, usize> = discovered
        .iter()
        .enumerate()
        .map(|(i, (_, m, _))| (m.id.clone(), i))
        .collect();
    let mut adj: Vec<Vec<usize>> = vec![Vec::new(); n];
    let mut in_deg: Vec<usize> = vec![0; n];
    for (u, (_, m, _)) in discovered.iter().enumerate() {
        for dep in m.depends_on.iter().chain(m.load_after.iter()) {
            if let Some(&v) = id_to_idx.get(dep) {
                if v != u && !adj[v].contains(&u) {
                    adj[v].push(u);
                    in_deg[u] += 1;
                }
            }
        }
    }
    let mut ready: std::collections::BTreeSet<usize> = (0..n).filter(|&i| in_deg[i] == 0).collect();
    let mut order = Vec::with_capacity(n);
    while let Some(u) = ready.pop_first() {
        order.push(u);
        for &w in &adj[u] {
            in_deg[w] -= 1;
            if in_deg[w] == 0 {
                ready.insert(w);
            }
        }
    }
    if order.len() < n {
        for i in 0..n {
            if !order.contains(&i) {
                order.push(i);
            }
        }
    }
    let mut drained: Vec<Option<(PathBuf, DmodManifest, Vec<u8>)>> =
        discovered.drain(..).map(Some).collect();
    for idx in order {
        if let Some(item) = drained[idx].take() {
            discovered.push(item);
        }
    }
}

fn read_disabled_mod_ids(game_dir: &Path) -> HashSet<String> {
    let mut disabled = HashSet::new();
    for file_name in ["diamond-mods.txt", "horizon-mods.txt"] {
        let path = game_dir.join(file_name);
        if let Ok(text) = std::fs::read_to_string(&path) {
            for raw_line in text.lines() {
                let line = raw_line.trim();
                if line.is_empty() || line.starts_with('#') {
                    continue;
                }
                let stripped = line.strip_prefix("mod.").unwrap_or(line);
                if let Some((id, state)) = stripped.split_once(':') {
                    let id = id.trim();
                    let state = state.trim();
                    if state.eq_ignore_ascii_case("false") || state == "0" {
                        disabled.insert(id.to_string());
                    } else if state.eq_ignore_ascii_case("true") || state == "1" {
                        disabled.remove(id);
                    }
                } else if let Some(rest) = stripped.strip_prefix('!') {
                    disabled.insert(rest.trim().to_string());
                } else {
                    disabled.remove(stripped);
                }
            }
        }
    }
    disabled
}

impl DmodManager {
    pub fn scan_manifests(game_dir: &Path) -> Vec<DmodManifest> {
        let candidate_dirs = [
            game_dir.join("diamond-mods"),
            game_dir.join("mods"),
            game_dir.join("horizon-mods"),
        ];
        let mut out = Vec::new();
        for dir in &candidate_dirs {
            if let Ok(entries) = std::fs::read_dir(dir) {
                for entry in entries.flatten() {
                    let path = entry.path();
                    let is_dmod_file = path.extension().is_some_and(|e| e == "dmod");
                    let is_dmod_dir = path.is_dir() && path.join("dmod.json").exists();
                    if is_dmod_file || is_dmod_dir {
                        if let Ok((manifest, _)) = load_dmod_bytes(&path) {
                            if !out.iter().any(|m: &DmodManifest| m.id == manifest.id) {
                                out.push(manifest);
                            }
                        }
                    }
                }
            }
        }
        out
    }

    pub fn new(game_dir: PathBuf) -> Self {
        let mut manager = Self {
            game_dir,
            instances: Vec::new(),
            disabled_ids: HashSet::new(),
            installed_manifests: Vec::new(),
            tick_count: 0,
            cached_debug_lines: Vec::new(),
            load_errors: HashMap::new(),
            camera_yaw_offset: 0.0,
            camera_pitch_offset: 0.0,
            camera_roll_deg: 0.0,
            camera_pos_offset: [0.0; 3],
            fov_scale: 1.0,
            fog_density: 0.0,
            fog_color: [0.0; 4],
            sky_override: None,
            vignette: [0.0; 4],
            fullbright_override: false,
            gamma_override: None,
            last_container_hash: 0,
        };
        manager.reload();
        manager
    }

    pub fn reload(&mut self) {
        self.instances.clear();
        self.installed_manifests.clear();
        self.load_errors.clear();
        self.camera_yaw_offset = 0.0;
        self.camera_pitch_offset = 0.0;
        self.camera_roll_deg = 0.0;
        self.camera_pos_offset = [0.0; 3];
        self.fov_scale = 1.0;
        self.fog_density = 0.0;
        self.fog_color = [0.0; 4];
        self.sky_override = None;
        self.vignette = [0.0; 4];
        self.fullbright_override = false;
        self.gamma_override = None;

        let candidate_dirs = [
            self.game_dir.join("diamond-mods"),
            self.game_dir.join("mods"),
            self.game_dir.join("horizon-mods"),
        ];

        let mut discovered: Vec<(PathBuf, DmodManifest, Vec<u8>)> = Vec::new();
        for dir in &candidate_dirs {
            if let Ok(entries) = std::fs::read_dir(dir) {
                for entry in entries.flatten() {
                    let path = entry.path();
                    let is_dmod_file = path.extension().is_some_and(|e| e == "dmod");
                    let is_dmod_dir = path.is_dir() && path.join("dmod.json").exists();
                    if is_dmod_file || is_dmod_dir {
                        if let Ok((manifest, wasm_bytes)) = load_dmod_bytes(&path) {
                            if !discovered.iter().any(|(_, m, _)| m.id == manifest.id) {
                                discovered.push((path, manifest, wasm_bytes));
                            }
                        }
                    }
                }
            }
        }

        sort_discovered_mods_topologically(&mut discovered);
        let all_loaded_ids: HashSet<String> =
            discovered.iter().map(|(_, m, _)| m.id.clone()).collect();
        for (_, m, _) in &discovered {
            self.installed_manifests.push(m.clone());
        }

        self.disabled_ids = read_disabled_mod_ids(&self.game_dir);

        let engine = Engine::default();
        for (_, manifest, wasm_bytes) in discovered {
            let module = match Module::new(&engine, &wasm_bytes) {
                Ok(m) => m,
                Err(e) => {
                    log::warn!("[dmod] Failed to compile {}: {}", manifest.id, e);
                    self.load_errors.insert(manifest.id.clone(), format!("Wasm compile error: {e}"));
                    continue;
                }
            };

            let mut preferred_mask = 0u8;
            for imp in module.imports() {
                if let wasmi::ExternType::Func(ft) = imp.ty() {
                    let params = ft.params();
                    match imp.name() {
                        "log" if params.len() == 3 => preferred_mask |= 1,
                        "hud_text" if params.len() == 6 && params[5] == wasmi::core::ValType::I32 => preferred_mask |= 2,
                        "register_setting_button" if params.len() == 2 => preferred_mask |= 4,
                        "set_camera_pose" if params.len() == 6 => preferred_mask |= 8,
                        _ => {}
                    }
                }
            }
            let mut masks = vec![preferred_mask];
            for m in 0u8..16u8 {
                if m != preferred_mask {
                    masks.push(m);
                }
            }
            let mut instantiated: Option<(Store<DmodHostState>, Instance)> = None;
            let mut last_err = String::new();
            for mask in masks {
                let mut linker = Linker::<DmodHostState>::new(&engine);
                let _ = add_host_funcs(&mut linker, "diamond", mask);
                let _ = add_host_funcs(&mut linker, "env", mask);

                let mut host_state = DmodHostState::default();
                host_state.mod_id = manifest.id.clone();
                host_state.loaded_mod_ids = all_loaded_ids.clone();
                let kv_path = self.game_dir.join("diamond-mod-kv").join(format!("{}.json", manifest.id));
                if let Ok(raw) = std::fs::read_to_string(&kv_path) {
                    if let Ok(map) = serde_json::from_str::<HashMap<String, String>>(&raw) {
                        host_state.kv_store = map;
                    }
                }
                host_state.kv_file = Some(kv_path);
                let att_path = self.game_dir.join("diamond-attachments").join(format!("{}.json", manifest.id));
                if let Ok(raw_att) = std::fs::read_to_string(&att_path) {
                    if let Ok(map) = serde_json::from_str::<HashMap<String, String>>(&raw_att) {
                        host_state.attachments = map;
                    }
                }
                host_state.attachments_file = Some(att_path);
                host_state.keybinds_file = Some(self.game_dir.join("diamond-keybinds.json"));

                let mut store = Store::new(&engine, host_state);
                for imp in module.imports() {
                    if let wasmi::ExternType::Func(expected_ft) = imp.ty() {
                        let needs_stub = match linker.get(&store, imp.module(), imp.name()) {
                            Some(wasmi::Extern::Func(f)) => f.ty(&store) != *expected_ft,
                            _ => true,
                        };
                        if needs_stub && linker.get(&store, imp.module(), imp.name()).is_none() {
                            let ft_clone = expected_ft.clone();
                            let stub = wasmi::Func::new(
                                &mut store,
                                ft_clone,
                                |_caller, _params, results| {
                                    for r in results.iter_mut() {
                                        *r = match &*r {
                                            wasmi::Val::I32(_) => wasmi::Val::I32(0),
                                            wasmi::Val::I64(_) => wasmi::Val::I64(0),
                                            wasmi::Val::F32(_) => wasmi::Val::F32(0.0f32.into()),
                                            wasmi::Val::F64(_) => wasmi::Val::F64(0.0f64.into()),
                                            other => other.clone(),
                                        };
                                    }
                                    Ok(())
                                },
                            );
                            let _ = linker.define(imp.module(), imp.name(), stub);
                        }
                    }
                }
                match linker.instantiate(&mut store, &module) {
                    Ok(pre) => match pre.start(&mut store) {
                        Ok(started) => {
                            instantiated = Some((store, started));
                            break;
                        }
                        Err(e) => {
                            last_err = e.to_string();
                        }
                    },
                    Err(e) => {
                        last_err = e.to_string();
                    }
                }
            }

            let Some((mut store, instance)) = instantiated else {
                log::warn!("[dmod] Failed to instantiate {}: {}", manifest.id, last_err);
                self.load_errors.insert(manifest.id.clone(), format!("Wasm link/start error: {last_err}"));
                continue;
            };

            let is_enabled_on_load = !self.disabled_ids.contains(&manifest.id);
            if is_enabled_on_load {
                if let Ok(init_func) = instance.get_typed_func::<(), ()>(&store, "dmod_init") {
                    let _ = init_func.call(&mut store, ());
                }
            }
            let mod_settings_path = self.game_dir.join("diamond-mod-settings.json");
            if let Ok(text) = std::fs::read_to_string(&mod_settings_path) {
                if let Ok(json) = serde_json::from_str::<serde_json::Value>(&text) {
                    let buttons = store.data().setting_buttons.clone();
                    for b in buttons {
                        let alias_key = match b.key.as_str() {
                            "toggle_horror" => "horror_optimizer.horror",
                            "toggle_optimizer" => "horror_optimizer.optimizer",
                            "toggle_vhs" => "horror_optimizer.vhs",
                            "mt_wheel" => "mouse_tweaks.wheel",
                            _ => "",
                        };
                        let wanted_opt = json
                            .get(&b.key)
                            .and_then(|v| v.as_bool())
                            .or_else(|| {
                                if alias_key.is_empty() {
                                    None
                                } else {
                                    json.get(alias_key).and_then(|v| v.as_bool())
                                }
                            });
                        if let Some(wanted) = wanted_opt {
                            let label_up = b.label.to_uppercase();
                            let currently_on = label_up.contains(": ON") || label_up.contains(": ENABLED");
                            let currently_off = label_up.contains(": OFF") || label_up.contains(": DISABLED");
                            if (wanted && currently_off) || (!wanted && currently_on) {
                                if let Ok(click_fn) = instance.get_typed_func::<i32, ()>(&store, "dmod_settings_click") {
                                    let _ = click_fn.call(&mut store, b.id);
                                } else if let Ok(click_fn2) = instance.get_typed_func::<i32, ()>(&store, "dmod_on_setting_button") {
                                    let _ = click_fn2.call(&mut store, b.id);
                                }
                            }
                        }
                    }
                }
            }

            let active = !self.disabled_ids.contains(&manifest.id);
            log::info!(
                "[dmod] Loaded {} v{} (active={})",
                manifest.id,
                manifest.version,
                active
            );

            self.instances.push(DmodInstance {
                manifest,
                store,
                instance,
                active,
            });
        }
        let err_file = self.game_dir.join("dmod-load-errors.txt");
        if self.load_errors.is_empty() {
            let _ = std::fs::remove_file(&err_file);
        } else {
            let mut lines = Vec::new();
            for (mod_id, reason) in &self.load_errors {
                let clean = reason.replace('\n', " ").replace('|', "/");
                lines.push(format!("{mod_id}|{clean}"));
            }
            let _ = std::fs::write(&err_file, lines.join("\n"));
        }
    }

    pub fn sync_disabled(&mut self, disabled: & std::collections::BTreeSet<String>) {
        let mut any_changed = false;
        for inst in &mut self.instances {
            let next = !disabled.contains(&inst.manifest.id);
            if inst.active != next {
                inst.active = next;
                if !next {
                    let d = inst.store.data_mut();
                    d.fog_density = 0.0;
                    d.fog_color = [0.0; 4];
                    d.vignette = [0.0; 4];
                    d.sky_override = None;
                    d.fullbright = false;
                    d.camera_yaw_offset = 0.0;
                    d.camera_pitch_offset = 0.0;
                    d.camera_roll_deg = 0.0;
                    d.camera_pos_offset = [0.0; 3];
                    d.fov_scale = 1.0;
                    d.hud_rects.clear();
                    d.hud_sprites.clear();
                    d.hud_texts.clear();
                }
                any_changed = true;
            }
        }
        if any_changed {
            horizon_client_render::gfx::set_vhs_fisheye(false);
            horizon_client_render::gfx::set_post_affect_ui(false);
            horizon_client_render::gfx::clear_custom_post_shader();
            horizon_client_render::gfx::set_builtin_shader(false, 0.0);
            let game_dir = self.game_dir.clone();
            for inst in &mut self.instances {
                if inst.active {
                    if let Ok(init_fn) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_init") {
                        let _ = init_fn.call(&mut inst.store, ());
                    }
                    Self::reapply_saved_settings_for(&game_dir, &inst.instance, &mut inst.store);
                }
            }
        }
    }

    pub fn dispatch_chunk_load(&mut self, chunk_x: i32, chunk_z: i32) {
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32), ()>(&inst.store, "dmod_on_chunk_load") {
                let _ = func.call(&mut inst.store, (chunk_x, chunk_z));
            }
        }
    }

    pub fn dispatch_shutdown(&mut self) {
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_on_shutdown") {
                let _ = func.call(&mut inst.store, ());
            }
        }
    }

    pub fn dispatch_imc_messages(&mut self) {
        let mut queue: Vec<(String, String, String, String)> = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let sender = inst.manifest.id.clone();
            for (target, method, payload) in inst.store.data_mut().pending_imc.drain(..) {
                queue.push((sender.clone(), target, method, payload));
            }
        }
        for (sender, target, method, payload) in queue {
            for inst in &mut self.instances {
                if !inst.active || (target != "*" && inst.manifest.id != target) {
                    continue;
                }
                if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32, i32, i32), ()>(&inst.store, "dmod_on_imc_message") {
                    if let Some(Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                        let base = 4096usize;
                        let sb = sender.as_bytes();
                        let mb = method.as_bytes();
                        let pb = payload.as_bytes();
                        let o1 = base;
                        let o2 = o1 + sb.len();
                        let o3 = o2 + mb.len();
                        if mem.write(&mut inst.store, o1, sb).is_ok()
                            && mem.write(&mut inst.store, o2, mb).is_ok()
                            && mem.write(&mut inst.store, o3, pb).is_ok()
                        {
                            let _ = func.call(
                                &mut inst.store,
                                (o1 as i32, sb.len() as i32, o2 as i32, mb.len() as i32, o3 as i32, pb.len() as i32),
                            );
                        }
                    }
                }
            }
        }
    }

    pub fn dispatch_custom_payload(&mut self, channel: &str, payload: &[u8]) {
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32), ()>(&inst.store, "dmod_on_custom_payload") {
                if let Some(Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    let ch_bytes = channel.as_bytes();
                    let ch_len = ch_bytes.len().min(128);
                    let pl_len = payload.len().min(4096);
                    let ch_ptr = 4096usize;
                    let pl_ptr = 4224usize;
                    if mem.write(&mut inst.store, ch_ptr, &ch_bytes[..ch_len]).is_ok()
                        && mem.write(&mut inst.store, pl_ptr, &payload[..pl_len]).is_ok()
                    {
                        let _ = func.call(&mut inst.store, (ch_ptr as i32, ch_len as i32, pl_ptr as i32, pl_len as i32));
                    }
                }
            }
        }
    }

    pub fn load_error_for(&self, mod_id: &str) -> Option<&str> {
        self.load_errors.get(mod_id).map(|s| s.as_str())
    }

    pub fn drain_sounds(&mut self) -> (Vec<(String, f32, f32)>, bool) {
        let mut sounds = Vec::new();
        let mut stop_all = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let d = inst.store.data_mut();
            sounds.extend(d.pending_sounds.drain(..));
            if d.pending_stop_sounds {
                d.pending_stop_sounds = false;
                stop_all = true;
            }
        }
        (sounds, stop_all)
    }

    pub fn tick(&mut self) {
        self.tick_with_debug(false);
    }

    pub fn tick_with_debug(&mut self, debug_open: bool) {
        self.tick_count = self.tick_count.wrapping_add(1);
        let tc = self.tick_count;
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst.instance.get_typed_func::<(i32,), ()>(&inst.store, "dmod_tick") {
                let _ = func.call(&mut inst.store, (tc,));
            } else if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_tick") {
                let _ = func.call(&mut inst.store, ());
            }
        }
        if debug_open {
            self.cached_debug_lines = self.debug_lines();
        } else if !self.cached_debug_lines.is_empty() {
            self.cached_debug_lines.clear();
        }
    }

    pub fn camera(&mut self, partial: f32) {
        self.camera_yaw_offset = 0.0;
        self.camera_pitch_offset = 0.0;
        self.camera_roll_deg = 0.0;
        self.camera_pos_offset = [0.0; 3];
        self.fov_scale = 1.0;
        self.fog_density = 0.0;
        self.fog_color = [0.0; 4];
        self.sky_override = None;
        self.vignette = [0.0; 4];
        self.fullbright_override = false;
        self.gamma_override = None;

        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            let (speed, on_ground, sneaking) = {
                let d = inst.store.data();
                let v = d.player_vel;
                let spd = ((v[0] * v[0] + v[2] * v[2]).sqrt()) as f32;
                let gnd = if (d.player_flags & 1) != 0 { 1 } else { 0 };
                let snk = if (d.player_flags & 4) != 0 { 1 } else { 0 };
                (spd, gnd, snk)
            };
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(f32, f32, i32, i32), ()>(&inst.store, "dmod_camera")
            {
                let _ = func.call(&mut inst.store, (partial, speed, on_ground, sneaking));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(f32,), ()>(&inst.store, "dmod_camera")
            {
                let _ = func.call(&mut inst.store, (partial,));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(), ()>(&inst.store, "dmod_camera")
            {
                let _ = func.call(&mut inst.store, ());
            }

            if let Ok(wfunc) = inst
                .instance
                .get_typed_func::<(f32,), ()>(&inst.store, "dmod_world_render")
            {
                let _ = wfunc.call(&mut inst.store, (partial,));
            } else if let Ok(wfunc) = inst
                .instance
                .get_typed_func::<(), ()>(&inst.store, "dmod_world_render")
            {
                let _ = wfunc.call(&mut inst.store, ());
            }

            let data = inst.store.data();
            self.camera_yaw_offset += data.camera_yaw_offset;
            self.camera_pitch_offset += data.camera_pitch_offset;
            self.camera_roll_deg += data.camera_roll_deg;
            self.camera_pos_offset[0] += data.camera_pos_offset[0];
            self.camera_pos_offset[1] += data.camera_pos_offset[1];
            self.camera_pos_offset[2] += data.camera_pos_offset[2];
            self.fov_scale *= data.fov_scale;
            if data.fog_density > self.fog_density {
                self.fog_density = data.fog_density;
                self.fog_color = data.fog_color;
            }
            if let Some(sky) = data.sky_override {
                self.sky_override = Some(sky);
            }
            if data.vignette[3] > self.vignette[3] {
                self.vignette = data.vignette;
            }
            if data.fullbright {
                self.fullbright_override = true;
            }
            if (data.gamma - 1.0).abs() > 0.01 {
                self.gamma_override = Some(data.gamma);
            }
        }
    }

    pub fn hud(&mut self) -> (Vec<DmodHudRect>, Vec<DmodHudText>) {
        let (r, _, t) = self.hud_sized_full(0.0, 0.0);
        (r, t)
    }

    pub fn hud_sized(&mut self, sw: f32, sh: f32) -> (Vec<DmodHudRect>, Vec<DmodHudText>) {
        let (r, _, t) = self.hud_sized_full(sw, sh);
        (r, t)
    }

    pub fn hud_sized_full(&mut self, sw: f32, sh: f32) -> (Vec<DmodHudRect>, Vec<DmodHudSprite>, Vec<DmodHudText>) {
        let mut all_rects = Vec::new();
        let mut all_sprites = Vec::new();
        let mut all_texts = Vec::new();

        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            let w = if sw > 0.0 {
                sw
            } else {
                inst.store.data().window_width as f32
            };
            let h = if sh > 0.0 {
                sh
            } else {
                inst.store.data().window_height as f32
            };
            inst.store.data_mut().hud_rects.clear();
            inst.store.data_mut().hud_sprites.clear();
            inst.store.data_mut().hud_texts.clear();

            if let Ok(func) = inst
                .instance
                .get_typed_func::<(f32, f32), ()>(&inst.store, "dmod_hud")
            {
                let _ = func.call(&mut inst.store, (w, h));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(), ()>(&inst.store, "dmod_hud")
            {
                let _ = func.call(&mut inst.store, ());
            }
            let data = inst.store.data_mut();
            all_rects.extend(data.hud_rects.drain(..));
            all_sprites.extend(data.hud_sprites.drain(..));
            all_texts.extend(data.hud_texts.drain(..));
        }
        (all_rects, all_sprites, all_texts)
    }

    pub fn pre_hud_sized_full(&mut self, sw: f32, sh: f32) -> (Vec<DmodHudRect>, Vec<DmodHudSprite>, Vec<DmodHudText>) {
        let mut all_rects = Vec::new();
        let mut all_sprites = Vec::new();
        let mut all_texts = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let w = if sw > 0.0 { sw } else { inst.store.data().window_width as f32 };
            let h = if sh > 0.0 { sh } else { inst.store.data().window_height as f32 };
            inst.store.data_mut().hud_rects.clear();
            inst.store.data_mut().hud_sprites.clear();
            inst.store.data_mut().hud_texts.clear();
            if let Ok(func) = inst.instance.get_typed_func::<(f32, f32), ()>(&inst.store, "dmod_pre_hud") {
                let _ = func.call(&mut inst.store, (w, h));
            } else if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_pre_hud") {
                let _ = func.call(&mut inst.store, ());
            }
            let data = inst.store.data_mut();
            all_rects.extend(data.hud_rects.drain(..));
            all_sprites.extend(data.hud_sprites.drain(..));
            all_texts.extend(data.hud_texts.drain(..));
        }
        (all_rects, all_sprites, all_texts)
    }

    pub fn screen_render_full(&mut self, sw: f32, sh: f32, screen_id: i32) -> (Vec<DmodHudRect>, Vec<DmodHudSprite>, Vec<DmodHudText>) {
        let mut all_rects = Vec::new();
        let mut all_sprites = Vec::new();
        let mut all_texts = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let w = if sw > 0.0 { sw } else { inst.store.data().window_width as f32 };
            let h = if sh > 0.0 { sh } else { inst.store.data().window_height as f32 };
            inst.store.data_mut().hud_rects.clear();
            inst.store.data_mut().hud_sprites.clear();
            inst.store.data_mut().hud_texts.clear();
            inst.store.data_mut().screen_buttons.clear();
            if let Ok(func) = inst.instance.get_typed_func::<(f32, f32, i32), ()>(&inst.store, "dmod_on_screen_render") {
                let _ = func.call(&mut inst.store, (w, h, screen_id));
            }
            let data = inst.store.data_mut();
            all_rects.extend(data.hud_rects.drain(..));
            all_sprites.extend(data.hud_sprites.drain(..));
            all_texts.extend(data.hud_texts.drain(..));
        }
        (all_rects, all_sprites, all_texts)
    }

    pub fn update_world_env(&mut self, difficulty: i32, raining: bool, thundering: bool, gui_ticks: i32, server_addr: &str) {
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            d.difficulty = difficulty;
            d.is_raining = raining;
            d.is_thundering = thundering;
            d.gui_ticks = gui_ticks;
            if d.server_address != server_addr {
                d.server_address.clear();
                d.server_address.push_str(server_addr);
            }
        }
    }

    pub fn on_chat_receive(&mut self, msg: &str) -> bool {
        let mut cancelled = false;
        let bytes = msg.as_bytes();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32), i32>(&inst.store, "dmod_on_chat_receive") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    let base = 4096usize;
                    let n = bytes.len().min(2048);
                    if mem.write(&mut inst.store, base, &bytes[..n]).is_ok() {
                        if let Ok(res) = func.call(&mut inst.store, (base as i32, n as i32)) {
                            if res != 0 { cancelled = true; }
                        }
                    }
                }
            }
        }
        cancelled
    }

    pub fn on_chat_send(&mut self, msg: &str) -> bool {
        let mut cancelled = false;
        let bytes = msg.as_bytes();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32), i32>(&inst.store, "dmod_on_chat_send") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    let base = 4096usize;
                    let n = bytes.len().min(2048);
                    if mem.write(&mut inst.store, base, &bytes[..n]).is_ok() {
                        if let Ok(res) = func.call(&mut inst.store, (base as i32, n as i32)) {
                            if res != 0 { cancelled = true; }
                        }
                    }
                }
            }
        }
        cancelled
    }

    pub fn on_attack_block(&mut self, x: i32, y: i32, z: i32, face: i32) -> bool {
        let mut cancelled = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32), i32>(&inst.store, "dmod_on_attack_block") {
                if let Ok(res) = func.call(&mut inst.store, (x, y, z, face)) {
                    if res != 0 { cancelled = true; }
                }
            }
        }
        cancelled
    }

    pub fn on_use_item(&mut self, hand: i32) -> bool {
        let mut cancelled = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<i32, i32>(&inst.store, "dmod_on_use_item") {
                if let Ok(res) = func.call(&mut inst.store, hand) {
                    if res != 0 { cancelled = true; }
                }
            }
        }
        cancelled
    }

    pub fn drain_pending_payloads(&mut self) -> Vec<(String, Vec<u8>)> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            out.extend(inst.store.data_mut().pending_payloads.drain(..));
        }
        out
    }

    pub fn try_client_command(&mut self, raw: &str) -> bool {
        let trimmed = raw.trim();
        let mut parts = trimmed.splitn(2, char::is_whitespace);
        let cmd = parts.next().unwrap_or("").to_ascii_lowercase();
        let args = parts.next().unwrap_or("").trim();
        if cmd.is_empty() { return false; }
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if !inst.store.data().client_commands.contains(&cmd) { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32), i32>(&inst.store, "dmod_on_client_command") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    let cb = cmd.as_bytes();
                    let ab = args.as_bytes();
                    let cn = cb.len().min(256);
                    let an = ab.len().min(1024);
                    if mem.write(&mut inst.store, 4096, &cb[..cn]).is_ok()
                        && mem.write(&mut inst.store, 4352, &ab[..an]).is_ok()
                    {
                        if let Ok(res) = func.call(&mut inst.store, (4096, cn as i32, 4352, an as i32)) {
                            if res != 0 { return true; }
                        }
                    }
                }
            }
        }
        false
    }

    pub fn dispatch_keybind(&mut self, key_code: i32) -> bool {
        let mut handled = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let matched: Vec<String> = inst.store.data().keybinds.iter()
                .filter(|k| k.3 == key_code)
                .map(|k| k.0.clone())
                .collect();
            if matched.is_empty() { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32), ()>(&inst.store, "dmod_on_keybind") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    for id in matched {
                        let b = id.as_bytes();
                        let n = b.len().min(256);
                        if mem.write(&mut inst.store, 4096, &b[..n]).is_ok() {
                            let _ = func.call(&mut inst.store, (4096, n as i32));
                            handled = true;
                        }
                    }
                }
            }
        }
        handled
    }

    pub fn item_tooltip_lines(&mut self, item_id: &str, count: i32, shift: bool, advanced: bool) -> Vec<(String, u32)> {
        let mut out = Vec::new();
        let flags = (i32::from(shift)) | (i32::from(advanced) << 1) | (i32::from(shift || advanced) << 2);
        let bytes = item_id.as_bytes();
        let n = bytes.len().min(256);
        for inst in &mut self.instances {
            if !inst.active { continue; }
            inst.store.data_mut().tooltip_extra_lines.clear();
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32), ()>(&inst.store, "dmod_on_item_tooltip") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    if mem.write(&mut inst.store, 4096, &bytes[..n]).is_ok() {
                        let _ = func.call(&mut inst.store, (4096, n as i32, count, flags));
                    }
                }
            }
            out.extend(inst.store.data_mut().tooltip_extra_lines.drain(..));
        }
        out
    }

    pub fn collect_data_pack_files(&self, out: &mut Vec<(String, Vec<u8>)>) {
        for inst in &self.instances {
            if !inst.active { continue; }
            for (path, bytes) in &inst.store.data().data_pack_files {
                out.push((path.clone(), bytes.clone()));
            }
        }
    }

    pub fn drain_particles(&mut self) -> Vec<(String, [f64; 3], [f64; 3])> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            out.extend(inst.store.data_mut().pending_particles.drain(..));
        }
        out
    }

    pub fn on_block_break(&mut self, x: i32, y: i32, z: i32) -> bool {
        let mut cancelled = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32), i32>(&inst.store, "dmod_on_block_break") {
                if let Ok(res) = func.call(&mut inst.store, (x, y, z)) {
                    if res != 0 { cancelled = true; }
                }
            }
        }
        cancelled
    }

    pub fn on_interact_entity(&mut self, entity_id: i32, kind: &str, hand: i32) -> bool {
        let mut claimed = false;
        let bytes = kind.as_bytes();
        let n = bytes.len().min(256);
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32), i32>(&inst.store, "dmod_on_interact_entity") {
                if let Some(wasmi::Extern::Memory(mem)) = inst.instance.get_export(&inst.store, "memory") {
                    if mem.write(&mut inst.store, 4096, &bytes[..n]).is_ok() {
                        if let Ok(res) = func.call(&mut inst.store, (entity_id, 4096, n as i32, hand)) {
                            if res != 0 { claimed = true; }
                        }
                    }
                }
            }
        }
        claimed
    }

    pub fn world_render(&mut self, partial: f32) -> (Vec<DmodWorldModel>, Vec<DmodWorldCuboid>, Vec<DmodWorldText>) {
        let mut out_m = Vec::new();
        let mut out_c = Vec::new();
        let mut out_t = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            inst.store.data_mut().world_models.clear();
            inst.store.data_mut().world_cuboids.clear();
            inst.store.data_mut().world_texts.clear();
            if let Ok(func) = inst.instance.get_typed_func::<f32, ()>(&inst.store, "dmod_world_render") {
                let _ = func.call(&mut inst.store, partial);
            } else if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_world_render") {
                let _ = func.call(&mut inst.store, ());
            }
            let d = inst.store.data_mut();
            out_m.extend(d.world_models.drain(..));
            out_c.extend(d.world_cuboids.drain(..));
            out_t.extend(d.world_texts.drain(..));
        }
        (out_m, out_c, out_t)
    }

    pub fn client_command_names(&self) -> Vec<String> {
        let mut out = Vec::new();
        for inst in &self.instances {
            if !inst.active { continue; }
            for c in &inst.store.data().client_commands {
                if !out.contains(c) { out.push(c.clone()); }
            }
        }
        out
    }

    pub fn dispatch_world_events(&mut self) {
        let block_ev: Vec<_> = DMOD_BLOCK_CHANGES
            .get()
            .and_then(|m| m.lock().ok().map(|mut g| g.drain(..).collect()))
            .unwrap_or_default();
        let fluid_ev: Vec<_> = DMOD_FLUID_CHANGES
            .get()
            .and_then(|m| m.lock().ok().map(|mut g| g.drain(..).collect()))
            .unwrap_or_default();
        if block_ev.is_empty() && fluid_ev.is_empty() { return; }
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if !block_ev.is_empty() {
                if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32, i32), ()>(&inst.store, "dmod_on_block_changed") {
                    for &(pos, old_id, new_id) in &block_ev {
                        let _ = func.call(&mut inst.store, (pos[0], pos[1], pos[2], old_id as i32, new_id as i32));
                    }
                }
            }
            if !fluid_ev.is_empty() {
                if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32, i32, i32), ()>(&inst.store, "dmod_on_fluid_changed") {
                    for &(pos, from_l, to_l) in &fluid_ev {
                        let _ = func.call(&mut inst.store, (pos[0], pos[1], pos[2], from_l, to_l));
                    }
                }
            }
        }
    }

    pub fn on_block_place(&mut self, x: i32, y: i32, z: i32) -> bool {
        let mut cancelled = false;
        for inst in &mut self.instances {
            if !inst.active { continue; }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, i32, i32), i32>(&inst.store, "dmod_on_block_place") {
                if let Ok(res) = func.call(&mut inst.store, (x, y, z)) {
                    if res != 0 { cancelled = true; }
                }
            }
        }
        cancelled
    }

    pub fn update_world_probes(
        &mut self,
        blocks: HashMap<(i32, i32, i32), String>,
        entity_count: i32,
        nearest: Option<(i32, [f64; 3], f32)>,
    ) {
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            d.local_blocks = blocks.clone();
            d.nearby_entity_count = entity_count;
            d.nearest_entity = nearest;
        }
    }

    pub fn screen_buttons(&self) -> Vec<DmodScreenButton> {
        let mut out = Vec::new();
        for inst in &self.instances {
            if !inst.active { continue; }
            out.extend(inst.store.data().screen_buttons.iter().cloned());
        }
        out
    }

    pub fn click_screen_button(&mut self, mx: f32, my: f32) -> bool {
        for inst in &mut self.instances {
            if !inst.active { continue; }
            let hit = inst.store.data().screen_buttons.iter()
                .find(|b| mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h)
                .map(|b| b.id);
            if let Some(id) = hit {
                if let Ok(func) = inst.instance.get_typed_func::<i32, ()>(&inst.store, "dmod_on_screen_button") {
                    let _ = func.call(&mut inst.store, id);
                }
                return true;
            }
        }
        false
    }

    pub fn drain_world_commands(&mut self) -> Vec<String> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            out.extend(inst.store.data_mut().pending_world_commands.drain(..));
        }
        out
    }

    pub fn drain_world_sounds(&mut self) -> Vec<(String, [f64; 3], f32, f32)> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if !inst.active { continue; }
            out.extend(inst.store.data_mut().pending_world_sounds.drain(..));
        }
        out
    }

    pub fn update_food_snapshot(
        &mut self,
        saturation: f32,
        exhaustion: f32,
        absorption: f32,
        tick_count: i64,
        hardcore: bool,
        status_mask: i32,
        armor: i32,
        mounted_health: bool,
        main_food: DmodFoodInfo,
        off_food: DmodFoodInfo,
    ) {
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            d.player_saturation = saturation;
            d.player_exhaustion = exhaustion;
            d.player_absorption = absorption;
            d.tick_count = tick_count;
            d.is_hardcore = hardcore;
            d.player_status_mask = status_mask;
            d.player_armor = armor;
            d.mounted_with_health = mounted_health;
            d.held_food = [main_food, off_food];
        }
    }

    pub fn tooltip_size(&mut self, food: DmodFoodInfo) -> [f32; 2] {
        if !food.is_food {
            return [0.0, 0.0];
        }
        let mut total_w: f32 = 0.0;
        let mut total_h: f32 = 0.0;
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst.instance.get_typed_func::<(i32, f32, i32, i32, f32), i64>(&inst.store, "dmod_on_tooltip_size") {
                if let Ok(packed) = func.call(&mut inst.store, (
                    food.nutrition as i32,
                    food.saturation,
                    i32::from(food.can_always_eat),
                    i32::from(food.is_rotten),
                    food.regen_hp,
                )) {
                    let w = ((packed >> 16) & 0xFFFF) as f32;
                    let h = (packed & 0xFFFF) as f32;
                    total_w = total_w.max(w);
                    total_h += h;
                }
            }
        }
        [total_w, total_h]
    }

    pub fn tooltip_draw(&mut self, food: DmodFoodInfo, x: f32, y: f32) -> (Vec<DmodHudRect>, Vec<DmodHudSprite>, Vec<DmodHudText>) {
        let mut all_rects = Vec::new();
        let mut all_sprites = Vec::new();
        let mut all_texts = Vec::new();
        if !food.is_food {
            return (all_rects, all_sprites, all_texts);
        }
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            inst.store.data_mut().hud_rects.clear();
            inst.store.data_mut().hud_sprites.clear();
            inst.store.data_mut().hud_texts.clear();
            if let Ok(func) = inst.instance.get_typed_func::<(f32, f32, i32, f32, i32, i32, f32), ()>(&inst.store, "dmod_on_tooltip_draw") {
                let _ = func.call(&mut inst.store, (
                    x,
                    y,
                    food.nutrition as i32,
                    food.saturation,
                    i32::from(food.can_always_eat),
                    i32::from(food.is_rotten),
                    food.regen_hp,
                ));
            }
            let d = inst.store.data_mut();
            all_rects.extend(d.hud_rects.drain(..));
            all_sprites.extend(d.hud_sprites.drain(..));
            all_texts.extend(d.hud_texts.drain(..));
        }
        (all_rects, all_sprites, all_texts)
    }

    pub fn cached_debug_lines(&self) -> &[String] {
        &self.cached_debug_lines
    }

    pub fn debug_lines(&mut self) -> Vec<String> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            inst.store.data_mut().debug_lines.clear();
            if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_on_debug_lines") {
                let _ = func.call(&mut inst.store, ());
            }
            out.extend(inst.store.data_mut().debug_lines.drain(..));
        }
        out
    }

    pub fn input(&mut self, key_or_btn: i32, action: i32) -> bool {
        let mut consumed = false;
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32, i32), i32>(&inst.store, "dmod_input")
            {
                if let Ok(ret) = func.call(&mut inst.store, (key_or_btn, action)) {
                    if ret != 0 {
                        consumed = true;
                    }
                }
            }
        }
        consumed
    }

    pub fn settings_click(&mut self, btn_id: i32) {
        for inst in &mut self.instances {
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_settings_click")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_on_setting_click")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_on_setting_button")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            }
        }
    }

    fn reapply_saved_settings_for(
        game_dir: &std::path::Path,
        instance: &wasmi::Instance,
        store: &mut wasmi::Store<DmodHostState>,
    ) {
        let mod_settings_path = game_dir.join("diamond-mod-settings.json");
        let Ok(text) = std::fs::read_to_string(&mod_settings_path) else {
            return;
        };
        let Ok(json) = serde_json::from_str::<serde_json::Value>(&text) else {
            return;
        };
        let buttons = store.data().setting_buttons.clone();
        for b in buttons {
            let alias_key = match b.key.as_str() {
                "toggle_horror" => "horror_optimizer.horror",
                "toggle_optimizer" => "horror_optimizer.optimizer",
                "toggle_vhs" => "horror_optimizer.vhs",
                "mt_wheel" => "mouse_tweaks.wheel",
                _ => "",
            };
            let wanted_opt = json
                .get(&b.key)
                .and_then(|v| v.as_bool())
                .or_else(|| {
                    if alias_key.is_empty() {
                        None
                    } else {
                        json.get(alias_key).and_then(|v| v.as_bool())
                    }
                });
            if let Some(wanted) = wanted_opt {
                let label_up = b.label.to_uppercase();
                let currently_on = label_up.contains(": ON") || label_up.contains(": ENABLED");
                let currently_off = label_up.contains(": OFF") || label_up.contains(": DISABLED");
                if (wanted && currently_off) || (!wanted && currently_on) {
                    if let Ok(click_fn) = instance.get_typed_func::<i32, ()>(&*store, "dmod_settings_click") {
                        let _ = click_fn.call(&mut *store, b.id);
                    } else if let Ok(click_fn2) = instance.get_typed_func::<i32, ()>(&*store, "dmod_on_setting_button") {
                        let _ = click_fn2.call(&mut *store, b.id);
                    } else if let Ok(click_fn3) = instance.get_typed_func::<i32, ()>(&*store, "dmod_on_setting_click") {
                        let _ = click_fn3.call(&mut *store, b.id);
                    }
                }
            }
        }
    }

    fn persist_button_states_to_disk(game_dir: &std::path::Path, buttons: &[DmodSettingButton]) {
        let mod_settings_path = game_dir.join("diamond-mod-settings.json");
        let mut root = std::fs::read_to_string(&mod_settings_path)
            .ok()
            .and_then(|t| serde_json::from_str::<serde_json::Map<String, serde_json::Value>>(&t).ok())
            .unwrap_or_default();
        let mut changed = false;
        for b in buttons {
            if b.key.is_empty() {
                continue;
            }
            let up = b.label.to_uppercase();
            let val = if up.contains(": ON") || up.contains(": ENABLED") {
                Some(true)
            } else if up.contains(": OFF") || up.contains(": DISABLED") {
                Some(false)
            } else {
                None
            };
            if let Some(v) = val {
                root.insert(b.key.clone(), serde_json::Value::Bool(v));
                changed = true;
            }
        }
        if changed {
            if let Ok(out) = serde_json::to_string_pretty(&serde_json::Value::Object(root)) {
                let _ = std::fs::write(&mod_settings_path, out);
            }
        }
    }

    pub fn settings_click_for(&mut self, mod_id: &str, button_index: usize) {
        let game_dir = self.game_dir.clone();
        for inst in &mut self.instances {
            if inst.manifest.id != mod_id {
                continue;
            }
            let btn_id = inst
                .store
                .data()
                .setting_buttons
                .get(button_index)
                .map(|b| b.id)
                .unwrap_or(button_index as i32);
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_settings_click")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_on_setting_click")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            } else if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32,), ()>(&inst.store, "dmod_on_setting_button")
            {
                let _ = func.call(&mut inst.store, (btn_id,));
            }
            Self::persist_button_states_to_disk(&game_dir, &inst.store.data().setting_buttons);
        }
    }

    pub fn setting_buttons_for(&self, mod_id: &str) -> Vec<String> {
        for inst in &self.instances {
            if inst.manifest.id == mod_id {
                return inst
                    .store
                    .data()
                    .setting_buttons
                    .iter()
                    .map(|b| b.label.clone())
                    .collect();
            }
        }
        Vec::new()
    }

    pub fn has_mod(&self, mod_id: &str) -> bool {
        self.instances.iter().any(|i| i.manifest.id == mod_id)
    }

    pub fn drain_chat_messages(&mut self) -> Vec<String> {
        let mut messages = Vec::new();
        for inst in &mut self.instances {
            messages.extend(inst.store.data_mut().chat_messages.drain(..));
        }
        messages
    }

    pub fn drain_world_lines(&mut self) -> Vec<DmodWorldLine> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if inst.active {
                out.extend(inst.store.data_mut().world_lines.drain(..));
            } else {
                inst.store.data_mut().world_lines.clear();
            }
        }
        out
    }

    pub fn take_sound_clicks(&mut self) -> u32 {
        let mut clicks = 0;
        for inst in &mut self.instances {
            clicks += std::mem::take(&mut inst.store.data_mut().sound_clicks);
        }
        clicks
    }

    pub fn update_snapshot(
        &mut self,
        fps: i32,
        w: i32,
        h: i32,
        in_world: bool,
        screen_id: i32,
        world_time: i64,
        player_flags: i32,
        hp: f32,
        max_hp: f32,
        pos: [f64; 3],
        vel: [f64; 3],
        rot: [f32; 2],
        delta: [f32; 2],
        hunger: i32,
        air: i32,
        gamemode: i32,
        selected_slot: i32,
        dimension: i32,
        is_multiplayer: bool,
    ) {
        for inst in &mut self.instances {
            let data = inst.store.data_mut();
            data.fps = fps;
            data.window_width = w;
            data.window_height = h;
            data.in_world = in_world;
            data.screen_id = screen_id;
            data.world_time = world_time;
            data.player_flags = player_flags;
            data.player_hp = hp;
            data.player_max_hp = max_hp;
            data.player_pos = pos;
            data.player_vel = vel;
            data.player_rot = rot;
            data.mouse_delta = delta;
            data.player_hunger = hunger;
            data.player_air = air;
            data.player_gamemode = gamemode;
            data.selected_slot = selected_slot;
            data.dimension = dimension;
            data.is_multiplayer = is_multiplayer;
            let was_in = data.world_was_in;
            data.world_was_in = in_world;
            if inst.active && !was_in && in_world {
                if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_on_world_join") {
                    let _ = func.call(&mut inst.store, ());
                }
                Self::reapply_saved_settings_for(&self.game_dir, &inst.instance, &mut inst.store);
            } else if inst.active && was_in && !in_world {
                if let Ok(func) = inst.instance.get_typed_func::<(), ()>(&inst.store, "dmod_on_world_leave") {
                    let _ = func.call(&mut inst.store, ());
                }
            }
        }
    }

    pub fn set_light_level(&mut self, light: i32) {
        for inst in &mut self.instances {
            inst.store.data_mut().light_level = light.clamp(0, 15);
        }
    }

    pub fn set_key_held(&mut self, key: i32, held: bool) {
        for inst in &mut self.instances {
            let data = inst.store.data_mut();
            if held {
                data.keys_held.insert(key);
            } else {
                data.keys_held.remove(&key);
            }
        }
    }

    pub fn set_mouse_button_held(&mut self, btn: i32, held: bool) {
        for inst in &mut self.instances {
            let data = inst.store.data_mut();
            if held {
                data.mouse_buttons_held.insert(btn);
            } else {
                data.mouse_buttons_held.remove(&btn);
            }
        }
    }

    pub fn camera_yaw_offset(&self) -> f32 {
        self.camera_yaw_offset
    }

    pub fn camera_pitch_offset(&self) -> f32 {
        self.camera_pitch_offset
    }

    pub fn camera_roll_deg(&self) -> f32 {
        self.camera_roll_deg
    }

    pub fn camera_pos_offset(&self) -> [f32; 3] {
        self.camera_pos_offset
    }

    pub fn fov_scale(&self) -> f32 {
        self.fov_scale
    }

    pub fn fog_density(&self) -> f32 {
        self.fog_density
    }

    pub fn fog_color(&self) -> [f32; 4] {
        self.fog_color
    }

    pub fn sky_override(&self) -> Option<[f32; 3]> {
        self.sky_override
    }

    pub fn vignette(&self) -> [f32; 4] {
        self.vignette
    }

    pub fn fullbright_override(&self) -> bool {
        self.fullbright_override
    }

    pub fn gamma_override(&self) -> Option<f32> {
        self.gamma_override
    }

    pub fn installed_mods(&self) -> &[DmodManifest] {
        &self.installed_manifests
    }

    pub fn all_setting_buttons(&self) -> Vec<DmodSettingButton> {
        let mut out = Vec::new();
        for inst in &self.instances {
            out.extend(inst.store.data().setting_buttons.clone());
        }
        out
    }

    pub fn update_container_cursor_fast(
        &mut self,
        content_hash: u64,
        container_type: i32,
        hovered_slot: i32,
        cursor: (f32, f32),
        shift: bool,
        ctrl: bool,
        alt: bool,
    ) -> (bool, bool) {
        if container_type <= 0 {
            self.last_container_hash = 0;
            for inst in &mut self.instances {
                let d = inst.store.data_mut();
                d.container_type = 0;
                d.hovered_slot = -1;
                d.cursor_x = cursor.0;
                d.cursor_y = cursor.1;
                d.shift_down = shift;
                d.ctrl_down = ctrl;
                d.alt_down = alt;
            }
            return (true, false);
        }
        if self.last_container_hash != content_hash || content_hash == 0 {
            return (false, true);
        }
        let mut hovered_changed = false;
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            if d.hovered_slot != hovered_slot {
                hovered_changed = true;
            }
            d.container_type = container_type;
            d.hovered_slot = hovered_slot;
            d.cursor_x = cursor.0;
            d.cursor_y = cursor.1;
            d.shift_down = shift;
            d.ctrl_down = ctrl;
            d.alt_down = alt;
        }
        (true, hovered_changed)
    }

    pub fn update_container_state_with_hash(
        &mut self,
        content_hash: u64,
        container_type: i32,
        hovered_slot: i32,
        cursor: (f32, f32),
        shift: bool,
        ctrl: bool,
        alt: bool,
        carried: (i32, i32, i32, String),
        slots: Vec<DmodSlotState>,
    ) {
        self.last_container_hash = content_hash;
        self.update_container_state(
            container_type,
            hovered_slot,
            cursor,
            shift,
            ctrl,
            alt,
            carried,
            slots,
        );
    }

    pub fn update_container_state(
        &mut self,
        container_type: i32,
        hovered_slot: i32,
        cursor: (f32, f32),
        shift: bool,
        ctrl: bool,
        alt: bool,
        carried: (i32, i32, i32, String),
        slots: Vec<DmodSlotState>,
    ) {
        let slot_count = slots.len() as i32;
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            d.container_type = container_type;
            d.container_slot_count = slot_count;
            d.hovered_slot = hovered_slot;
            d.cursor_x = cursor.0;
            d.cursor_y = cursor.1;
            d.shift_down = shift;
            d.ctrl_down = ctrl;
            d.alt_down = alt;
            d.carried_item_id = carried.0;
            d.carried_item_count = carried.1;
            d.carried_max_stack = carried.2;
            d.carried_item_name = carried.3.clone();
            d.slots = slots.clone();
        }
    }

    pub fn update_world_target(
        &mut self,
        targeted_block: [i32; 5],
        targeted_face: i32,
        targeted_block_name: String,
        targeted_entity_id: i32,
        targeted_entity_health: f32,
        targeted_entity_name: String,
        biome_name: String,
        sky_light: i32,
        block_light: i32,
    ) {
        for inst in &mut self.instances {
            let d = inst.store.data_mut();
            d.targeted_block = targeted_block;
            d.targeted_face = targeted_face;
            d.targeted_block_name = targeted_block_name.clone();
            d.targeted_entity_id = targeted_entity_id;
            d.targeted_entity_health = targeted_entity_health;
            d.targeted_entity_name = targeted_entity_name.clone();
            d.biome_name = biome_name.clone();
            d.sky_light = sky_light;
            d.block_light = block_light;
        }
    }

    pub fn container_tick(&mut self, mouse_mask: i32) {
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            let (ct, sc, hs) = {
                let d = inst.store.data();
                (d.container_type, d.container_slot_count, d.hovered_slot)
            };
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32, i32, i32, i32), ()>(&inst.store, "dmod_container_tick")
            {
                let _ = func.call(&mut inst.store, (ct, sc, hs, mouse_mask));
            }
        }
    }

    pub fn container_drag(&mut self, hovered_slot: i32, button: i32, shift_down: bool) -> bool {
        let mut handled = false;
        let shift_i = i32::from(shift_down);
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            inst.store.data_mut().hovered_slot = hovered_slot;
            inst.store.data_mut().shift_down = shift_down;
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32, i32, i32), i32>(&inst.store, "dmod_container_drag")
            {
                if let Ok(ret) = func.call(&mut inst.store, (hovered_slot, button, shift_i)) {
                    if ret != 0 {
                        handled = true;
                    }
                }
            }
        }
        handled
    }

    pub fn container_scroll(&mut self, hovered_slot: i32, delta: f32) -> bool {
        let mut handled = false;
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            inst.store.data_mut().hovered_slot = hovered_slot;
            if let Ok(func) = inst
                .instance
                .get_typed_func::<(i32, f32), i32>(&inst.store, "dmod_container_scroll")
            {
                if let Ok(ret) = func.call(&mut inst.store, (hovered_slot, delta)) {
                    if ret != 0 {
                        handled = true;
                    }
                }
            }
        }
        handled
    }

    pub fn drain_container_ops(&mut self) -> Vec<DmodContainerOp> {
        let mut out = Vec::new();
        for inst in &mut self.instances {
            if inst.active {
                out.extend(inst.store.data_mut().pending_container_ops.drain(..));
            } else {
                inst.store.data_mut().pending_container_ops.clear();
            }
        }
        out
    }

    pub fn drain_player_actions(
        &mut self,
    ) -> (
        Vec<String>,
        Option<[f32; 3]>,
        Option<[f32; 2]>,
        Option<i32>,
        bool,
    ) {
        let mut chats = Vec::new();
        let mut vel = None;
        let mut angles = None;
        let mut slot = None;
        let mut swing = false;
        for inst in &mut self.instances {
            if !inst.active {
                continue;
            }
            let d = inst.store.data_mut();
            chats.extend(d.pending_chat_sends.drain(..));
            if let Some(v) = d.pending_velocity_add.take() {
                let p = vel.unwrap_or([0.0; 3]);
                vel = Some([p[0] + v[0], p[1] + v[1], p[2] + v[2]]);
            }
            if let Some(a) = d.pending_player_angles.take() {
                angles = Some(a);
            }
            if let Some(s) = d.pending_hotbar_slot.take() {
                slot = Some(s);
            }
            if d.pending_swing_arm {
                d.pending_swing_arm = false;
                swing = true;
            }
        }
        (chats, vel, angles, slot, swing)
    }

    pub fn mouse_tweaks_enabled(&self) -> bool {
        self.instances.iter().any(|i| i.active && ( {
            i.active
                && (i.manifest.id.contains("mouse")
                    || i.manifest.id.contains("tweak")
                    || (i.store.data().mouse_tweaks_flags & 7) != 0)
        }))
    }

    pub fn mouse_tweaks_wheel_enabled(&self) -> bool {
        self.instances.iter().any(|i| i.active && ( {
            i.active && (i.store.data().mouse_tweaks_flags & 8) != 0
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_unsafe_zip_slip_entry_paths() {
        assert!(is_safe_relative_entry_path("mod.wasm"));
        assert!(is_safe_relative_entry_path("wasm/horror.wasm"));
        assert!(!is_safe_relative_entry_path("../evil.wasm"));
        assert!(!is_safe_relative_entry_path("/etc/passwd"));
        assert!(!is_safe_relative_entry_path(r"\\server\share\mod.wasm"));
    }

    #[test]
    fn sorts_mods_topologically_by_depends_on() {
        let m_addon = DmodManifest {
            id: "addon_mod".to_string(),
            name: "Addon".to_string(),
            version: "1.0.0".to_string(),
            author: None,
            description: None,
            entry: "mod.wasm".to_string(),
            api_version: Some(4),
            depends_on: vec!["core_lib".to_string()],
            load_after: Vec::new(),
        };
        let m_core = DmodManifest {
            id: "core_lib".to_string(),
            name: "Core".to_string(),
            version: "1.0.0".to_string(),
            author: None,
            description: None,
            entry: "mod.wasm".to_string(),
            api_version: Some(4),
            depends_on: Vec::new(),
            load_after: Vec::new(),
        };
        let mut list = vec![
            (PathBuf::from("addon.dmod"), m_addon, Vec::new()),
            (PathBuf::from("core.dmod"), m_core, Vec::new()),
        ];
        sort_discovered_mods_topologically(&mut list);
        assert_eq!(list[0].1.id, "core_lib");
        assert_eq!(list[1].1.id, "addon_mod");
    }
}
