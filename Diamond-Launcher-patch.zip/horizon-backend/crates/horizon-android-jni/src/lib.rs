use jni::objects::{JClass, JFloatArray, JString};
use jni::sys::{jboolean, jint, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use std::path::PathBuf;

#[cfg(target_os = "android")]
mod android {
    use android_activity::AndroidApp;
    use std::path::PathBuf;

    #[cfg(target_arch = "aarch64")]
    unsafe extern "C" fn stack_trampoline(arg: *mut std::ffi::c_void) {
        let closure = unsafe { Box::from_raw(arg as *mut Box<dyn FnOnce()>) };
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(closure));
    }

    #[cfg(target_arch = "aarch64")]
    fn run_with_64mb_stack(f: impl FnOnce()) {
        const STACK_SIZE: usize = 64 * 1024 * 1024;
        const GUARD_SIZE: usize = 64 * 1024;
        unsafe {
            let map = libc::mmap(
                std::ptr::null_mut(),
                STACK_SIZE,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            );
            if map == libc::MAP_FAILED || map.is_null() {
                f();
                return;
            }
            let _ = libc::mprotect(map, GUARD_SIZE, libc::PROT_NONE);
            let boxed: Box<Box<dyn FnOnce()>> = Box::new(Box::new(f));
            let arg = Box::into_raw(boxed) as *mut std::ffi::c_void;
            let top = ((map as usize) + STACK_SIZE - 64) & !15usize;
            let tramp_fn = stack_trampoline as usize;
            core::arch::asm!(
                "stp x19, x29, [sp, #-16]!",
                "mov x19, sp",
                "mov sp, x1",
                "mov x29, #0",
                "blr x2",
                "mov sp, x19",
                "ldp x19, x29, [sp], #16",
                inout("x0") arg => _,
                inout("x1") top => _,
                inout("x2") tramp_fn => _,
                out("x3") _,
                out("x4") _,
                out("x5") _,
                out("x6") _,
                out("x7") _,
                out("x8") _,
                out("x9") _,
                out("x10") _,
                out("x11") _,
                out("x12") _,
                out("x13") _,
                out("x14") _,
                out("x15") _,
                out("x16") _,
                out("x17") _,
                out("x30") _,
                clobber_abi("C"),
            );
        }
    }

    #[cfg(not(target_arch = "aarch64"))]
    fn run_with_64mb_stack(f: impl FnOnce()) {
        f();
    }

    #[unsafe(no_mangle)]
    pub extern "C" fn android_main(app: AndroidApp) {
        run_with_64mb_stack(move || {
            let base = app
                .external_data_path()
                .or_else(|| app.internal_data_path())
                .unwrap_or_else(|| {
                    PathBuf::from("/storage/emulated/0/Android/data/com.logosforgestudios.diamond/files")
                });
            let root = base.join("horizon");
            let home = std::env::var_os("HORIZON_HOME")
                .filter(|v| !v.is_empty())
                .map(PathBuf::from)
                .unwrap_or_else(|| root.join("instance"));
            let resources = std::env::var_os("HORIZON_RESOURCES")
                .filter(|v| !v.is_empty())
                .map(PathBuf::from)
                .unwrap_or_else(|| {
                    root.join(".local/horizon-client")
                        .join(horizon_platform::version::VANILLA_VERSION)
                });
            let msa_session = root.join("sessions/session-msa.json");
            let session = std::env::var_os("HORIZON_SESSION_FILE")
                .filter(|v| !v.is_empty())
                .map(PathBuf::from)
                .filter(|p| p.is_file())
                .or_else(|| msa_session.is_file().then_some(msa_session));
            let player_name = std::fs::read_to_string(home.join("horizon-player.txt"))
                .ok()
                .and_then(|t| {
                    t.lines()
                        .find_map(|l| l.trim_end_matches('
').strip_prefix("name:"))
                        .map(|n| n.trim().to_string())
                        .filter(|n| !n.is_empty())
                });
            let internal_cache = app
                .internal_data_path()
                .unwrap_or_else(|| PathBuf::from("/data/data/com.logosforgestudios.diamond/files"))
                .join(".horizon-cache");

            let _ = std::fs::create_dir_all(&home);
            let _ = std::fs::create_dir_all(&internal_cache);
            let _ = std::env::set_current_dir(&home);
            unsafe {
                std::env::set_var("HORIZON_HOME", &home);
                std::env::set_var("HORIZON_GAME_DIR", &home);
                std::env::set_var("HORIZON_RESOURCES", &resources);
                std::env::set_var("HORIZON_INTERNAL_CACHE", &internal_cache);
                if let Some(ref name) = player_name {
                    std::env::set_var("HORIZON_PLAYER_NAME", name);
                }
                if let Some(ref sess) = session {
                    if sess.is_file() {
                        std::env::set_var("HORIZON_SESSION_FILE", sess);
                    }
                }
            }

            let crash_home = home.clone();
            let prev_hook = std::panic::take_hook();
            std::panic::set_hook(Box::new(move |info| {
                let crash_dir = crash_home.join("crash-reports");
                let _ = std::fs::create_dir_all(&crash_dir);
                let msg = format!("Rust Panic in :game process:\n{info}");
                let _ = std::fs::write(crash_dir.join("last_crash_summary.txt"), &msg);
                prev_hook(info);
            }));

            horizon_client::entry::set_android_app(app);
            horizon_client::entry::main();
            let _ = std::fs::write(root.join(".game_session_clean"), "clean");
            let _ = std::fs::remove_file(root.join(".game_session_active"));
            unsafe { libc::_exit(0); }
        });
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeGetEngineInfo<
    'local,
>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let info = format!(
        "Horizon Rust Engine (MC {}, JNI Active)",
        horizon_platform::version::VANILLA_VERSION,
    );
    env.new_string(info)
        .map(|s| s.into_raw())
        .unwrap_or(std::ptr::null_mut())
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeValidateUsername<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    username: JString<'local>,
) -> jboolean {
    let Ok(name) = env.get_string(&username) else {
        return JNI_FALSE;
    };
    let s = name.to_string_lossy();
    let len = s.len();
    let valid = (3..=16).contains(&len)
        && s.bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'_');
    if valid { JNI_TRUE } else { JNI_FALSE }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativePrepareResources<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    minecraft_dir: JString<'local>,
    output_dir: JString<'local>,
    version_id: JString<'local>,
) -> jint {
    let Ok(mc_str) = env.get_string(&minecraft_dir) else {
        return -1;
    };
    let Ok(out_str) = env.get_string(&output_dir) else {
        return -2;
    };
    let Ok(ver_str) = env.get_string(&version_id) else {
        return -3;
    };
    let mc_path = PathBuf::from(mc_str.to_string_lossy().as_ref());
    let out_path = PathBuf::from(out_str.to_string_lossy().as_ref());
    let _version = ver_str.to_string_lossy().into_owned();

    let root = out_path
        .ancestors()
        .nth(3)
        .map_or_else(|| mc_path.clone(), |path| path.to_path_buf());
    let options = horizon_platform::prepare::Options {
        root,
        import: true,
        minecraft_dir: Some(mc_path),
        server_jar: None,
        java_home: None,
        inputs: Default::default(),
        output: Some(out_path.clone()),
    };

    let err_path = out_path.join("prepare-error.txt");
    match horizon_platform::prepare::prepare(&options, &|_line| {}) {
        Ok(_) => {
            let _ = std::fs::remove_file(&err_path);
            0
        }
        Err(e) => {
            let _ = std::fs::write(&err_path, format!("{e}"));
            -4
        }
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeLaunchClient<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    game_home_dir: JString<'local>,
    session_file: JString<'local>,
    graphics_api: JString<'local>,
    resources_dir: JString<'local>,
) -> jint {
    let Ok(home_str) = env.get_string(&game_home_dir) else {
        return -1;
    };
    let Ok(session_str) = env.get_string(&session_file) else {
        return -2;
    };
    let Ok(api_str) = env.get_string(&graphics_api) else {
        return -3;
    };
    let Ok(res_str) = env.get_string(&resources_dir) else {
        return -4;
    };

    unsafe {
        std::env::set_var("HORIZON_HOME", home_str.to_string_lossy().as_ref());
        std::env::set_var(
            "HORIZON_SESSION_FILE",
            session_str.to_string_lossy().as_ref(),
        );
        std::env::set_var(
            "HORIZON_GRAPHICS_API",
            api_str.to_string_lossy().as_ref(),
        );
        std::env::set_var(
            "HORIZON_RESOURCES",
            res_str.to_string_lossy().as_ref(),
        );
    }

    0
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendKey<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    key: JString<'local>,
    pressed: jboolean,
) {
    if let Ok(key_str) = env.get_string(&key) {
        horizon_client::entry::push_android_input(
            horizon_client::entry::AndroidInputEvent::Key {
                key: key_str.to_string_lossy().into_owned(),
                pressed: pressed != 0,
            },
        );
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendMouseButton<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    button: jint,
    pressed: jboolean,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::MouseButton {
            button,
            pressed: pressed != 0,
        },
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendCursorDelta<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    dx: jni::sys::jfloat,
    dy: jni::sys::jfloat,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::CursorDelta { dx, dy },
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendCursorPos<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    x: jni::sys::jfloat,
    y: jni::sys::jfloat,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::CursorPos { x, y },
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendScroll<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    dx: jni::sys::jfloat,
    dy: jni::sys::jfloat,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::Scroll { dx, dy },
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendTouch<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    action: jint,
    x: jni::sys::jfloat,
    y: jni::sys::jfloat,
    dx: jni::sys::jfloat,
    dy: jni::sys::jfloat,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::Touch {
            action,
            x,
            y,
            dx,
            dy,
        },
    );
}


#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeIsCursorCaptured<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jboolean {
    if horizon_client::entry::is_android_cursor_captured() {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeIsImeWanted<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jboolean {
    if horizon_client::entry::is_android_ime_wanted() {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSendTextCommit<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    text: JString<'local>,
) {
    if let Ok(text_str) = env.get_string(&text) {
        let s = text_str.to_string_lossy().into_owned();
        if !s.is_empty() {
            horizon_client::entry::push_android_input(
                horizon_client::entry::AndroidInputEvent::TextCommit { text: s },
            );
        }
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeDismissIme<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) {
    horizon_client::entry::push_android_input(
        horizon_client::entry::AndroidInputEvent::DismissIme,
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeMixAudio<
    'local,
>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
    out: JFloatArray<'local>,
    channels: jint,
    rate: jint,
) {
    let len = match env.get_array_length(&out) {
        Ok(l) => l as usize,
        Err(_) => return,
    };
    let mut buf = vec![0.0f32; len];
    horizon_client::audio::mix_android_audio(
        &mut buf,
        channels.max(1) as usize,
        rate.max(8000) as u32,
    );
    let _ = env.set_float_array_region(&out, 0, &buf);
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeIsBootDrawn<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jboolean {
    if horizon_client::entry::is_android_boot_drawn() {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeIsGameLoaded<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jboolean {
    if horizon_client::entry::is_android_game_loaded() {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetResolutionScale<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    scale_percent: jint,
) {
    horizon_client::entry::set_android_resolution_scale(scale_percent.clamp(10, 100) as u32);
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetBuiltinShader<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    enabled: jboolean,
    strength_percent: jint,
) {
    horizon_client::entry::set_android_builtin_shader(
        enabled != 0,
        strength_percent.max(0) as u32,
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetHudHidden<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    hidden: jboolean,
) {
    horizon_client::entry::set_android_hud_hidden(hidden != 0);
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetShaderFlags<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    builtin_shader: jboolean,
    dynamic_shadows: jboolean,
    vhs_fisheye: jboolean,
) {
    horizon_client::entry::set_android_shader_flags(
        builtin_shader != 0,
        dynamic_shadows != 0,
        vhs_fisheye != 0,
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeInitShaderFlags<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    builtin_shader: jboolean,
    dynamic_shadows: jboolean,
    vhs_fisheye: jboolean,
) {
    horizon_client::entry::init_android_shader_flags(
        builtin_shader != 0,
        dynamic_shadows != 0,
        vhs_fisheye != 0,
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeGetShaderFlags<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jint {
    horizon_client::entry::get_android_shader_flags() as jint
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetVirtualMouse<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    enabled: jboolean,
) {
    horizon_client::entry::set_android_virtual_mouse(enabled != 0);
}


#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativeSetWindowAspect<
    'local,
>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    aspect_milli: jint,
    stretch_to_fullscreen: jboolean,
) {
    horizon_client::entry::set_android_window_aspect(
        aspect_milli.max(0) as u32,
        stretch_to_fullscreen != 0,
    );
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_com_logosforgestudios_diamond_engine_HorizonNativeBridge_nativePollTtsRequest<
    'local,
>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    match horizon_client::entry::poll_android_tts_request() {
        Some(req) => env
            .new_string(req)
            .map(|s| s.into_raw())
            .unwrap_or(std::ptr::null_mut()),
        None => std::ptr::null_mut(),
    }
}

