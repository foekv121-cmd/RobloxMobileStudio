package com.logosforgestudios.diamond.ui

import android.content.Intent
import android.content.res.Configuration
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.scaleIn
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.outlined.Explore as OutlinedExplore
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.Layers as OutlinedLayers
import androidx.compose.material.icons.outlined.Person as OutlinedPerson
import androidx.compose.material.icons.outlined.Settings as OutlinedSettings
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Gamepad
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.NightlightRound
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.logosforgestudios.diamond.R
import com.logosforgestudios.diamond.engine.DeviceGpuInfo
import com.logosforgestudios.diamond.engine.HORIZON_MC_VERSION
import com.logosforgestudios.diamond.engine.HorizonAccount
import com.logosforgestudios.diamond.engine.HorizonEngine
import com.logosforgestudios.diamond.engine.HorizonSettings
import com.logosforgestudios.diamond.engine.ModSettingSchema
import com.logosforgestudios.diamond.engine.ModrinthClient
import com.logosforgestudios.diamond.engine.ModrinthProjectDetails
import com.logosforgestudios.diamond.engine.ModrinthProjectHit
import com.logosforgestudios.diamond.engine.ModrinthSortOption
import com.logosforgestudios.diamond.engine.ModrinthVersionEntry
import com.logosforgestudios.diamond.engine.ModrinthVersionFile
import com.logosforgestudios.diamond.engine.RemoteImageCache
import com.logosforgestudios.diamond.engine.ManagedPackItem
import com.logosforgestudios.diamond.engine.PackKind
import com.logosforgestudios.diamond.engine.SetupProgress
import com.logosforgestudios.diamond.controls.GlobalTouchSettings
import com.logosforgestudios.diamond.controls.TouchControlEditorScreen
import com.logosforgestudios.diamond.controls.TouchControlLayout
import com.logosforgestudios.diamond.controls.TouchControlsManager
import com.logosforgestudios.diamond.crash.CrashDetector
import com.logosforgestudios.diamond.crash.CrashReportData
import com.logosforgestudios.diamond.ui.theme.DiamondLauncherTheme
import com.logosforgestudios.diamond.ui.theme.AccentSeedChoices
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

private val HeroCardShape = RoundedCornerShape(26.dp)
private val TileCardShape = RoundedCornerShape(22.dp)
private val SquircleShape = RoundedCornerShape(16.dp)

private val FastExpand = fadeIn(animationSpec = tween(durationMillis = 95, easing = FastOutSlowInEasing))

private val FastCollapse = fadeOut(animationSpec = tween(durationMillis = 75, easing = FastOutSlowInEasing))

private data class ResumeSnapshot(
    val diskSettings: HorizonSettings,
    val diskModSettings: Map<String, Boolean>,
    val diskAccounts: Pair<List<HorizonAccount>, String?>,
    val versionReady: Boolean,
    val smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    val globalTouchSettings: GlobalTouchSettings,
    val availableControlLayouts: List<TouchControlLayout>,
    val installedSizeMib: Float,
    val auditReport: HorizonEngine.Companion.VerificationAuditReport,
    val mods: List<ManagedPackItem>,
    val shaders: List<ManagedPackItem>,
    val resourcePacks: List<ManagedPackItem>,
    val crash: CrashReportData?,
)

private enum class ActiveQuickTile {
    NONE,
    PROFILE,
    RENDERER,
    RAM,
    FPS,
}

private enum class SettingsCategory(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
) {
    GRAPHICS("Video Settings", "Vulkan / OpenGL ES, unified FPS limit, VSync & resolution scale", Icons.Rounded.Code),
    CONTROLS("Controls", "Control Editor, layout selector, sensitivity, inverted Y & opacity", Icons.Rounded.Gamepad),
    CULLING("GPU & Culling", "Frustum culling, caves, entities, shadows & FXAA", Icons.Rounded.Tune),
    MEMORY("Memory & Runtime", "Smart RAM detector, heap allocation & worker threads", Icons.Rounded.Memory),
    STORAGE("Storage & Verification", "Graded installation audit, SAF Google Files & crash logs", Icons.Rounded.Storage),
    APPEARANCE("Appearance", "Material You dynamic colors & dark theme", Icons.Rounded.Palette),
}

private data class NavDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
)

private val Destinations = listOf(
    NavDestination("Play", Icons.Rounded.Home, OutlinedHome),
    NavDestination("Versions", Icons.Rounded.Layers, OutlinedLayers),
    NavDestination("Discover", Icons.Rounded.Explore, OutlinedExplore),
    NavDestination("Manage", Icons.Rounded.GridView, OutlinedGridView),
    NavDestination("Settings", Icons.Rounded.Settings, OutlinedSettings),
)

@Composable
fun LauncherScreen(openControlEditorTrigger: Int = 0) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember(context) { HorizonEngine(context) }

    var settings by remember { mutableStateOf(engine.peekCachedSettings()) }
    var modSettings by remember { mutableStateOf(engine.peekCachedModSettings()) }
    var accountsState by remember { mutableStateOf(engine.peekCachedAccounts()) }
    val accounts = accountsState.first
    val selectedAccountUuid = accountsState.second
    val activeAccount = remember(accounts, selectedAccountUuid) {
        accounts.firstOrNull { it.uuid == selectedAccountUuid } ?: accounts.firstOrNull()
    }

    var needsOptimization by remember { mutableStateOf(engine.needsFirstLaunchOptimization()) }
    var optimizationStep by remember { mutableStateOf("Checking device hardware & Vulkan capabilities...") }
    var optimizationProgress by remember { mutableFloatStateOf(0.15f) }
    var introLoaded by remember { mutableStateOf(!needsOptimization) }
    var launchingGameStage by remember { mutableStateOf<String?>(null) }
    var customDrivers by remember { mutableStateOf<List<String>>(emptyList()) }
    var hasCustomSkin by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeSettingsCategory by remember { mutableStateOf<SettingsCategory?>(null) }

    var versionReady by remember { mutableStateOf(false) }
    var installedSizeMib by remember { mutableStateOf(0f) }
    var auditReport by remember {
        mutableStateOf(
            HorizonEngine.Companion.VerificationAuditReport(
                grade = "A+ • Ready",
                scorePercent = 100,
                summary = "Checking Horizon 26.3 installation...",
                items = emptyList(),
                readyToPlay = false,
            ),
        )
    }
    var smartMemory by remember {
        mutableStateOf(
            HorizonEngine.Companion.SmartMemoryProfile(
                totalDeviceRamMb = 6144,
                availableRamMb = 2800,
                lowMemory = false,
                recommendedAllocMb = 2560,
                minSafeAllocMb = 1024,
                maxSafeAllocMb = 4096,
                tierLabel = "6 GB Balanced Mobile Profile",
            ),
        )
    }

    var globalTouchSettings by remember {
        mutableStateOf(GlobalTouchSettings())
    }
    var availableControlLayouts by remember {
        mutableStateOf<List<TouchControlLayout>>(emptyList())
    }
    var activeEditorLayout by remember {
        mutableStateOf<TouchControlLayout?>(null)
    }
    LaunchedEffect(openControlEditorTrigger, introLoaded) {
        if (openControlEditorTrigger > 0 && introLoaded) {
            val activeLay = withContext(Dispatchers.IO) {
                val cfg = TouchControlsManager.loadGlobalSettings(context)
                TouchControlsManager.loadLayout(context, cfg.activeLayoutName)
            }
            activeEditorLayout = activeLay
        }
    }
    var showControlPickerDialog by remember { mutableStateOf(false) }
    var showCreateNewControlDialog by remember { mutableStateOf(false) }

    var activeQuickTile by remember { mutableStateOf(ActiveQuickTile.NONE) }
    var launchError by remember { mutableStateOf<String?>(null) }
    var modLoadErrors by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    var showDownloadDialog by remember { mutableStateOf(false) }
    var showVerifyDialog by remember { mutableStateOf(false) }
    var showWhatsNewDialog by remember { mutableStateOf(false) }
    var showDiagnosticsDialog by remember { mutableStateOf(false) }
    var diagnosticsReportText by remember { mutableStateOf("") }
    var setupProgress by remember { mutableStateOf(SetupProgress(versionId = HORIZON_MC_VERSION)) }

    var packRefreshTick by remember { mutableIntStateOf(0) }
    var modsList by remember { mutableStateOf<List<ManagedPackItem>>(emptyList()) }
    var shadersList by remember { mutableStateOf<List<ManagedPackItem>>(emptyList()) }
    var resourcePacksList by remember { mutableStateOf<List<ManagedPackItem>>(emptyList()) }
    var preloadedShaders by remember { mutableStateOf<List<ModrinthProjectHit>>(emptyList()) }

    LaunchedEffect(Unit) {
        if (needsOptimization) {
            optimizationStep = "Detecting GPU, CPU cores & Smart RAM profile..."
            optimizationProgress = 0.25f
            delay(180)
        }
        val snapshot = withContext(Dispatchers.IO) {
            val mem = engine.detectSmartMemoryProfile()
            RemoteImageCache.configure(context, mem.isLowRamDevice)
            val diskSettings = engine.reloadSettingsFromDisk()
            val diskModSettings = engine.loadModSettings()
            val diskAccounts = engine.loadAccounts()
            val prepared = engine.isVersionPrepared()
            val touchCfg = TouchControlsManager.loadGlobalSettings(context)
            val layouts = TouchControlsManager.listLayouts(context)
            val sizeMib = if (prepared) HorizonEngine.readOrComputeInstallMetrics(context).totalSizeMib else 0f
            val report = HorizonEngine.Companion.VerificationAuditReport(
                grade = if (prepared) "A+ • Ready" else "Setup Needed",
                scorePercent = if (prepared) 100 else 0,
                summary = if (prepared) "Horizon 26.3 ready (tap Verify for full file scan)" else "Download required",
                items = emptyList(),
                readyToPlay = prepared,
            )
            val loadedMods = engine.listPacks(PackKind.MOD)
            val loadedShaders = engine.listPacks(PackKind.SHADER)
            val loadedPacks = engine.listPacks(PackKind.RESOURCE)
            (loadedMods + loadedShaders + loadedPacks).forEach { item ->
                val p = item.iconPath
                if (!p.isNullOrBlank()) {
                    RemoteImageCache.loadLocalFile(p, maxDimPx = 128)
                }
            }
            val crash = CrashDetector.checkForNewCrash(context)
            ResumeSnapshot(
                diskSettings = diskSettings,
                diskModSettings = diskModSettings,
                diskAccounts = diskAccounts,
                versionReady = prepared,
                smartMemory = mem,
                globalTouchSettings = touchCfg,
                availableControlLayouts = layouts,
                installedSizeMib = sizeMib,
                auditReport = report,
                mods = loadedMods,
                shaders = loadedShaders,
                resourcePacks = loadedPacks,
                crash = crash,
            )
        }
        settings = snapshot.diskSettings
        modSettings = snapshot.diskModSettings
        accountsState = snapshot.diskAccounts
        versionReady = snapshot.versionReady
        smartMemory = snapshot.smartMemory
        globalTouchSettings = snapshot.globalTouchSettings
        availableControlLayouts = snapshot.availableControlLayouts
        installedSizeMib = snapshot.installedSizeMib
        auditReport = snapshot.auditReport
        modsList = snapshot.mods
        shadersList = snapshot.shaders
        resourcePacksList = snapshot.resourcePacks
        val syncedDrivers = withContext(Dispatchers.IO) { engine.listCustomDrivers() }
        val syncedSkin = withContext(Dispatchers.IO) { engine.hasCustomSkin() }
        customDrivers = syncedDrivers
        hasCustomSkin = syncedSkin
        val startupModErrs = withContext(Dispatchers.IO) { engine.readModLoadErrors() }
        if (startupModErrs.isNotEmpty()) {
            modLoadErrors = startupModErrs
        }
        if (snapshot.diskSettings.autoSmartRam && snapshot.diskSettings.memoryMb != snapshot.smartMemory.recommendedAllocMb) {
            val autoSynced = snapshot.diskSettings.copy(memoryMb = snapshot.smartMemory.recommendedAllocMb)
            settings = autoSynced
            withContext(Dispatchers.IO) { engine.saveSettings(autoSynced) }
        }
        if (needsOptimization) {
            optimizationStep = "Indexing shaders, mods & touch control presets..."
            optimizationProgress = 0.68f
            delay(200)
            optimizationStep = "Optimizing launcher cache for instant launches..."
            optimizationProgress = 0.96f
            withContext(Dispatchers.IO) { engine.markFirstLaunchOptimized() }
            delay(180)
            needsOptimization = false
        }
        introLoaded = true
        if (snapshot.crash != null) {
            CrashDetector.launchCrashActivity(context, snapshot.crash)
        }
        launch(Dispatchers.IO) {
            delay(1500L)
            ModrinthClient.searchProjects("", "shader", limit = 16).onSuccess { hits ->
                withContext(Dispatchers.Main) { preloadedShaders = hits }
                hits.take(6).forEach { h ->
                    h.iconUrl?.let { RemoteImageCache.loadRemote(it, maxDimPx = 128) }
                }
            }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    val crash = withContext(Dispatchers.IO) { CrashDetector.checkForNewCrash(context) }
                    if (crash != null) {
                        CrashDetector.launchCrashActivity(context, crash)
                    }
                    val errs = withContext(Dispatchers.IO) { engine.readModLoadErrors() }
                    if (errs.isNotEmpty()) {
                        modLoadErrors = errs
                    }
                    val refreshedAcc = withContext(Dispatchers.IO) { engine.loadAccounts() }
                    val refreshedSkin = withContext(Dispatchers.IO) { engine.hasCustomSkin() }
                    accountsState = refreshedAcc
                    hasCustomSkin = refreshedSkin
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val openSafInGoogleFiles: () -> Unit = {
        runCatching {
            val rootUri = DocumentsContract.buildRootUri(
                "com.logosforgestudios.diamond.documents",
                "diamond_launcher_root",
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(rootUri, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            context.startActivity(intent)
        }.onFailure {
            runCatching {
                context.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE))
            }
        }
    }

    var showOfflineAccountDialog by remember { mutableStateOf(false) }
    var showMicrosoftComingSoonDialog by remember { mutableStateOf(false) }

    val hasBackAction = showCreateNewControlDialog ||
        showControlPickerDialog ||
        showDownloadDialog ||
        showOfflineAccountDialog ||
        showMicrosoftComingSoonDialog ||
        showVerifyDialog ||
        showWhatsNewDialog ||
        activeQuickTile != ActiveQuickTile.NONE ||
        selectedTab != 0

    BackHandler(enabled = hasBackAction) {
        if (showCreateNewControlDialog) {
            showCreateNewControlDialog = false
        } else if (showControlPickerDialog) {
            showControlPickerDialog = false
        } else if (showDownloadDialog) {
            showDownloadDialog = false
        } else if (showOfflineAccountDialog) {
            showOfflineAccountDialog = false
        } else if (showMicrosoftComingSoonDialog) {
            showMicrosoftComingSoonDialog = false
        } else if (showVerifyDialog) {
            showVerifyDialog = false
        } else if (showWhatsNewDialog) {
            showWhatsNewDialog = false
        } else if (activeQuickTile != ActiveQuickTile.NONE) {
            activeQuickTile = ActiveQuickTile.NONE
        } else if (selectedTab != 0) {
            selectedTab = 0
        }
    }

    LaunchedEffect(selectedTab) {
        if (selectedTab == 3) {
            packRefreshTick++
        }
    }

    LaunchedEffect(packRefreshTick) {
        if (packRefreshTick == 0) return@LaunchedEffect
        val (m, s, r) = withContext(Dispatchers.IO) {
            val loadedMods = engine.listPacks(PackKind.MOD)
            val loadedShaders = engine.listPacks(PackKind.SHADER)
            val loadedPacks = engine.listPacks(PackKind.RESOURCE)
            (loadedMods + loadedShaders + loadedPacks).forEach { item ->
                item.iconPath?.let { RemoteImageCache.loadLocalFile(it, maxDimPx = 128) }
            }
            Triple(loadedMods, loadedShaders, loadedPacks)
        }
        modsList = m
        shadersList = s
        resourcePacksList = r
    }

    var importTargetKind by remember { mutableStateOf(PackKind.MOD) }
    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch(Dispatchers.IO) {
                uris.forEach { uri ->
                    engine.importPackFromUri(uri, importTargetKind)
                }
                withContext(Dispatchers.Main) { packRefreshTick++ }
            }
        }
    }

    val driverZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) { engine.importCustomDriverZip(uri) }
                res.onSuccess { importedName ->
                    val list = withContext(Dispatchers.IO) { engine.listCustomDrivers() }
                    customDrivers = list
                    val updated = settings.copy(customDriverName = importedName)
                    settings = updated
                    withContext(Dispatchers.IO) { engine.saveSettings(updated) }
                }
            }
        }
    }

    val skinPngPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) { engine.importCustomSkinPng(uri) }
                if (res.isSuccess) {
                    hasCustomSkin = true
                }
            }
        }
    }

    val updateSettings: (HorizonSettings) -> Unit = remember(engine) {
        { updated ->
            settings = updated
            engine.saveSettings(updated)
        }
    }

    val updateModSetting: (String, Boolean) -> Unit = remember(engine) {
        { key, enabled ->
            modSettings = engine.saveModSetting(key, enabled)
        }
    }

    val startSetup: () -> Unit = {
        launchError = null
        showDownloadDialog = true
        setupProgress = SetupProgress(
            active = true,
            versionId = HORIZON_MC_VERSION,
            stageTitle = "Starting Mojang 26.3 download...",
        )
        engine.startDownloadAndSetup(scope) { prog ->
            setupProgress = prog
            if (prog.isFinished) {
                scope.launch {
                    val prepared = withContext(Dispatchers.IO) { engine.isVersionPrepared() }
                    versionReady = prepared
                    installedSizeMib = withContext(Dispatchers.IO) { if (prepared) engine.getInstalledSizeMib() else 0f }
                    auditReport = withContext(Dispatchers.IO) { engine.auditInstallationGraded() }
                }
            }
        }
    }

    val onPlayClick: () -> Unit = {
        launchError = null
        if (!versionReady) {
            startSetup()
        } else if (activeAccount == null) {
            selectedTab = 2
            showOfflineAccountDialog = true
        } else {
            scope.launch {
                launchingGameStage = "Applying video, shader & Smart RAM configs..."
                delay(140)
                launchingGameStage = "Syncing active mods & touch control layout..."
                delay(120)
                launchingGameStage = "Launching Horizon Rust MC $HORIZON_MC_VERSION..."
                val result = withContext(Dispatchers.IO) { engine.launchHorizonClient() }
                launchingGameStage = null
                if (!result.launched) {
                    launchError = result.errorMessage
                }
            }
        }
    }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    DiamondLauncherTheme(
        darkTheme = settings.darkTheme,
        dynamicColor = settings.dynamicColor,
        amoledDark = settings.amoledDark,
        accentColorName = settings.accentColorName,
        expressiveMotion = settings.expressiveMotion,
    ) {
        if (!introLoaded || needsOptimization) {
            val introScale = remember { Animatable(0.88f) }
            val animatedOptProgress by animateFloatAsState(
                targetValue = optimizationProgress,
                animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
                label = "opt_progress",
            )
            LaunchedEffect(Unit) {
                introScale.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 380f),
                )
            }
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background,
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 28.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.graphicsLayer {
                            scaleX = introScale.value
                            scaleY = introScale.value
                        },
                    ) {
                        AppLauncherIconBadge(size = 82.dp)
                        Text(
                            text = "Optimizing Diamond Launcher",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                        ) {
                            Text(
                                text = "One-time setup for update • Fast boot enabled",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                        }
                        Text(
                            text = optimizationStep,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LinearProgressIndicator(
                            progress = { animatedOptProgress },
                            modifier = Modifier
                                .width(220.dp)
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                        )
                    }
                }
            }
            return@DiamondLauncherTheme
        }
        val editingLayout = activeEditorLayout
        if (editingLayout != null) {
            TouchControlEditorScreen(
                initialLayout = editingLayout,
                onSavedLayout = { saved ->
                    scope.launch(Dispatchers.IO) {
                        val layouts = TouchControlsManager.listLayouts(context)
                        withContext(Dispatchers.Main) {
                            availableControlLayouts = layouts
                            globalTouchSettings = globalTouchSettings.copy(activeLayoutName = saved.name)
                            TouchControlsManager.saveGlobalSettings(context, globalTouchSettings)
                        }
                    }
                },
                onExitEditor = {
                    scope.launch(Dispatchers.IO) {
                        val layouts = TouchControlsManager.listLayouts(context)
                        withContext(Dispatchers.Main) {
                            availableControlLayouts = layouts
                            activeEditorLayout = null
                        }
                    }
                },
            )
            return@DiamondLauncherTheme
        }

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.systemBars),
                ) {
                    LandscapeNavigationRail(
                        selectedTab = selectedTab,
                        onSelectTab = {
                            if (it != 4) activeSettingsCategory = null
                            selectedTab = it
                        },
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                    ) {
                        HeaderBar(
                            onOpenCrashInspector = {
                                scope.launch {
                                    val report = withContext(Dispatchers.IO) { CrashDetector.loadLatestLogAndLogcat(context) }
                                    CrashDetector.launchCrashActivity(context, report)
                                }
                            },
                            compact = true,
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                        ) {
                            TabContentHost(
                                selectedTab = selectedTab,
                                isLandscape = true,
                                versionReady = versionReady,
                                installedSizeMib = installedSizeMib,
                                activeAccount = activeAccount,
                                accounts = accounts,
                                gpuInfo = engine.gpuInfo,
                                rendererLabel = engine.rendererLabelForApi(settings.graphicsApi),
                                settings = settings,
                                onUpdateSettings = updateSettings,
                                activeQuickTile = activeQuickTile,
                                onToggleQuickTile = { tile ->
                                    activeQuickTile = if (activeQuickTile == tile) ActiveQuickTile.NONE else tile
                                },
                                launchError = launchError,
                                onDismissLaunchError = { launchError = null },
                                onStartDownloadSetup = startSetup,
                                onPlayClick = onPlayClick,
                                mods = modsList,
                                shaders = shadersList,
                                resourcePacks = resourcePacksList,
                                onTogglePack = { item, enabled ->
                                    when (item.kind) {
                                        PackKind.MOD -> modsList = modsList.map { if (it.id == item.id) it.copy(enabled = enabled) else it }
                                        PackKind.SHADER -> shadersList = shadersList.map { it.copy(enabled = if (it.id == item.id) enabled else false) }
                                        PackKind.RESOURCE -> resourcePacksList = resourcePacksList.map { if (it.id == item.id) it.copy(enabled = enabled) else it }
                                    }
                                    scope.launch(Dispatchers.IO) {
                                        engine.setPackEnabled(item, enabled)
                                    }
                                },
                                onDeletePack = { item ->
                                    when (item.kind) {
                                        PackKind.MOD -> modsList = modsList.filterNot { it.id == item.id }
                                        PackKind.SHADER -> shadersList = shadersList.filterNot { it.id == item.id }
                                        PackKind.RESOURCE -> resourcePacksList = resourcePacksList.filterNot { it.id == item.id }
                                    }
                                    scope.launch(Dispatchers.IO) {
                                        engine.deletePack(item)
                                    }
                                },
                                onImportPack = { kind ->
                                    importTargetKind = kind
                                    documentPicker.launch(arrayOf(arrayOf("*", "*").joinToString("/")))
                                },
                                onOpenCreateOfflineAccount = { showOfflineAccountDialog = true },
                                onOpenMicrosoftComingSoon = { ProfileManagerActivity.launch(context, startMsaLogin = true) },
                                onSelectAccount = { uuid ->
                                    engine.selectAccount(uuid)
                                    accountsState = engine.loadAccounts()
                                },
                                onUpdateSkinModel = { uuid, model ->
                                    engine.updateAccountSkinModel(uuid, model)
                                    accountsState = engine.loadAccounts()
                                },
                                onRemoveAccount = { uuid ->
                                    accountsState = engine.removeAccount(uuid)
                                },
                                activeSettingsCategory = activeSettingsCategory,
                                onSelectSettingsCategory = { activeSettingsCategory = it },
                                auditGrade = auditReport.grade,
                                smartMemory = smartMemory,
                                globalTouchSettings = globalTouchSettings,
                                availableControlLayouts = availableControlLayouts,
                                onUpdateTouchSettings = { updated ->
                                    globalTouchSettings = updated
                                    scope.launch(Dispatchers.IO) {
                                        TouchControlsManager.saveGlobalSettings(context, updated)
                                    }
                                },
                                onOpenControlEditorDialog = {
                                    scope.launch(Dispatchers.IO) {
                                        val layouts = TouchControlsManager.listLayouts(context)
                                        withContext(Dispatchers.Main) {
                                            availableControlLayouts = layouts
                                            showControlPickerDialog = true
                                        }
                                    }
                                },
                                onOpenVerifyDialog = {
                                    scope.launch {
                                        auditReport = withContext(Dispatchers.IO) { engine.auditInstallationGraded() }
                                        showVerifyDialog = true
                                    }
                                },
                                onOpenWhatsNewDialog = { showWhatsNewDialog = true },
                                modSettings = modSettings,
                                onUpdateModSetting = updateModSetting,
                                onOpenSafFiles = openSafInGoogleFiles,
                                onOpenCrashInspector = {
                                    scope.launch {
                                    val report = withContext(Dispatchers.IO) { CrashDetector.loadLatestLogAndLogcat(context) }
                                    CrashDetector.launchCrashActivity(context, report)
                                }
                                },
                                preloadedShaders = preloadedShaders,
                                onRefreshPacks = { packRefreshTick++ },
                                onOpenDiagnostics = {
                                    scope.launch {
                                        diagnosticsReportText = withContext(Dispatchers.IO) {
                                            engine.buildFullDiagnosticsReport()
                                        }
                                        showDiagnosticsDialog = true
                                    }
                                },
                                onJumpToSettingsCategory = { cat ->
                                    activeSettingsCategory = cat
                                    selectedTab = 4
                                },
                customDrivers = customDrivers,
                hasCustomSkin = hasCustomSkin,
                onImportDriverZip = { driverZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                onDeleteDriver = { drvName ->
                    scope.launch {
                        withContext(Dispatchers.IO) { engine.deleteCustomDriver(drvName) }
                        val list = withContext(Dispatchers.IO) { engine.listCustomDrivers() }
                        customDrivers = list
                        if (settings.customDriverName == drvName) {
                            updateSettings(settings.copy(customDriverName = "System Default"))
                        }
                    }
                },
                onImportSkinPng = { skinPngPicker.launch(arrayOf("image/png", "image/*")) },
                            )
                        }
                    }
                }
            } else {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentWindowInsets = WindowInsets.systemBars,
                    bottomBar = {
                        PortraitNavigationBar(
                            selectedTab = selectedTab,
                            onSelectTab = {
                                if (it != 4) activeSettingsCategory = null
                                selectedTab = it
                            },
                        )
                    },
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 16.dp),
                    ) {
                        Spacer(modifier = Modifier.height(8.dp))

                        HeaderBar(
                            onOpenCrashInspector = {
                                scope.launch {
                                    val report = withContext(Dispatchers.IO) { CrashDetector.loadLatestLogAndLogcat(context) }
                                    CrashDetector.launchCrashActivity(context, report)
                                }
                            },
                            compact = false,
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                        ) {
                            TabContentHost(
                                selectedTab = selectedTab,
                                isLandscape = false,
                                versionReady = versionReady,
                                installedSizeMib = installedSizeMib,
                                activeAccount = activeAccount,
                                accounts = accounts,
                                gpuInfo = engine.gpuInfo,
                                rendererLabel = engine.rendererLabelForApi(settings.graphicsApi),
                                settings = settings,
                                onUpdateSettings = updateSettings,
                                activeQuickTile = activeQuickTile,
                                onToggleQuickTile = { tile ->
                                    activeQuickTile = if (activeQuickTile == tile) ActiveQuickTile.NONE else tile
                                },
                                launchError = launchError,
                                onDismissLaunchError = { launchError = null },
                                onStartDownloadSetup = startSetup,
                                onPlayClick = onPlayClick,
                                mods = modsList,
                                shaders = shadersList,
                                resourcePacks = resourcePacksList,
                                onTogglePack = { item, enabled ->
                                    when (item.kind) {
                                        PackKind.MOD -> modsList = modsList.map { if (it.id == item.id) it.copy(enabled = enabled) else it }
                                        PackKind.SHADER -> shadersList = shadersList.map { it.copy(enabled = if (it.id == item.id) enabled else false) }
                                        PackKind.RESOURCE -> resourcePacksList = resourcePacksList.map { if (it.id == item.id) it.copy(enabled = enabled) else it }
                                    }
                                    scope.launch(Dispatchers.IO) {
                                        engine.setPackEnabled(item, enabled)
                                    }
                                },
                                onDeletePack = { item ->
                                    when (item.kind) {
                                        PackKind.MOD -> modsList = modsList.filterNot { it.id == item.id }
                                        PackKind.SHADER -> shadersList = shadersList.filterNot { it.id == item.id }
                                        PackKind.RESOURCE -> resourcePacksList = resourcePacksList.filterNot { it.id == item.id }
                                    }
                                    scope.launch(Dispatchers.IO) {
                                        engine.deletePack(item)
                                    }
                                },
                                onImportPack = { kind ->
                                    importTargetKind = kind
                                    documentPicker.launch(arrayOf(arrayOf("*", "*").joinToString("/")))
                                },
                                onOpenCreateOfflineAccount = { showOfflineAccountDialog = true },
                                onOpenMicrosoftComingSoon = { ProfileManagerActivity.launch(context, startMsaLogin = true) },
                                onSelectAccount = { uuid ->
                                    engine.selectAccount(uuid)
                                    accountsState = engine.loadAccounts()
                                },
                                onUpdateSkinModel = { uuid, model ->
                                    engine.updateAccountSkinModel(uuid, model)
                                    accountsState = engine.loadAccounts()
                                },
                                onRemoveAccount = { uuid ->
                                    accountsState = engine.removeAccount(uuid)
                                },
                                activeSettingsCategory = activeSettingsCategory,
                                onSelectSettingsCategory = { activeSettingsCategory = it },
                                auditGrade = auditReport.grade,
                                smartMemory = smartMemory,
                                globalTouchSettings = globalTouchSettings,
                                availableControlLayouts = availableControlLayouts,
                                onUpdateTouchSettings = { updated ->
                                    globalTouchSettings = updated
                                    scope.launch(Dispatchers.IO) {
                                        TouchControlsManager.saveGlobalSettings(context, updated)
                                    }
                                },
                                onOpenControlEditorDialog = {
                                    scope.launch(Dispatchers.IO) {
                                        val layouts = TouchControlsManager.listLayouts(context)
                                        withContext(Dispatchers.Main) {
                                            availableControlLayouts = layouts
                                            showControlPickerDialog = true
                                        }
                                    }
                                },
                                onOpenVerifyDialog = {
                                    scope.launch {
                                        auditReport = withContext(Dispatchers.IO) { engine.auditInstallationGraded() }
                                        showVerifyDialog = true
                                    }
                                },
                                onOpenWhatsNewDialog = { showWhatsNewDialog = true },
                                modSettings = modSettings,
                                onUpdateModSetting = updateModSetting,
                                onOpenSafFiles = openSafInGoogleFiles,
                                onOpenCrashInspector = {
                                    scope.launch {
                                    val report = withContext(Dispatchers.IO) { CrashDetector.loadLatestLogAndLogcat(context) }
                                    CrashDetector.launchCrashActivity(context, report)
                                }
                                },
                                preloadedShaders = preloadedShaders,
                                onRefreshPacks = { packRefreshTick++ },
                                onOpenDiagnostics = {
                                    scope.launch {
                                        diagnosticsReportText = withContext(Dispatchers.IO) {
                                            engine.buildFullDiagnosticsReport()
                                        }
                                        showDiagnosticsDialog = true
                                    }
                                },
                                onJumpToSettingsCategory = { cat ->
                                    activeSettingsCategory = cat
                                    selectedTab = 4
                                },
                customDrivers = customDrivers,
                hasCustomSkin = hasCustomSkin,
                onImportDriverZip = { driverZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                onDeleteDriver = { drvName ->
                    scope.launch {
                        withContext(Dispatchers.IO) { engine.deleteCustomDriver(drvName) }
                        val list = withContext(Dispatchers.IO) { engine.listCustomDrivers() }
                        customDrivers = list
                        if (settings.customDriverName == drvName) {
                            updateSettings(settings.copy(customDriverName = "System Default"))
                        }
                    }
                },
                onImportSkinPng = { skinPngPicker.launch(arrayOf("image/png", "image/*")) },
                            )
                        }
                    }
                }
            }

            if (showDownloadDialog) {
                HorizonDownloadSetupDialog(
                    progress = setupProgress,
                    onCancel = {
                        engine.cancelDownload()
                        showDownloadDialog = false
                    },
                    onCloseFinished = {
                        showDownloadDialog = false
                    },
                    onCreateAccountOnProfileTab = {
                        showDownloadDialog = false
                        selectedTab = 2
                        if (activeAccount == null) {
                            showOfflineAccountDialog = true
                        }
                    },
                )
            }

            if (showOfflineAccountDialog) {
                CreateOfflineAccountDialog(
                    engine = engine,
                    onDismiss = { showOfflineAccountDialog = false },
                    onSaveAccount = { username, skinModel ->
                        val res = engine.createOfflineAccount(username, skinModel)
                        if (res.isSuccess) {
                            accountsState = engine.loadAccounts()
                            showOfflineAccountDialog = false
                        }
                    },
                )
            }

            if (showMicrosoftComingSoonDialog) {
                AlertDialog(
                    onDismissRequest = { showMicrosoftComingSoonDialog = false },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    },
                    title = {
                        Text(
                            text = "Microsoft Account Login",
                            fontWeight = FontWeight.Bold,
                        )
                    },
                    text = {
                        Text(
                            text = "Microsoft OAuth login is coming soon. Create an Offline Account right now to generate a valid Java UUID v3 and play immediately.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showMicrosoftComingSoonDialog = false
                                showOfflineAccountDialog = true
                            },
                        ) {
                            Text("Create Offline Account")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showMicrosoftComingSoonDialog = false }) {
                            Text("Close")
                        }
                    },
                )
            }

            if (showVerifyDialog) {
                VerifyAuditDialog(
                    report = auditReport,
                    onDismiss = {
                    showVerifyDialog = false
                    scope.launch {
                        val prepared = withContext(Dispatchers.IO) { engine.isVersionPrepared() }
                        versionReady = prepared
                        if (prepared) {
                            installedSizeMib = withContext(Dispatchers.IO) { engine.getInstalledSizeMib() }
                        }
                        auditReport = withContext(Dispatchers.IO) { engine.auditInstallationGraded() }
                    }
                },
                    onRunSetupAgain = {
                        showVerifyDialog = false
                        startSetup()
                    },
                )
            }

            val activeLaunchStage = launchingGameStage
        if (activeLaunchStage != null) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        AppLauncherIconBadge(size = 64.dp)
                        Text(
                            text = "Starting Minecraft $HORIZON_MC_VERSION",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = activeLaunchStage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                            ) {
                                Text(
                                    text = if (settings.graphicsApi == "opengl") "OpenGL ES" else "Vulkan",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                            ) {
                                Text(
                                    text = "${settings.memoryMb} MB RAM",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                            ) {
                                Text(
                                    text = "${modsList.count { it.enabled }} Mods",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (modLoadErrors.isNotEmpty()) {
            AlertDialog(
                onDismissRequest = {
                    engine.clearModLoadErrors()
                    modLoadErrors = emptyList()
                },
                icon = {
                    Icon(
                        imageVector = Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                    )
                },
                title = {
                    Text(
                        text = if (modLoadErrors.size == 1) "Mod Failed to Load" else "${modLoadErrors.size} Mods Failed to Load",
                        fontWeight = FontWeight.Bold,
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "The following .dmod file(s) failed during the last game launch:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        modLoadErrors.forEach { (modId, reason) ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(3.dp),
                                ) {
                                    Text(
                                        text = modId,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                    )
                                    Text(
                                        text = reason,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.88f),
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            engine.clearModLoadErrors()
                            modLoadErrors = emptyList()
                        },
                    ) {
                        Text("Got it")
                    }
                },
            )
        }

        if (showWhatsNewDialog) {
                AlertDialog(
                    onDismissRequest = { showWhatsNewDialog = false },
                    icon = {
                        Surface(
                            modifier = Modifier.size(46.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.NewReleases,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    },
                    title = {
                        Text(
                            text = "What's New • Update Log",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer,
                            ) {
                                Text(
                                    text = "0.0.1 BETA",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                            Text(
                                text = "• Horizon Rust MC 26.3 engine with Vulkan & OpenGL ES\n• Native in-game GPU virtual mouse & redesigned two-pane floating menu\n• Full .dmod WebAssembly mod loader with icons & persistent settings\n• Live Modrinth browser with Shaders, Resource Packs & Worlds filters\n• 32-bit ARMv7 + 1 GB low-RAM optimization profiles",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = { showWhatsNewDialog = false }) {
                            Text("Close")
                        }
                    },
                )
            }

            if (showDiagnosticsDialog) {
                val clipMgr = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                var copiedDiag by remember { mutableStateOf(false) }
                AlertDialog(
                    onDismissRequest = { showDiagnosticsDialog = false },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    },
                    title = {
                        Text(
                            text = "Performance & System Diagnostics",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        )
                    },
                    text = {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 200.dp, max = 360.dp),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(12.dp),
                            ) {
                                Text(
                                    text = diagnosticsReportText.ifBlank { "Collecting report..." },
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                clipMgr?.setPrimaryClip(
                                    android.content.ClipData.newPlainText("Diamond Diagnostics", diagnosticsReportText),
                                )
                                copiedDiag = true
                            },
                        ) {
                            Text(if (copiedDiag) "Copied!" else "Copy Full Report")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDiagnosticsDialog = false }) {
                            Text("Close")
                        }
                    },
                )
            }

            if (showControlPickerDialog) {
                AlertDialog(
                    onDismissRequest = { showControlPickerDialog = false },
                    icon = {
                        Surface(
                            modifier = Modifier.size(46.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Gamepad,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    },
                    title = {
                        Text(
                            text = "Which control do you want to edit?",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            val defaultLayout = availableControlLayouts.firstOrNull {
                                it.name.equals(TouchControlsManager.DEFAULT_LAYOUT_NAME, ignoreCase = true)
                            } ?: TouchControlsManager.buildDefaultLayout()

                            Surface(
                                onClick = {
                                    showControlPickerDialog = false
                                    activeEditorLayout = defaultLayout
                                },
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "[ Default Control ]",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    )
                                    Text(
                                        text = "Author: ${TouchControlsManager.DEFAULT_AUTHOR} • Edits save as a new layout",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    )
                                }
                            }

                            val customLayouts = availableControlLayouts.filterNot {
                                it.name.equals(TouchControlsManager.DEFAULT_LAYOUT_NAME, ignoreCase = true)
                            }
                            if (customLayouts.isNotEmpty()) {
                                Text(
                                    text = "Other Controls (Touch_Controls/)",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                customLayouts.forEach { layout ->
                                    Surface(
                                        onClick = {
                                            showControlPickerDialog = false
                                            activeEditorLayout = layout
                                        },
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text(
                                                text = layout.name,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            )
                                            Text(
                                                text = "Author: ${layout.author} • ${layout.buttons.size} buttons",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    showControlPickerDialog = false
                                    showCreateNewControlDialog = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("[ Create New Controls ]", fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showControlPickerDialog = false }) {
                            Text("Cancel")
                        }
                    },
                )
            }

            if (showCreateNewControlDialog) {
                var newLayoutName by remember { mutableStateOf("") }
                var newLayoutAuthor by remember { mutableStateOf(TouchControlsManager.DEFAULT_AUTHOR) }
                var createErr by remember { mutableStateOf<String?>(null) }

                AlertDialog(
                    onDismissRequest = { showCreateNewControlDialog = false },
                    title = {
                        Text(
                            text = "Create New Controls",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = newLayoutName,
                                onValueChange = {
                                    newLayoutName = it
                                    createErr = null
                                },
                                label = { Text("Unique Control Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                            )
                            OutlinedTextField(
                                value = newLayoutAuthor,
                                onValueChange = { newLayoutAuthor = it },
                                label = { Text("Author") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                            )
                            createErr?.let {
                                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val base = TouchControlsManager.buildDefaultLayout().copy(
                                    name = newLayoutName.trim(),
                                    author = newLayoutAuthor.trim().ifBlank { TouchControlsManager.DEFAULT_AUTHOR },
                                    isDefault = false,
                                )
                                scope.launch(Dispatchers.IO) {
                                    TouchControlsManager.saveCustomLayout(
                                        context = context,
                                        layout = base,
                                        allowOverwriteExistingCustom = false,
                                    ).onSuccess { created ->
                                        val layouts = TouchControlsManager.listLayouts(context)
                                        withContext(Dispatchers.Main) {
                                            availableControlLayouts = layouts
                                            globalTouchSettings = globalTouchSettings.copy(activeLayoutName = created.name)
                                            TouchControlsManager.saveGlobalSettings(context, globalTouchSettings)
                                            showCreateNewControlDialog = false
                                            activeEditorLayout = created
                                        }
                                    }.onFailure { err ->
                                        withContext(Dispatchers.Main) {
                                            createErr = err.message
                                        }
                                    }
                                }
                            },
                        ) {
                            Text("Create & Open Editor")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCreateNewControlDialog = false }) {
                            Text("Cancel")
                        }
                    },
                )
            }


        }
    }
}

@Composable
private fun MaterialWavyProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceContainerHighest,
    strokeWidth: Dp = 6.dp,
    waveAmplitude: Dp = 3.5.dp,
    waveLength: Dp = 26.dp,
) {
    val clamped = progress.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = clamped,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "wavy_progress",
    )
    val phase = 0f

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(22.dp),
    ) {
        val widthPx = size.width
        val centerY = size.height / 2f
        val strokePx = strokeWidth.toPx()
        val ampPx = if (animatedProgress in 0.01f..0.99f) waveAmplitude.toPx() else 0f
        val waveLenPx = waveLength.toPx().coerceAtLeast(12f)
        val activeEndPx = widthPx * animatedProgress

        if (activeEndPx < widthPx) {
            val gapPx = strokePx * 1.4f
            val trackStart = (activeEndPx + gapPx).coerceAtMost(widthPx)
            drawLine(
                color = trackColor,
                start = Offset(trackStart, centerY),
                end = Offset(widthPx, centerY),
                strokeWidth = strokePx,
                cap = StrokeCap.Round,
            )
        }

        if (activeEndPx > 2f) {
            val path = Path()
            val stepPx = 4f
            var x = 0f
            var first = true
            while (x <= activeEndPx) {
                val angle = (x / waveLenPx) * (2f * PI.toFloat()) + phase
                val y = centerY + sin(angle) * ampPx
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
                x += stepPx
            }
            val finalAngle = (activeEndPx / waveLenPx) * (2f * PI.toFloat()) + phase
            path.lineTo(activeEndPx, centerY + sin(finalAngle) * ampPx)

            drawPath(
                path = path,
                color = activeColor,
                style = Stroke(width = strokePx, cap = StrokeCap.Round),
            )
        }
    }
}

@Composable
private fun HorizonDownloadSetupDialog(
    progress: SetupProgress,
    onCancel: () -> Unit,
    onCloseFinished: () -> Unit,
    onCreateAccountOnProfileTab: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = {
            if (progress.isFinished || progress.error != null) {
                onCloseFinished()
            }
        },
        icon = {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                color = if (progress.isFinished) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.secondaryContainer
                },
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (progress.isFinished) {
                            Icons.Rounded.CheckCircle
                        } else {
                            Icons.Rounded.CloudDownload
                        },
                        contentDescription = null,
                        tint = if (progress.isFinished) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        },
                        modifier = Modifier.size(26.dp),
                    )
                }
            }
        },
        title = {
            Text(
                text = if (progress.isFinished) {
                    "Minecraft ${progress.versionId} Ready"
                } else {
                    "Setting Up Minecraft ${progress.versionId}"
                },
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center,
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (progress.error != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Text(
                            text = progress.error,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                } else if (progress.isFinished) {
                    Text(
                        text = "Downloaded and verified full Minecraft ${progress.versionId} (${progress.totalFiles} files) and converted assets via Horizon prepare.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = "Total Downloaded",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "%.1f / %.1f MiB",
                                        progress.downloadedMib,
                                        progress.totalMib,
                                    ),
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = "Storage Write",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = String.format(Locale.US, "%.1f MiB/s", progress.storageSpeedMibPerSec),
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                )
                            }
                        }
                    }

                    Text(
                        text = "Create an Offline Account on the Profile tab so Minecraft can read your session, or close.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        text = progress.stageTitle,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface,
                    )

                    MaterialWavyProgressBar(
                        progress = progress.progressFraction,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = String.format(
                                Locale.US,
                                "%.1f / %.1f MiB",
                                progress.downloadedMib,
                                progress.totalMib,
                            ),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            text = "${(progress.progressFraction * 100).roundToInt()}% (${progress.completedFiles}/${progress.totalFiles})",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Wifi,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Internet",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.1f MiB/s", progress.internetSpeedMibPerSec),
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    )
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Storage,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Storage",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.1f MiB/s", progress.storageSpeedMibPerSec),
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    )
                                }
                            }
                        }
                    }

                    if (progress.currentFile.isNotBlank()) {
                        Text(
                            text = progress.currentFile,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (progress.isFinished) {
                Button(onClick = onCreateAccountOnProfileTab) {
                    Icon(
                        imageVector = Icons.Rounded.PersonAdd,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Create Account on Profile Tab")
                }
            }
        },
        dismissButton = {
            if (progress.isFinished || progress.error != null) {
                OutlinedButton(onClick = onCloseFinished) {
                    Text("Close")
                }
            } else {
                TextButton(onClick = onCancel) {
                    Text("Cancel")
                }
            }
        },
    )
}

@Composable
private fun CreateOfflineAccountDialog(
    engine: HorizonEngine,
    onDismiss: () -> Unit,
    onSaveAccount: (String, String) -> Unit,
) {
    var username by remember { mutableStateOf("") }
    var selectedSkinModel by remember { mutableStateOf("Classic (Steve)") }
    val validationError = remember(username) {
        if (username.isEmpty()) null else engine.validateJavaUsername(username)
    }
    val isValid = username.isNotBlank() && validationError == null
    val previewUuid = remember(username, isValid) {
        if (isValid) engine.generateOfflineJavaUuid(username.trim()).second else "—"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.PersonAdd,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
        title = {
            Text(
                text = "Create Offline Account",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = "Minecraft: Java Edition Username Rules",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            text = "• 3 to 16 characters\n• Only A–Z, a–z, 0–9, and _\n• No spaces or special symbols",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { if (it.length <= 20) username = it },
                    label = { Text("Java Edition Username") },
                    placeholder = { Text("e.g. GoyDevv") },
                    singleLine = true,
                    isError = validationError != null,
                    supportingText = {
                        if (validationError != null) {
                            Text(
                                text = validationError,
                                color = MaterialTheme.colorScheme.error,
                            )
                        } else if (isValid) {
                            Text(
                                text = "UUID v3: $previewUuid",
                                color = MaterialTheme.colorScheme.primary,
                            )
                        } else {
                            Text("Saved to accounts.json & sessions/session-offline.json")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Classic (Steve)", "Slim (Alex)").forEach { model ->
                        FilterChip(
                            selected = selectedSkinModel == model,
                            onClick = { selectedSkinModel = model },
                            label = { Text(model) },
                            leadingIcon = if (selectedSkinModel == model) {
                                {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                }
                            } else {
                                null
                            },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSaveAccount(username.trim(), selectedSkinModel) },
                enabled = isValid,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Account")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
private fun HeaderBar(
    onOpenCrashInspector: () -> Unit,
    compact: Boolean,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppLauncherIconBadge(size = if (compact) 42.dp else 48.dp)

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "Diamond Launcher",
                    style = (if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge).copy(
                        fontWeight = FontWeight.Bold,
                    ),
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = "Horizon Rust • MC $HORIZON_MC_VERSION",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }

        FilledTonalIconButton(
            onClick = onOpenCrashInspector,
            modifier = Modifier.size(40.dp),
            colors = IconButtonDefaults.filledTonalIconButtonColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
        ) {
            Icon(
                imageVector = Icons.Rounded.BugReport,
                contentDescription = "Crash & Logcat Inspector",
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun TabContentHost(
    selectedTab: Int,
    isLandscape: Boolean,
    versionReady: Boolean,
    installedSizeMib: Float,
    activeAccount: HorizonAccount?,
    accounts: List<HorizonAccount>,
    gpuInfo: DeviceGpuInfo,
    rendererLabel: String,
    settings: HorizonSettings,
    onUpdateSettings: (HorizonSettings) -> Unit,
    activeQuickTile: ActiveQuickTile,
    onToggleQuickTile: (ActiveQuickTile) -> Unit,
    launchError: String?,
    onDismissLaunchError: () -> Unit,
    onStartDownloadSetup: () -> Unit,
    onPlayClick: () -> Unit,
    mods: List<ManagedPackItem>,
    shaders: List<ManagedPackItem>,
    resourcePacks: List<ManagedPackItem>,
    onTogglePack: (ManagedPackItem, Boolean) -> Unit,
    onDeletePack: (ManagedPackItem) -> Unit,
    onImportPack: (PackKind) -> Unit,
    onOpenCreateOfflineAccount: () -> Unit,
    onOpenMicrosoftComingSoon: () -> Unit,
    onSelectAccount: (String) -> Unit,
    onUpdateSkinModel: (String, String) -> Unit,
    onRemoveAccount: (String) -> Unit,
    activeSettingsCategory: SettingsCategory?,
    onSelectSettingsCategory: (SettingsCategory?) -> Unit,
    auditGrade: String,
    smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    globalTouchSettings: GlobalTouchSettings,
    availableControlLayouts: List<TouchControlLayout>,
    onUpdateTouchSettings: (GlobalTouchSettings) -> Unit,
    onOpenControlEditorDialog: () -> Unit,
    onOpenVerifyDialog: () -> Unit,
    onOpenWhatsNewDialog: () -> Unit,
    modSettings: Map<String, Boolean>,
    onUpdateModSetting: (String, Boolean) -> Unit,
    onOpenSafFiles: () -> Unit,
    onOpenCrashInspector: () -> Unit,
    preloadedShaders: List<ModrinthProjectHit>,
    onRefreshPacks: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onJumpToSettingsCategory: (SettingsCategory) -> Unit,
    customDrivers: List<String>,
    hasCustomSkin: Boolean,
    onImportDriverZip: () -> Unit,
    onDeleteDriver: (String) -> Unit,
    onImportSkinPng: () -> Unit,
) {
    AnimatedContent(
        targetState = selectedTab,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            (fadeIn(animationSpec = tween(durationMillis = 190, easing = FastOutSlowInEasing)) +
                scaleIn(
                    initialScale = 0.975f,
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 480f),
                )) togetherWith fadeOut(animationSpec = tween(durationMillis = 120))
        },
        label = "tab_expressive_transition",
    ) { tab ->
        when (tab) {
            0 -> HomeTabContent(
                isLandscape = isLandscape,
                versionReady = versionReady,
                installedSizeMib = installedSizeMib,
                auditGrade = auditGrade,
                smartMemory = smartMemory,
                globalTouchSettings = globalTouchSettings,
                activeAccount = activeAccount,
                hasCustomSkin = hasCustomSkin,
                modsCount = mods.count { it.enabled },
                activeShaderLabel = when {
                    settings.builtinShaderEnabled -> "Built-In"
                    else -> shaders.firstOrNull { it.enabled }?.title ?: "None"
                },
                rendererLabel = rendererLabel,
                settings = settings,
                launchError = launchError,
                onDismissLaunchError = onDismissLaunchError,
                onStartDownloadSetup = onStartDownloadSetup,
                onOpenVerifyDialog = onOpenVerifyDialog,
                onOpenWhatsNewDialog = onOpenWhatsNewDialog,
                onOpenControlEditorDialog = onOpenControlEditorDialog,
                onOpenDiagnostics = onOpenDiagnostics,
                onJumpToSettingsCategory = onJumpToSettingsCategory,
                onPlayClick = onPlayClick,
                onOpenProfileTab = { ProfileManagerActivity.launch(context, startMsaLogin = false) },
            )

            1 -> VersionsAndProfilesTabContent(
                versionReady = versionReady,
                installedSizeMib = installedSizeMib,
                auditGrade = auditGrade,
                rendererLabel = rendererLabel,
                settings = settings,
                smartMemory = smartMemory,
                modsCount = mods.count { it.enabled },
                onPlayClick = onPlayClick,
                onReverifyGameFiles = onOpenVerifyDialog,
            )

            2 -> DiscoverBrowserTabContent(
                preloadedShaders = preloadedShaders,
                installedPackKeys = remember(shaders, resourcePacks) {
                    (shaders + resourcePacks).map { it.title.lowercase(Locale.US) }.toSet()
                },
                onRefreshPacks = onRefreshPacks,
                onImportDmod = { onImportPack(PackKind.MOD) },
                onImportShader = { onImportPack(PackKind.SHADER) },
                onImportResourcePack = { onImportPack(PackKind.RESOURCE) },
            )

            3 -> ManagerTabContent(
                mods = mods,
                shaders = shaders,
                resourcePacks = resourcePacks,
                settings = settings,
                onUpdateSettings = onUpdateSettings,
                modSettings = modSettings,
                onUpdateModSetting = onUpdateModSetting,
                onTogglePack = onTogglePack,
                onDeletePack = onDeletePack,
                onImportPack = onImportPack,
                onOpenSafFiles = onOpenSafFiles,
            )

            4 -> SettingsTabContent(
                activeAccount = activeAccount,
                accounts = accounts,
                modsCount = mods.count { it.enabled },
                activeShader = shaders.firstOrNull { it.enabled }?.title ?: "None",
                onOpenCreateOfflineAccount = onOpenCreateOfflineAccount,
                onOpenMicrosoftComingSoon = onOpenMicrosoftComingSoon,
                onSelectAccount = onSelectAccount,
                onUpdateSkinModel = onUpdateSkinModel,
                onRemoveAccount = onRemoveAccount,
                activeCategory = activeSettingsCategory,
                onSelectCategory = onSelectSettingsCategory,
                gpuInfo = gpuInfo,
                settings = settings,
                onUpdateSettings = onUpdateSettings,
                smartMemory = smartMemory,
                globalTouchSettings = globalTouchSettings,
                availableControlLayouts = availableControlLayouts,
                onUpdateTouchSettings = onUpdateTouchSettings,
                onOpenControlEditorDialog = onOpenControlEditorDialog,
                onOpenVerifyDialog = onOpenVerifyDialog,
                onOpenSafFiles = onOpenSafFiles,
                onOpenCrashInspector = onOpenCrashInspector,
                onOpenDiagnostics = onOpenDiagnostics,
                onReverifyGameFiles = onStartDownloadSetup,
                customDrivers = customDrivers,
                hasCustomSkin = hasCustomSkin,
                onImportDriverZip = onImportDriverZip,
                onDeleteDriver = onDeleteDriver,
                onImportSkinPng = onImportSkinPng,
            )
        }
    }
}

@Composable
private fun HomeTabContent(
    isLandscape: Boolean,
    versionReady: Boolean,
    installedSizeMib: Float,
    auditGrade: String,
    smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    globalTouchSettings: GlobalTouchSettings,
    activeAccount: HorizonAccount?,
    hasCustomSkin: Boolean,
    modsCount: Int,
    activeShaderLabel: String,
    rendererLabel: String,
    settings: HorizonSettings,
    launchError: String?,
    onDismissLaunchError: () -> Unit,
    onStartDownloadSetup: () -> Unit,
    onOpenVerifyDialog: () -> Unit,
    onOpenWhatsNewDialog: () -> Unit,
    onOpenControlEditorDialog: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onJumpToSettingsCategory: (SettingsCategory) -> Unit,
    onPlayClick: () -> Unit,
    onOpenProfileTab: () -> Unit,
) {
    if (isLandscape) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(
                modifier = Modifier
                    .weight(0.52f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MinecraftHeroCard(
                    versionReady = versionReady,
                    installedSizeMib = installedSizeMib,
                    auditGrade = auditGrade,
                    rendererLabel = rendererLabel,
                    fpsLabel = if (settings.targetFps <= 0) "Uncapped" else "${settings.targetFps} FPS",
                    ramLabel = "${settings.memoryMb} MB",
                    abiLabel = if (smartMemory.is32Bit) "32-bit" else "64-bit",
                    onStartDownloadSetup = onStartDownloadSetup,
                    onOpenVerifyDialog = onOpenVerifyDialog,
                    onPlayClick = onPlayClick,
                )
                if (launchError != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = TileCardShape,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(launchError, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.weight(1f))
                            TextButton(onClick = onDismissLaunchError) { Text("OK") }
                        }
                    }
                }
            }
            Column(
                modifier = Modifier
                    .weight(0.48f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(onClick = onOpenProfileTab)
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = (activeAccount?.name?.firstOrNull()?.uppercaseChar() ?: 'P').toString(),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeAccount?.name ?: "Add Account",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = if (activeAccount?.userType == "msa") "Microsoft • 3D Studio" else "Offline • 3D Studio",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                )
                            }
                        }
                        FilledTonalButton(
                            onClick = onOpenControlEditorDialog,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        ) {
                            Icon(Icons.Rounded.Gamepad, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(globalTouchSettings.activeLayoutName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        onClick = { onJumpToSettingsCategory(SettingsCategory.GRAPHICS) },
                        shape = TileCardShape,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Rounded.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(18.dp))
                            Text("Video", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSecondaryContainer, maxLines = 1)
                            Text(settings.customDriverName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Surface(
                        onClick = { onJumpToSettingsCategory(SettingsCategory.CONTROLS) },
                        shape = TileCardShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Rounded.Gamepad, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text("Controls", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                            Text("${globalTouchSettings.sensitivityPercent}% sens", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                    Surface(
                        onClick = onOpenDiagnostics,
                        shape = TileCardShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Rounded.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                            Text("Diag", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                            Text("$modsCount mods", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
                Surface(
                    onClick = onOpenWhatsNewDialog,
                    modifier = Modifier.fillMaxWidth(),
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Release Notes • 0.0.1 BETA", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item(key = "home_hero", contentType = "hero") {
            MinecraftHeroCard(
                versionReady = versionReady,
                installedSizeMib = installedSizeMib,
                auditGrade = auditGrade,
                rendererLabel = rendererLabel,
                fpsLabel = if (settings.targetFps <= 0) "Uncapped" else "${settings.targetFps} FPS",
                ramLabel = "${settings.memoryMb} MB",
                abiLabel = if (smartMemory.is32Bit) "32-bit" else "64-bit",
                onStartDownloadSetup = onStartDownloadSetup,
                onOpenVerifyDialog = onOpenVerifyDialog,
                onPlayClick = onPlayClick,
            )
        }

        if (launchError != null) {
            item(key = "home_error") {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = TileCardShape,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = launchError,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = onDismissLaunchError) {
                            Text("OK")
                        }
                    }
                }
            }
        }

        item(key = "home_profile_controls_strip") {
            Surface(
                shape = TileCardShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = onOpenProfileTab)
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = (activeAccount?.name?.firstOrNull()?.uppercaseChar() ?: 'P').toString(),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeAccount?.name ?: "Add Account",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = if (hasCustomSkin) "Custom Skin • Offline" else "${activeAccount?.skinModel ?: "Classic"} • Offline",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = onOpenControlEditorDialog,
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Gamepad,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = globalTouchSettings.activeLayoutName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }
        }

        item(key = "home_env_summary") {
            Surface(
                shape = TileCardShape,
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            Text(
                                text = "Active Mods",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                            )
                            Text(
                                text = "$modsCount enabled",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            Text(
                                text = "Shader",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                            )
                            Text(
                                text = activeShaderLabel,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            Text(
                                text = if (settings.autoSmartRam) "Smart RAM" else "Manual RAM",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                            )
                            Text(
                                text = "${settings.memoryMb} MB",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.tertiary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }

        item(key = "home_quick_actions") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    onClick = { onJumpToSettingsCategory(SettingsCategory.GRAPHICS) },
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.weight(1f),
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            text = "Video & Drivers",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = settings.customDriverName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Surface(
                    onClick = { onJumpToSettingsCategory(SettingsCategory.CONTROLS) },
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.weight(1f),
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Gamepad,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            text = "Controls",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "${globalTouchSettings.sensitivityPercent}% sens",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Surface(
                    onClick = onOpenDiagnostics,
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.weight(1f),
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            text = "Diagnostics",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "Perf report",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }

        item(key = "home_whats_new") {
            Surface(
                onClick = onOpenWhatsNewDialog,
                modifier = Modifier.fillMaxWidth(),
                shape = TileCardShape,
                color = MaterialTheme.colorScheme.surfaceContainer,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f),
                    ) {
                        Surface(
                            modifier = Modifier.size(40.dp),
                            shape = SquircleShape,
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoAwesome,
                                    contentDescription = "What's New",
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    text = "Release Notes",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                ) {
                                    Text(
                                        text = "0.0.1 BETA",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    )
                                }
                            }
                            Text(
                                text = "Custom drivers, real-time Smart RAM & instant boot",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun MinecraftHeroCard(
    versionReady: Boolean,
    installedSizeMib: Float,
    auditGrade: String,
    rendererLabel: String,
    fpsLabel: String,
    ramLabel: String,
    abiLabel: String,
    onStartDownloadSetup: () -> Unit,
    onOpenVerifyDialog: () -> Unit,
    onPlayClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = HeroCardShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_grass_block),
                        contentDescription = "Minecraft Grass Block",
                        modifier = Modifier.size(56.dp),
                        contentScale = ContentScale.Fit,
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Minecraft",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        ) {
                            Text(
                                text = "Java $HORIZON_MC_VERSION (Horizon)",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                if (!versionReady) {
                    Button(
                        onClick = onStartDownloadSetup,
                        shape = RoundedCornerShape(50),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CloudDownload,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Download",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        )
                    }
                } else {
                    Button(
                        onClick = onPlayClick,
                        modifier = Modifier.height(46.dp),
                        shape = RoundedCornerShape(50),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Play",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                listOf(
                    rendererLabel.substringBefore(" ("),
                    fpsLabel,
                    ramLabel,
                    abiLabel,
                ).forEach { badge ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    ) {
                        Text(
                            text = badge,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (versionReady) Color(0xFF2EA043) else MaterialTheme.colorScheme.tertiary,
                            ),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val cleanGrade = auditGrade.substringBefore("•").trim().ifBlank { "A+" }
                    val statusLine = if (versionReady) {
                        if (installedSizeMib > 0.5f) {
                            String.format(Locale.US, "Ready • Grade %s • %.0f MiB", cleanGrade, installedSizeMib)
                        } else {
                            "Ready • Grade $cleanGrade"
                        }
                    } else {
                        "Not installed • Tap Download"
                    }
                    Text(
                        text = statusLine,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                TextButton(onClick = onOpenVerifyDialog) {
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Verify")
                }
            }
        }
    }
}

@Composable
private fun QuickSettingTile(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    value: String,
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    val arrowRotation by animateFloatAsState(
        targetValue = if (selected) 180f else 0f,
        animationSpec = tween(180),
        label = "tile_arrow",
    )

    Surface(
        onClick = onClick,
        modifier = modifier.height(72.dp),
        shape = TileCardShape,
        color = if (selected) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                modifier = Modifier.size(36.dp),
                shape = CircleShape,
                color = if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surfaceContainerHigh
                },
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (selected) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(18.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (selected) {
                        MaterialTheme.colorScheme.onSecondaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (selected) {
                        MaterialTheme.colorScheme.onSecondaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .size(18.dp)
                    .graphicsLayer { rotationZ = arrowRotation },
            )
        }
    }
}

@Composable
private fun QuickTileSelectorSheet(
    activeTile: ActiveQuickTile,
    activeAccount: HorizonAccount?,
    gpuInfo: DeviceGpuInfo,
    smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    settings: HorizonSettings,
    onUpdateSettings: (HorizonSettings) -> Unit,
    onCreateOfflineAccount: () -> Unit,
    onDismiss: () -> Unit,
) {
    if (activeTile == ActiveQuickTile.NONE) return

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = TileCardShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
        ) {
            val title = when (activeTile) {
                ActiveQuickTile.PROFILE -> "Active Account"
                ActiveQuickTile.RENDERER -> "Graphics API"
                ActiveQuickTile.RAM -> "Heap Memory (-Xmx)"
                ActiveQuickTile.FPS -> "Target FPS"
                ActiveQuickTile.NONE -> ""
            }

            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
            )

            Spacer(modifier = Modifier.height(8.dp))

            when (activeTile) {
                ActiveQuickTile.PROFILE -> {
                    Text(
                        text = activeAccount?.let { "${it.name} (${it.dashedUuid})" }
                            ?: "No offline account created yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FilledTonalButton(
                        onClick = {
                            onDismiss()
                            onCreateOfflineAccount()
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PersonAdd,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (activeAccount == null) "Create Offline Account" else "Switch / Add Account")
                    }
                }

                ActiveQuickTile.RENDERER -> {
                    val options = buildList {
                        add("auto" to "Auto")
                        if (gpuInfo.vulkanSupported) {
                            add("vulkan" to gpuInfo.vulkanVersionLabel)
                        }
                        add("opengl" to gpuInfo.openGlEsVersionLabel)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        options.forEach { (apiKey, label) ->
                            val isSelected = settings.graphicsApi == apiKey
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(settings.copy(graphicsApi = apiKey))
                                    onDismiss()
                                },
                                label = { Text(label) },
                                leadingIcon = if (isSelected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Rounded.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                        )
                                    }
                                } else {
                                    null
                                },
                            )
                        }
                    }
                }

                ActiveQuickTile.RAM -> {
                    Text(
                        text = "Detected: ${smartMemory.totalDeviceRamMb} MB Total • ${smartMemory.availableRamMb} MB Free • Best: ${smartMemory.recommendedAllocMb} MB",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        val isSmartSelected = settings.memoryMb == smartMemory.recommendedAllocMb
                        FilterChip(
                            selected = isSmartSelected,
                            onClick = {
                                onUpdateSettings(settings.copy(memoryMb = smartMemory.recommendedAllocMb))
                                onDismiss()
                            },
                            label = { Text("Smart Best (${smartMemory.recommendedAllocMb} MB)") },
                        )
                        val ramOptions = if (smartMemory.totalDeviceRamMb <= 2560) {
                            listOf(384, 512, 768, 1024)
                        } else {
                            listOf(1024, 1536, 2048, 3072, 4096).filter { it <= smartMemory.maxSafeAllocMb }
                        }
                        ramOptions.forEach { mb ->
                            val isSelected = settings.memoryMb == mb
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(settings.copy(memoryMb = mb))
                                    onDismiss()
                                },
                                label = { Text("${mb} MB") },
                            )
                        }
                    }
                }

                ActiveQuickTile.FPS -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(30, 60, 90, 120, 0).forEach { fps ->
                            val isSelected = settings.targetFps == fps
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val nextPresent = if (fps == 0) "immediate" else settings.presentMode
                                    onUpdateSettings(settings.copy(targetFps = fps, presentMode = nextPresent))
                                    onDismiss()
                                },
                                label = { Text(if (fps == 0) "Uncapped" else "$fps FPS") },
                            )
                        }
                    }
                }

                ActiveQuickTile.NONE -> Unit
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManagerTabContent(
    mods: List<ManagedPackItem>,
    shaders: List<ManagedPackItem>,
    resourcePacks: List<ManagedPackItem>,
    settings: HorizonSettings,
    onUpdateSettings: (HorizonSettings) -> Unit,
    modSettings: Map<String, Boolean>,
    onUpdateModSetting: (String, Boolean) -> Unit,
    onTogglePack: (ManagedPackItem, Boolean) -> Unit,
    onDeletePack: (ManagedPackItem) -> Unit,
    onImportPack: (PackKind) -> Unit,
    onOpenSafFiles: () -> Unit,
) {
    var categoryIndex by remember { mutableIntStateOf(0) }
    var expandedModId by remember { mutableStateOf<String?>(null) }
    val categories = remember(mods.size, shaders.size, resourcePacks.size) {
        listOf("Mods (${mods.size})", "Shaders (${shaders.size})", "Packs (${resourcePacks.size})")
    }
    val currentKind = when (categoryIndex) {
        0 -> PackKind.MOD
        1 -> PackKind.SHADER
        else -> PackKind.RESOURCE
    }
    val activeItems = when (currentKind) {
        PackKind.MOD -> mods
        PackKind.SHADER -> shaders
        PackKind.RESOURCE -> resourcePacks
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 14.dp),
    ) {
        item(key = "manage_toolbar") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.weight(1f)) {
                    categories.forEachIndexed { index, label ->
                        SegmentedButton(
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = categories.size),
                            onClick = { categoryIndex = index },
                            selected = categoryIndex == index,
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (categoryIndex == index) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                FilledTonalIconButton(onClick = onOpenSafFiles) {
                    Icon(
                        imageVector = Icons.Rounded.FolderOpen,
                        contentDescription = "Open in Files",
                    )
                }
                FilledTonalIconButton(onClick = { onImportPack(currentKind) }) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Import file",
                    )
                }
            }
        }

        if (currentKind == PackKind.SHADER) {
            item(key = "builtin_shader_card") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(spring(dampingRatio = 0.82f, stiffness = 420f)),
                    shape = HeroCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Built-In Diamond Shader",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = "Single-pass 60 FPS shadows, bloom, water reflections & vibrance",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = settings.builtinShaderEnabled,
                                onCheckedChange = { onUpdateSettings(settings.copy(builtinShaderEnabled = it)) },
                            )
                        }
                        AnimatedVisibility(
                            visible = settings.builtinShaderEnabled,
                            enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 420f)) + fadeIn(tween(150)),
                            exit = shrinkVertically(tween(130)) + fadeOut(tween(100)),
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                HorizontalDivider()
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text("Sun & Canopy Shadows", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text("${settings.shaderShadowStrength}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Slider(
                                        value = settings.shaderShadowStrength.toFloat(),
                                        onValueChange = { onUpdateSettings(settings.copy(shaderShadowStrength = it.roundToInt())) },
                                        valueRange = 0f..100f,
                                    )
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text("Bloom & Light Glow", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text("${settings.shaderBloomStrength}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Slider(
                                        value = settings.shaderBloomStrength.toFloat(),
                                        onValueChange = { onUpdateSettings(settings.copy(shaderBloomStrength = it.roundToInt())) },
                                        valueRange = 0f..100f,
                                    )
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text("Vibrant Color & Contrast", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text("${settings.shaderVibranceStrength}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Slider(
                                        value = settings.shaderVibranceStrength.toFloat(),
                                        onValueChange = { onUpdateSettings(settings.copy(shaderVibranceStrength = it.roundToInt())) },
                                        valueRange = 0f..100f,
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text("Water Reflections & Specular", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Switch(
                                        checked = settings.shaderWaterReflections,
                                        onCheckedChange = { onUpdateSettings(settings.copy(shaderWaterReflections = it)) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (activeItems.isEmpty()) {
            item(key = "manage_empty_${currentKind.name}") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = HeroCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FolderOpen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp),
                        )
                        Text(
                            text = when (currentKind) {
                                PackKind.MOD -> "No .dmod mods installed"
                                PackKind.SHADER -> "No external shader packs installed"
                                PackKind.RESOURCE -> "No resource packs installed"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        )
                        Text(
                            text = when (currentKind) {
                                PackKind.MOD -> "Import a .dmod package or install one from Discover."
                                PackKind.SHADER -> "Enable the Built-In Diamond Shader above or install packs from Discover."
                                PackKind.RESOURCE -> "Install resource packs from Discover or import a .zip pack."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        FilledTonalButton(onClick = { onImportPack(currentKind) }) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (currentKind == PackKind.MOD) "Import .dmod" else "Import File")
                        }
                    }
                }
            }
        } else {
            items(activeItems, key = { "${it.kind.name}_${it.id}" }) { item ->
                val isExpanded = currentKind == PackKind.MOD && expandedModId == item.id
                val modOptions: List<ModSettingSchema> = if (currentKind == PackKind.MOD) item.settingSchemas else emptyList()

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = TileCardShape,
                    color = if (item.enabled) {
                        MaterialTheme.colorScheme.surfaceContainerHigh
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    },
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            LocalPackIconImage(
                                iconPath = item.iconPath,
                                kind = item.kind,
                                enabled = item.enabled,
                                size = 48.dp,
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = item.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Switch(
                                checked = item.enabled,
                                onCheckedChange = { checked -> onTogglePack(item, checked) },
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.surfaceContainerHighest,
                                modifier = Modifier.weight(1f, fill = false),
                            ) {
                                Text(
                                    text = "${item.sizeText} • ${item.fileName}",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                if (currentKind == PackKind.MOD && modOptions.isNotEmpty()) {
                                    FilledTonalButton(
                                        onClick = { expandedModId = if (isExpanded) null else item.id },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp),
                                        shape = RoundedCornerShape(10.dp),
                                    ) {
                                        Icon(Icons.Rounded.Tune, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = if (isExpanded) "Done" else "Options",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            softWrap = false,
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { onDeletePack(item) },
                                    modifier = Modifier.size(34.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(19.dp),
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(
                            visible = isExpanded && modOptions.isNotEmpty(),
                            enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 420f)) + fadeIn(tween(150)),
                            exit = shrinkVertically(tween(120)) + fadeOut(tween(90)),
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                Text(
                                    text = "Mod Configuration",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                )
                                for (schema in modOptions) {
                                    val optChecked = modSettings[schema.key] ?: schema.defaultBool
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Text(
                                            text = schema.label,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f),
                                        )
                                        Switch(
                                            checked = optChecked,
                                            onCheckedChange = { next -> onUpdateModSetting(schema.key, next) },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileTabContent(
    activeAccount: HorizonAccount?,
    accounts: List<HorizonAccount>,
    versionReady: Boolean,
    modsCount: Int,
    activeShader: String,
    onOpenCreateOfflineAccount: () -> Unit,
    onOpenMicrosoftComingSoon: () -> Unit,
    onSelectAccount: (String) -> Unit,
    onUpdateSkinModel: (String, String) -> Unit,
    onRemoveAccount: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (activeAccount == null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = HeroCardShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Surface(
                        modifier = Modifier.size(72.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(36.dp),
                            )
                        }
                    }

                    Text(
                        text = "No accounts logged in",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                    )

                    Text(
                        text = "Create an Offline Java Account so Minecraft can read your profile and session.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )

                    Button(
                        onClick = onOpenCreateOfflineAccount,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PersonAdd,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Create Offline Account",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                    }

                    OutlinedButton(
                        onClick = onOpenMicrosoftComingSoon,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Login Microsoft Account (Coming Soon)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                        )
                    }
                }
            }
        } else {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = HeroCardShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "@${activeAccount.name}",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Rounded.Verified,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp),
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalIconButton(
                                onClick = onOpenCreateOfflineAccount,
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PersonAdd,
                                    contentDescription = "Add Account",
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                            FilledTonalIconButton(
                                onClick = { onRemoveAccount(activeAccount.uuid) },
                                modifier = Modifier.size(36.dp),
                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                ),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Logout,
                                    contentDescription = "Log out",
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(CircleShape)
                                .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = activeAccount.name.take(2).uppercase(Locale.US),
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                        ) {
                            SocialCounterColumn(count = "0", label = "Friends")
                            SocialCounterColumn(count = "0", label = "Followers")
                            SocialCounterColumn(count = "0", label = "Following")
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = "${activeAccount.name} • Offline Java Edition",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                        Text(
                            text = "UUID v3: ${activeAccount.dashedUuid}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val nextModel = if (activeAccount.skinModel.startsWith("Classic")) {
                                    "Slim (Alex)"
                                } else {
                                    "Classic (Steve)"
                                }
                                onUpdateSkinModel(activeAccount.uuid, nextModel)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text(activeAccount.skinModel.substringBefore(" "))
                        }

                        OutlinedButton(
                            onClick = onOpenMicrosoftComingSoon,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text("MS Login (Soon)")
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StatBadgeCard(
                    modifier = Modifier.weight(1f),
                    label = "MC $HORIZON_MC_VERSION",
                    value = if (versionReady) "Ready" else "Not Setup",
                )
                StatBadgeCard(
                    modifier = Modifier.weight(1f),
                    label = "Mods",
                    value = "$modsCount",
                )
                StatBadgeCard(
                    modifier = Modifier.weight(1f),
                    label = "Shader",
                    value = activeShader.substringBefore(" "),
                )
            }

            if (accounts.size > 1) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = "Saved Accounts",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                        accounts.forEach { acc ->
                            val isSelected = acc.uuid == activeAccount.uuid
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onSelectAccount(acc.uuid) }
                                    .padding(vertical = 6.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = acc.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    ),
                                )
                                if (isSelected) {
                                    Text(
                                        text = "Active",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialCounterColumn(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun StatBadgeCard(modifier: Modifier = Modifier, label: String, value: String) {
    Surface(
        modifier = modifier,
        shape = TileCardShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SettingsTabContent(
    activeAccount: HorizonAccount?,
    accounts: List<HorizonAccount>,
    modsCount: Int,
    activeShader: String,
    onOpenCreateOfflineAccount: () -> Unit,
    onOpenMicrosoftComingSoon: () -> Unit,
    onSelectAccount: (String) -> Unit,
    onUpdateSkinModel: (String, String) -> Unit,
    onRemoveAccount: (String) -> Unit,
    activeCategory: SettingsCategory?,
    onSelectCategory: (SettingsCategory?) -> Unit,
    gpuInfo: DeviceGpuInfo,
    settings: HorizonSettings,
    onUpdateSettings: (HorizonSettings) -> Unit,
    smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    globalTouchSettings: GlobalTouchSettings,
    availableControlLayouts: List<TouchControlLayout>,
    onUpdateTouchSettings: (GlobalTouchSettings) -> Unit,
    onOpenControlEditorDialog: () -> Unit,
    onOpenVerifyDialog: () -> Unit,
    onOpenSafFiles: () -> Unit,
    onOpenCrashInspector: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onReverifyGameFiles: () -> Unit,
    customDrivers: List<String>,
    hasCustomSkin: Boolean,
    onImportDriverZip: () -> Unit,
    onDeleteDriver: (String) -> Unit,
    onImportSkinPng: () -> Unit,
) {
    val context = LocalContext.current
    val cpuCores = remember { Runtime.getRuntime().availableProcessors().coerceAtLeast(1) }

    AnimatedContent(
        targetState = activeCategory,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            if (targetState != null) {
                (slideInHorizontally(tween(210, easing = FastOutSlowInEasing)) { it / 6 } + fadeIn(tween(180))) togetherWith
                    fadeOut(tween(110))
            } else {
                (slideInHorizontally(tween(210, easing = FastOutSlowInEasing)) { -it / 6 } + fadeIn(tween(180))) togetherWith
                    fadeOut(tween(110))
            }
        },
        label = "settings_category_transition",
    ) { category ->
        if (category == null) {
            val categoryBadges = mapOf(
                SettingsCategory.CONTROLS to globalTouchSettings.activeLayoutName,
                SettingsCategory.GRAPHICS to (if (settings.customDriverName != "System Default") settings.customDriverName else if (settings.targetFps <= 0) "Uncapped" else "${settings.targetFps} FPS"),
                SettingsCategory.CULLING to (if (settings.gpuCulling) "GPU Early-Z" else "Leaf ${settings.leafCulling}"),
                SettingsCategory.MEMORY to (if (settings.autoSmartRam) "Auto • ${settings.memoryMb} MB" else "${settings.memoryMb} MB"),
                SettingsCategory.STORAGE to "SAF Ready",
                SettingsCategory.APPEARANCE to (if (settings.amoledDark && settings.darkTheme) "AMOLED" else if (settings.darkTheme) "Dark" else "Light"),
            )
            val orderedCategories = listOf(
                "Gameplay & Display" to listOf(
                    SettingsCategory.CONTROLS,
                    SettingsCategory.GRAPHICS,
                    SettingsCategory.CULLING,
                    SettingsCategory.MEMORY,
                ),
                "Storage, Logs & App" to listOf(
                    SettingsCategory.STORAGE,
                    SettingsCategory.APPEARANCE,
                ),
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                var profileExpanded by remember { mutableStateOf(false) }
                Card(
                    shape = HeroCardShape,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(spring(dampingRatio = 0.82f, stiffness = 420f)),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { profileExpanded = !profileExpanded },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(46.dp),
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = (activeAccount?.name?.firstOrNull()?.uppercaseChar() ?: 'P').toString(),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onPrimary,
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = activeAccount?.name ?: "No Account Selected",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = "Offline • ${activeAccount?.skinModel ?: "Classic"} • ${if (hasCustomSkin) "Custom Skin" else "Default Skin"} • $modsCount mods",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            FilledTonalButton(
                                onClick = { ProfileManagerActivity.launch(context, startMsaLogin = false) },
                                shape = RoundedCornerShape(12.dp),
                            ) {
                                Text("3D Studio", maxLines = 1, softWrap = false)
                            }
                        }
                        if (profileExpanded) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Custom Offline Skin (.png)",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    Text(
                                        text = if (hasCustomSkin) "Saved as horizon-skin.png" else "Import a 64x64 Minecraft skin texture",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                FilledTonalButton(
                                    onClick = onImportSkinPng,
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (hasCustomSkin) "Replace" else "Import PNG", maxLines = 1, softWrap = false)
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            Text(
                                text = "Accounts & Skin Model",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            accounts.forEach { acc ->
                                val isSelected = acc.uuid == activeAccount?.uuid
                                Surface(
                                    shape = SquircleShape,
                                    color = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectAccount(acc.uuid) },
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = acc.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Text(
                                                text = "Offline • ${acc.skinModel}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            TextButton(
                                                onClick = {
                                                    val nextSkin = if (acc.skinModel == "slim") "classic" else "slim"
                                                    onUpdateSkinModel(acc.uuid, nextSkin)
                                                },
                                            ) {
                                                Text(if (acc.skinModel == "slim") "Slim" else "Classic", maxLines = 1, softWrap = false)
                                            }
                                            IconButton(onClick = { onRemoveAccount(acc.uuid) }) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove")
                                            }
                                        }
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Button(
                                    onClick = onOpenCreateOfflineAccount,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Offline", maxLines = 1, softWrap = false)
                                }
                                OutlinedButton(
                                    onClick = onOpenMicrosoftComingSoon,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.Rounded.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Microsoft", maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }

                Surface(
                    onClick = onOpenDiagnostics,
                    modifier = Modifier.fillMaxWidth(),
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Speed,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                            Column {
                                Text(
                                    text = "Full Diagnostics & Performance Report",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                                Text(
                                    text = "Hardware, GPU, RAM headroom, active mods & log timings",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                }

                orderedCategories.forEach { (sectionTitle, cats) ->
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = sectionTitle,
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 6.dp),
                        )
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = HeroCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                cats.forEachIndexed { idx, cat ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onSelectCategory(cat) }
                                            .padding(horizontal = 16.dp, vertical = if (settings.compactDensity) 12.dp else 15.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Surface(
                                            modifier = Modifier.size(42.dp),
                                            shape = SquircleShape,
                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = cat.icon,
                                                    contentDescription = cat.title,
                                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.size(21.dp),
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = cat.title,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                color = MaterialTheme.colorScheme.onSurface,
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = cat.subtitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(50),
                                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                                        ) {
                                            Text(
                                                text = categoryBadges[cat] ?: "",
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = MaterialTheme.colorScheme.primary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    if (idx < cats.lastIndex) {
                                        HorizontalDivider(
                                            modifier = Modifier.padding(start = 72.dp, end = 16.dp),
                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(28.dp))
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FilledTonalIconButton(onClick = { onSelectCategory(null) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back to Settings",
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Surface(
                            modifier = Modifier.size(36.dp),
                            shape = SquircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = category.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            )
                            Text(
                                text = category.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }

                when (category) {
                    SettingsCategory.GRAPHICS -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = "Graphics API",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                val apiChoices = buildList {
                                    add(
                                        Triple(
                                            "auto",
                                            "Auto",
                                            "Uses ${if (gpuInfo.vulkanSupported) gpuInfo.vulkanVersionLabel else gpuInfo.openGlEsVersionLabel} with fallback",
                                        ),
                                    )
                                    if (gpuInfo.vulkanSupported) {
                                        add(
                                            Triple(
                                                "vulkan",
                                                gpuInfo.vulkanVersionLabel,
                                                "Native hardware Vulkan backend detected on this device",
                                            ),
                                        )
                                    }
                                    add(
                                        Triple(
                                            "opengl",
                                            gpuInfo.openGlEsVersionLabel,
                                            "OpenGL ES backend for compatibility",
                                        ),
                                    )
                                }
                                apiChoices.forEach { (key, label, desc) ->
                                    val selected = settings.graphicsApi == key
                                    Surface(
                                        onClick = { onUpdateSettings(settings.copy(graphicsApi = key)) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) {
                                            MaterialTheme.colorScheme.primaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.surfaceContainerHigh
                                        },
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                )
                                                Text(
                                                    text = desc,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            if (selected) {
                                                Icon(
                                                    imageVector = Icons.Rounded.CheckCircle,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Custom Vulkan Driver (.zip)",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = "Load PanVK, Turnip, or custom Vulkan ICD driver packages",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    FilledTonalButton(
                                        onClick = onImportDriverZip,
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Import ZIP", maxLines = 1, softWrap = false)
                                    }
                                }

                                val allDriverNames = (listOf("System Default") + customDrivers).distinct()
                                allDriverNames.forEach { drv ->
                                    val isSel = settings.customDriverName == drv
                                    Surface(
                                        onClick = { onUpdateSettings(settings.copy(customDriverName = drv)) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (isSel) {
                                            MaterialTheme.colorScheme.secondaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.surfaceContainerHigh
                                        },
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = drv,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                Text(
                                                    text = if (drv == "System Default") "Built-in device GPU driver" else "Custom imported Vulkan ICD",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (isSel) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.CheckCircle,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                    )
                                                }
                                                if (drv != "System Default") {
                                                    IconButton(onClick = { onDeleteDriver(drv) }) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.DeleteOutline,
                                                            contentDescription = "Delete driver",
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = "Target Frame Rate",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf(30, 60, 90, 120, 0).forEach { fps ->
                                        FilterChip(
                                            selected = settings.targetFps == fps,
                                            onClick = {
                                                val nextPresent = if (fps == 0) "immediate" else settings.presentMode
                                                onUpdateSettings(settings.copy(targetFps = fps, presentMode = nextPresent))
                                            },
                                            label = { Text(if (fps == 0) "Uncapped" else "$fps FPS") },
                                        )
                                    }
                                }

                                Text(
                                    text = "Swapchain Present Mode",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("vsync" to "VSync", "mailbox" to "Mailbox", "immediate" to "Immediate").forEach { (k, l) ->
                                        FilterChip(
                                            selected = settings.presentMode == k,
                                            onClick = { onUpdateSettings(settings.copy(presentMode = k)) },
                                            label = { Text(l) },
                                        )
                                    }
                                }

                                Text(
                                    text = "Frame Pacing",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf("efficient" to "Efficient", "low_latency" to "Low Latency", "throughput" to "Max Throughput").forEach { (k, l) ->
                                        FilterChip(
                                            selected = settings.framePacing == k,
                                            onClick = { onUpdateSettings(settings.copy(framePacing = k)) },
                                            label = { Text(l) },
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Resolution Scale",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${settings.resolutionScale}%",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.resolutionScale.toFloat(),
                                    onValueChange = {
                                        val s = ((it / 5f).roundToInt() * 5).coerceIn(50, 125)
                                        onUpdateSettings(settings.copy(resolutionScale = s))
                                    },
                                    valueRange = 50f..125f,
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Render Distance",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${settings.renderDistance} chunks",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.renderDistance.toFloat(),
                                    onValueChange = {
                                        onUpdateSettings(settings.copy(renderDistance = it.roundToInt().coerceIn(2, 24)))
                                    },
                                    valueRange = 2f..24f,
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Simulation Distance",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${settings.simulationDistance} chunks",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.simulationDistance.toFloat(),
                                    onValueChange = {
                                        onUpdateSettings(settings.copy(simulationDistance = it.roundToInt().coerceIn(5, 16)))
                                    },
                                    valueRange = 5f..16f,
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Distant LOD Chunks",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = if (settings.lodDistance == 0) "Off" else "${settings.lodDistance} chunks",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.lodDistance.toFloat(),
                                    onValueChange = {
                                        val v = ((it / 8f).roundToInt() * 8).coerceIn(0, 128)
                                        onUpdateSettings(settings.copy(lodDistance = v))
                                    },
                                    valueRange = 0f..128f,
                                )

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Text(
                                    text = "Display Aspect Ratio",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf("Fullscreen", "16:9", "16:10", "4:3", "21:9").forEach { preset ->
                                        FilterChip(
                                            selected = settings.windowAspectPreset == preset,
                                            onClick = { onUpdateSettings(settings.copy(windowAspectPreset = preset)) },
                                            label = { Text(preset) },
                                        )
                                    }
                                }
                            }
                        }

                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Stretch Viewport to Fullscreen",
                            subtitle = "Stretch non-native aspect ratios edge to edge",
                            checked = settings.stretchToFullscreen,
                            onCheckedChange = { onUpdateSettings(settings.copy(stretchToFullscreen = it)) },
                        )
                    }

                    SettingsCategory.CONTROLS -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = HeroCardShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    Surface(
                                        modifier = Modifier.size(44.dp),
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary,
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Rounded.Gamepad,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Control Editor",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                        Text(
                                            text = "Active: ${globalTouchSettings.activeLayoutName} • Saved in SAF Touch_Controls/",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                    }
                                }

                                Button(
                                    onClick = onOpenControlEditorDialog,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary,
                                    ),
                                ) {
                                    Icon(Icons.Rounded.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Open Control Editor", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = "Active Control Layout",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    availableControlLayouts.forEach { layout ->
                                        val isSel = globalTouchSettings.activeLayoutName.equals(layout.name, ignoreCase = true)
                                        FilterChip(
                                            selected = isSel,
                                            onClick = {
                                                onUpdateTouchSettings(globalTouchSettings.copy(activeLayoutName = layout.name))
                                            },
                                            label = { Text(layout.name) },
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Sensitivity",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${globalTouchSettings.sensitivityPercent}%",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = globalTouchSettings.sensitivityPercent.toFloat(),
                                    onValueChange = { v ->
                                        onUpdateTouchSettings(
                                            globalTouchSettings.copy(sensitivityPercent = v.roundToInt().coerceIn(10, 300)),
                                        )
                                    },
                                    valueRange = 10f..300f,
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Control Size",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${globalTouchSettings.controlSizePercent}%",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = globalTouchSettings.controlSizePercent.toFloat(),
                                    onValueChange = { v ->
                                        onUpdateTouchSettings(
                                            globalTouchSettings.copy(controlSizePercent = v.roundToInt().coerceIn(50, 150)),
                                        )
                                    },
                                    valueRange = 50f..150f,
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Control Opacity",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${globalTouchSettings.controlOpacityPercent}%",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = globalTouchSettings.controlOpacityPercent.toFloat(),
                                    onValueChange = { v ->
                                        onUpdateTouchSettings(
                                            globalTouchSettings.copy(controlOpacityPercent = v.roundToInt().coerceIn(10, 100)),
                                        )
                                    },
                                    valueRange = 10f..100f,
                                )
                            }
                        }

                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Inverted Y",
                            subtitle = "Invert vertical camera look movement",
                            checked = globalTouchSettings.invertedY,
                            onCheckedChange = { inv ->
                                onUpdateTouchSettings(globalTouchSettings.copy(invertedY = inv))
                            },
                        )
                    }

                    SettingsCategory.CULLING -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = "Leaf Culling Mode",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("off" to "Off", "hollow" to "Hollow", "aggressive" to "Aggressive").forEach { (k, l) ->
                                        FilterChip(
                                            selected = settings.leafCulling == k,
                                            onClick = { onUpdateSettings(settings.copy(leafCulling = k)) },
                                            label = { Text(l) },
                                        )
                                    }
                                }

                                Text(
                                    text = "Particle Culling",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("off" to "Off", "sync" to "Sync", "async" to "Async").forEach { (k, l) ->
                                        FilterChip(
                                            selected = settings.particleCulling == k,
                                            onClick = { onUpdateSettings(settings.copy(particleCulling = k)) },
                                            label = { Text(l) },
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Text(
                                    text = "Chunk Updates per Frame",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(1, 2, 4, 8).forEach { n ->
                                        FilterChip(
                                            selected = settings.chunkUpdates == n,
                                            onClick = { onUpdateSettings(settings.copy(chunkUpdates = n)) },
                                            label = { Text("$n / frame") },
                                        )
                                    }
                                }

                                Text(
                                    text = "GPU Texture Budget",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(64, 128, 256, 512).forEach { mib ->
                                        FilterChip(
                                            selected = settings.textureBudgetMiB == mib,
                                            onClick = { onUpdateSettings(settings.copy(textureBudgetMiB = mib)) },
                                            label = { Text("$mib MiB") },
                                        )
                                    }
                                }

                                Text(
                                    text = "Mesh Upload Budget",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(256, 512, 1024).forEach { kib ->
                                        FilterChip(
                                            selected = settings.uploadBudgetKiB == kib,
                                            onClick = { onUpdateSettings(settings.copy(uploadBudgetKiB = kib)) },
                                            label = { Text("$kib KiB") },
                                        )
                                    }
                                }
                            }
                        }

                        SettingsToggleRow(
                            icon = Icons.Rounded.Speed,
                            title = "GPU Frustum Culling",
                            subtitle = "Skip off-screen chunk sections on the GPU",
                            checked = settings.gpuCulling,
                            onCheckedChange = { onUpdateSettings(settings.copy(gpuCulling = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Layers,
                            title = "Cave Culling",
                            subtitle = "Skip underground geometry when above ground",
                            checked = settings.caveCulling,
                            onCheckedChange = { onUpdateSettings(settings.copy(caveCulling = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Bolt,
                            title = "Entity Culling",
                            subtitle = "Skip occluded mobs and block-entities",
                            checked = settings.entityCulling,
                            onCheckedChange = { onUpdateSettings(settings.copy(entityCulling = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.AutoAwesome,
                            title = "Batch Translucent Geometry",
                            subtitle = "Merge water, glass & ice draw calls",
                            checked = settings.batchTranslucent,
                            onCheckedChange = { onUpdateSettings(settings.copy(batchTranslucent = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Layers,
                            title = "Opaque Ice",
                            subtitle = "Render ice blocks as opaque for faster fill rate",
                            checked = settings.opaqueIce,
                            onCheckedChange = { onUpdateSettings(settings.copy(opaqueIce = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.AutoAwesome,
                            title = "Animated Textures",
                            subtitle = "Animate water, lava, portal & fire textures",
                            checked = settings.animatedTextures,
                            onCheckedChange = { onUpdateSettings(settings.copy(animatedTextures = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Render Sky",
                            subtitle = "Draw sky dome, sun, moon & clouds",
                            checked = settings.skyEnabled,
                            onCheckedChange = { onUpdateSettings(settings.copy(skyEnabled = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Render Fog",
                            subtitle = "Smooth atmospheric distance & biome fog",
                            checked = settings.fogEnabled,
                            onCheckedChange = { onUpdateSettings(settings.copy(fogEnabled = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Render Weather",
                            subtitle = "Draw rain & snow precipitation passes",
                            checked = settings.weatherEnabled,
                            onCheckedChange = { onUpdateSettings(settings.copy(weatherEnabled = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Bolt,
                            title = "Shadow Cache",
                            subtitle = "Reuse shadow map frames for higher shader FPS",
                            checked = settings.shadowCache,
                            onCheckedChange = { onUpdateSettings(settings.copy(shadowCache = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.AutoAwesome,
                            title = "Built-In Diamond Shader",
                            subtitle = "Single-pass 60 FPS shadows, bloom, water reflections & color grading",
                            checked = settings.builtinShaderEnabled,
                            onCheckedChange = { onUpdateSettings(settings.copy(builtinShaderEnabled = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "Water Reflections & Specular",
                            subtitle = "Animated water normal ripples, sky Fresnel reflection & sun glints",
                            checked = settings.shaderWaterReflections,
                            onCheckedChange = { onUpdateSettings(settings.copy(shaderWaterReflections = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Tune,
                            title = "FXAA Anti-Aliasing",
                            subtitle = "Fast edge smoothing pass",
                            checked = settings.fxaa,
                            onCheckedChange = { onUpdateSettings(settings.copy(fxaa = it)) },
                        )
                    }

                    SettingsCategory.MEMORY -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = smartMemory.tierLabel,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    text = "Device Total RAM: ${smartMemory.totalDeviceRamMb} MB • Available Now: ${smartMemory.availableRamMb} MB • Recommended Heap: ${smartMemory.recommendedAllocMb} MB",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Auto Smart RAM (Real-Time)",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = "Automatically tunes heap to ${smartMemory.recommendedAllocMb} MB before every launch",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Switch(
                                        checked = settings.autoSmartRam,
                                        onCheckedChange = { enabled ->
                                            val nextMb = if (enabled) smartMemory.recommendedAllocMb else settings.memoryMb
                                            onUpdateSettings(settings.copy(autoSmartRam = enabled, memoryMb = nextMb))
                                        },
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = if (settings.autoSmartRam) "Memory Allocation (Auto-Managed)" else "Manual Memory Allocation",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (settings.autoSmartRam) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    )
                                    Text(
                                        text = "${settings.memoryMb} MB",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.memoryMb.toFloat().coerceIn(512f, 6144f),
                                    enabled = !settings.autoSmartRam,
                                    onValueChange = {
                                        val s = ((it / 256f).roundToInt() * 256).coerceIn(512, 6144)
                                        onUpdateSettings(settings.copy(memoryMb = s))
                                    },
                                    valueRange = 512f..6144f,
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "CPU Core Affinity",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                    ) {
                                        Text(
                                            text = "$cpuCores cores detected",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        )
                                    }
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf("All Cores", "Performance", "Efficiency").forEach { preset ->
                                        FilterChip(
                                            selected = settings.cpuCorePreset == preset,
                                            onClick = {
                                                val suggestedWorkers = when (preset) {
                                                    "Performance" -> (cpuCores / 2).coerceIn(2, 8)
                                                    "Efficiency" -> 2
                                                    else -> (cpuCores - 2).coerceIn(2, 8)
                                                }
                                                onUpdateSettings(settings.copy(cpuCorePreset = preset, workerThreads = suggestedWorkers))
                                            },
                                            label = { Text(preset) },
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Chunk Worker Threads",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${settings.workerThreads} / $cpuCores",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.workerThreads.toFloat().coerceIn(1f, cpuCores.coerceAtLeast(2).toFloat()),
                                    onValueChange = {
                                        onUpdateSettings(settings.copy(workerThreads = it.roundToInt().coerceIn(1, cpuCores.coerceAtLeast(2))))
                                    },
                                    valueRange = 1f..cpuCores.coerceAtLeast(2).toFloat(),
                                )
                            }
                        }

                        SettingsToggleRow(
                            icon = Icons.Rounded.Memory,
                            title = "Low-RAM Image Cache",
                            subtitle = "Shrink launcher thumbnail memory pool for extra game headroom",
                            checked = settings.lowRamImageCache,
                            onCheckedChange = { low ->
                                RemoteImageCache.configure(context, low || smartMemory.isLowRamDevice)
                                onUpdateSettings(settings.copy(lowRamImageCache = low))
                            },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Bolt,
                            title = "Battery Saver Mode",
                            subtitle = "Limit background chunk updates on battery",
                            checked = settings.batteryMode,
                            onCheckedChange = { onUpdateSettings(settings.copy(batteryMode = it)) },
                        )
                    }

                    SettingsCategory.STORAGE -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "Concurrent Download Threads",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = "${settings.downloadThreads}",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                                Slider(
                                    value = settings.downloadThreads.toFloat(),
                                    onValueChange = {
                                        onUpdateSettings(settings.copy(downloadThreads = it.roundToInt().coerceIn(1, 8)))
                                    },
                                    valueRange = 1f..8f,
                                    steps = 6,
                                )

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Verify & Grade MC $HORIZON_MC_VERSION Setup",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = "Audit all game files, assets & Horizon tables with grade report",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    FilledTonalButton(onClick = onOpenVerifyDialog) {
                                        Text("Verify")
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "SAF File Manager Access (Google Files)",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = "Read and write instance/ & Touch_Controls/ directly in Google Files",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    FilledTonalButton(onClick = onOpenSafFiles) {
                                        Text("Open SAF")
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Crash Detector & Logcat Window",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = "Inspect latest.log, native crash reports & export .txt via SAF",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    FilledTonalButton(onClick = onOpenCrashInspector) {
                                        Text("Logs")
                                    }
                                }
                            }
                        }
                    }

                    SettingsCategory.APPEARANCE -> {
                        SettingsToggleRow(
                            icon = Icons.Rounded.AutoAwesome,
                            title = "Material You Dynamic Color",
                            subtitle = "Derive launcher colors from wallpaper (Android 12+)",
                            checked = settings.dynamicColor,
                            onCheckedChange = { onUpdateSettings(settings.copy(dynamicColor = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.NightlightRound,
                            title = "Dark Theme",
                            subtitle = "Use dark Material You surfaces",
                            checked = settings.darkTheme,
                            onCheckedChange = { onUpdateSettings(settings.copy(darkTheme = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.Palette,
                            title = "Pure Black AMOLED Mode",
                            subtitle = "True #000000 backgrounds for OLED battery savings",
                            checked = settings.amoledDark,
                            onCheckedChange = {
                                onUpdateSettings(settings.copy(amoledDark = it, darkTheme = if (it) true else settings.darkTheme))
                            },
                        )

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = TileCardShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(
                                    text = "Custom Accent Palette",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Text(
                                    text = if (settings.dynamicColor) {
                                        "Turn off Dynamic Color above to apply a custom accent seed"
                                    } else {
                                        "Active palette: ${settings.accentColorName}"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    AccentSeedChoices.forEach { (name, swatch) ->
                                        FilterChip(
                                            selected = !settings.dynamicColor && settings.accentColorName == name,
                                            onClick = {
                                                onUpdateSettings(settings.copy(dynamicColor = false, accentColorName = name))
                                            },
                                            leadingIcon = {
                                                Box(
                                                    modifier = Modifier
                                                        .size(14.dp)
                                                        .clip(CircleShape)
                                                        .background(swatch),
                                                )
                                            },
                                            label = { Text(name) },
                                        )
                                    }
                                }
                            }
                        }

                        SettingsToggleRow(
                            icon = Icons.Rounded.Speed,
                            title = "Expressive Spring Motion",
                            subtitle = "Use Material 3 Expressive springs (turn off for minimal motion)",
                            checked = settings.expressiveMotion,
                            onCheckedChange = { onUpdateSettings(settings.copy(expressiveMotion = it)) },
                        )
                        SettingsToggleRow(
                            icon = Icons.Rounded.GridView,
                            title = "Compact List Density",
                            subtitle = "Tighter vertical spacing across settings & lists",
                            checked = settings.compactDensity,
                            onCheckedChange = { onUpdateSettings(settings.copy(compactDensity = it)) },
                        )
                    }
                }
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Surface(
        onClick = { onCheckedChange(!checked) },
        modifier = Modifier.fillMaxWidth(),
        shape = TileCardShape,
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                modifier = Modifier.size(38.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(19.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
            )
        }
    }
}


@Composable
private fun VersionsAndProfilesTabContent(
    versionReady: Boolean,
    installedSizeMib: Float,
    auditGrade: String,
    rendererLabel: String,
    settings: HorizonSettings,
    smartMemory: HorizonEngine.Companion.SmartMemoryProfile,
    modsCount: Int,
    onPlayClick: () -> Unit,
    onReverifyGameFiles: () -> Unit,
) {
    val cleanGrade = auditGrade.substringBefore("•").trim().ifBlank { "A+" }
    val sizeBadge = if (installedSizeMib > 0.5f) {
        String.format(Locale.US, "%.0f MiB", installedSizeMib)
    } else if (versionReady) {
        "Verified"
    } else {
        "Not Setup"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "versions_title_row") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Minecraft Instances",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Text(
                        text = if (versionReady) "1 Installed" else "Setup Needed",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
        }

        item(key = "instance_26_3") {
            Card(
                shape = HeroCardShape,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                ),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_grass_block),
                            contentDescription = "Minecraft 26.3",
                            modifier = Modifier.size(48.dp),
                            contentScale = ContentScale.Fit,
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    text = "Minecraft $HORIZON_MC_VERSION",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                ) {
                                    Text(
                                        text = if (versionReady) "ACTIVE" else "SETUP",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    )
                                }
                            }
                            Text(
                                text = "Horizon Rust • $rendererLabel • $modsCount mods • $sizeBadge",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = onPlayClick,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (versionReady) "Launch $HORIZON_MC_VERSION" else "Install $HORIZON_MC_VERSION", maxLines = 1, softWrap = false)
                        }
                        OutlinedButton(
                            onClick = onReverifyGameFiles,
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Icon(Icons.Rounded.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Audit $cleanGrade", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }

        item(key = "runtime_environment_row") {
            Surface(
                shape = TileCardShape,
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "Runtime Profile",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = "${smartMemory.tierLabel} • ${settings.memoryMb} MB alloc",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    ) {
                        Text(
                            text = if (smartMemory.is32Bit) "ARMv7 32-bit" else "ARM64",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

private enum class DiscoverProvider(val label: String) {
    MODRINTH("Modrinth"),
    DIAMOND_HUB("DiamondHUB"),
}

private enum class ModrinthSection(
    val label: String,
    val modrinthType: String,
    val subFolder: String,
    val worldsOnly: Boolean,
    val categories: List<String>,
) {
    SHADERS("Shaders", "shader", "shaderpacks", false, listOf("All", "Realistic", "Vanilla-like", "Fantasy", "Potato")),
    RESOURCE_PACKS("Resource Packs", "resourcepack", "resourcepacks", false, listOf("All", "16x", "32x", "64x", "Simplistic", "Combat")),
    WORLDS("Worlds", "datapack", "saves", true, listOf("All", "Worldgen", "Adventure")),
}

@Composable
private fun RemoteCachedImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    maxDimPx: Int = 256,
    contentScale: ContentScale = ContentScale.Crop,
    fallbackIcon: ImageVector = Icons.Rounded.AutoAwesome,
) {
    val cacheKey = remember(url, maxDimPx) { if (url.isNullOrBlank()) null else "${url}_$maxDimPx" }
    var bitmap by remember(cacheKey) {
        mutableStateOf(cacheKey?.let { RemoteImageCache.peek(it) })
    }
    LaunchedEffect(cacheKey) {
        if (!url.isNullOrBlank() && bitmap == null) {
            bitmap = RemoteImageCache.loadRemote(url, maxDimPx = maxDimPx)
        }
    }
    val img = bitmap
    if (img != null) {
        Image(
            bitmap = img,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
        )
    } else {
        Box(
            modifier = modifier.background(MaterialTheme.colorScheme.surfaceContainerHighest),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = fallbackIcon,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

@Composable
private fun LocalPackIconImage(
    iconPath: String?,
    kind: PackKind,
    enabled: Boolean,
    size: Dp = 48.dp,
) {
    val cacheKey = remember(iconPath) { if (iconPath.isNullOrBlank()) null else "file_${iconPath}_128" }
    var bitmap by remember(cacheKey) {
        mutableStateOf(cacheKey?.let { RemoteImageCache.peek(it) })
    }
    LaunchedEffect(cacheKey) {
        if (!iconPath.isNullOrBlank() && bitmap == null) {
            bitmap = RemoteImageCache.loadLocalFile(iconPath, maxDimPx = 128)
        }
    }
    Surface(
        modifier = Modifier.size(size),
        shape = RoundedCornerShape(14.dp),
        color = if (enabled) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceContainerHighest
        },
    ) {
        val img = bitmap
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = when (kind) {
                        PackKind.MOD -> Icons.Rounded.Extension
                        PackKind.SHADER -> Icons.Rounded.AutoAwesome
                        PackKind.RESOURCE -> Icons.Rounded.Layers
                    },
                    contentDescription = null,
                    tint = if (enabled) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DiscoverBrowserTabContent(
    preloadedShaders: List<ModrinthProjectHit>,
    installedPackKeys: Set<String>,
    onRefreshPacks: () -> Unit,
    onImportDmod: () -> Unit,
    onImportShader: () -> Unit,
    onImportResourcePack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(DiscoverProvider.MODRINTH) }
    var modrinthSection by remember { mutableStateOf(ModrinthSection.SHADERS) }
    var sortOption by remember { mutableStateOf(ModrinthSortOption.DOWNLOADS) }
    var mcVersionFilter by remember { mutableStateOf("Any") }
    var categoryFilter by remember { mutableStateOf("All") }
    var filtersExpanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf(preloadedShaders) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var downloadingId by remember { mutableStateOf<String?>(null) }
    var sessionInstalledIds by remember {
        mutableStateOf(HorizonEngine(context).loadInstalledModrinthProjectIds())
    }
    var installStatus by remember { mutableStateOf<String?>(null) }
    var selectedProject by remember { mutableStateOf<ModrinthProjectHit?>(null) }

    val mcVersionChoices = remember { listOf("Any", "26.3", "1.21.4", "1.21.1", "1.20.1", "1.19.2") }

    LaunchedEffect(provider, modrinthSection, sortOption, mcVersionFilter, categoryFilter, searchQuery, preloadedShaders) {
        if (provider != DiscoverProvider.MODRINTH) {
            hits = emptyList()
            errorMessage = null
            isLoading = false
            return@LaunchedEffect
        }
        val isDefaultShaders = modrinthSection == ModrinthSection.SHADERS &&
            sortOption == ModrinthSortOption.DOWNLOADS &&
            mcVersionFilter == "Any" &&
            categoryFilter == "All" &&
            searchQuery.isBlank()
        if (isDefaultShaders && preloadedShaders.isNotEmpty()) {
            hits = preloadedShaders
            errorMessage = null
            isLoading = false
            return@LaunchedEffect
        }
        if (searchQuery.isNotBlank()) delay(220L)
        isLoading = true
        errorMessage = null
        val res = ModrinthClient.searchProjects(
            query = searchQuery,
            projectType = modrinthSection.modrinthType,
            sortIndex = sortOption.apiIndex,
            mcVersion = mcVersionFilter,
            category = categoryFilter,
            worldsOnly = modrinthSection.worldsOnly,
            limit = 24,
        )
        res.onSuccess { list ->
            hits = list
        }.onFailure { err ->
            errorMessage = err.message ?: "Unable to reach Modrinth"
            hits = emptyList()
        }
        isLoading = false
    }

    selectedProject?.let { hit ->
        ModrinthProjectDetailDialog(
            hit = hit,
            subFolder = modrinthSection.subFolder,
            zipOnly = modrinthSection.worldsOnly,
            onDismiss = { selectedProject = null },
            onInstalled = { savedName ->
                installStatus = "Installed $savedName into ${modrinthSection.subFolder}/"
                onRefreshPacks()
            },
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "discover_provider_bar", contentType = "provider_bar") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.weight(1f)) {
                    DiscoverProvider.entries.forEachIndexed { idx, prov ->
                        SegmentedButton(
                            shape = SegmentedButtonDefaults.itemShape(index = idx, count = DiscoverProvider.entries.size),
                            selected = provider == prov,
                            onClick = {
                                provider = prov
                                installStatus = null
                            },
                        ) {
                            Text(
                                text = prov.label,
                                fontWeight = if (provider == prov) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                            )
                        }
                    }
                }
                if (provider == DiscoverProvider.MODRINTH) {
                    FilledTonalIconButton(
                        onClick = { filtersExpanded = !filtersExpanded },
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = if (filtersExpanded || mcVersionFilter != "Any" || categoryFilter != "All" || sortOption != ModrinthSortOption.DOWNLOADS) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerHigh
                            },
                        ),
                    ) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Filters")
                    }
                }
            }
        }

        if (provider == DiscoverProvider.MODRINTH) {
            item(key = "modrinth_sections", contentType = "sections") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ModrinthSection.entries, key = { it.name }) { sec ->
                        FilterChip(
                            selected = modrinthSection == sec,
                            onClick = {
                                modrinthSection = sec
                                categoryFilter = "All"
                                installStatus = null
                            },
                            label = { Text(sec.label, maxLines = 1, softWrap = false) },
                        )
                    }
                }
            }

            item(key = "modrinth_filters_drawer", contentType = "filters") {
                AnimatedVisibility(
                    visible = filtersExpanded,
                    enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 450f)) + fadeIn(tween(150)),
                    exit = shrinkVertically(tween(120)) + fadeOut(tween(90)),
                ) {
                    Surface(
                        shape = TileCardShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text("Sort By", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(ModrinthSortOption.entries, key = { it.name }) { opt ->
                                    FilterChip(
                                        selected = sortOption == opt,
                                        onClick = { sortOption = opt },
                                        label = { Text(opt.label, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
                                    )
                                }
                            }
                            Text("Minecraft Version", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(mcVersionChoices, key = { it }) { ver ->
                                    FilterChip(
                                        selected = mcVersionFilter == ver,
                                        onClick = { mcVersionFilter = ver },
                                        label = { Text(ver, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
                                    )
                                }
                            }
                            Text("Category", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(modrinthSection.categories, key = { it }) { cat ->
                                    FilterChip(
                                        selected = categoryFilter == cat,
                                        onClick = { categoryFilter = cat },
                                        label = { Text(cat, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item(key = "discover_search", contentType = "search") {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        text = if (provider == DiscoverProvider.DIAMOND_HUB) {
                            "Search DiamondHUB .dmod packages..."
                        } else {
                            "Search ${modrinthSection.label} on Modrinth..."
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(22.dp),
            )
        }

        if (installStatus != null) {
            item(key = "discover_status", contentType = "status") {
                Surface(
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = installStatus ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { installStatus = null }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Dismiss",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
            }
        }

        if (provider == DiscoverProvider.DIAMOND_HUB) {
            item(key = "diamondhub_actions", contentType = "diamondhub") {
                Surface(
                    shape = HeroCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(Icons.Rounded.Extension, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text("DiamondHUB (.dmod)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondaryContainer,
                            ) {
                                Text(
                                    text = "API Ready",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Button(
                                onClick = onImportDmod,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Icon(Icons.Rounded.CloudDownload, contentDescription = null, modifier = Modifier.size(17.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Import .dmod", maxLines = 1, softWrap = false)
                            }
                            OutlinedButton(
                                onClick = onImportShader,
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Text("Shader", maxLines = 1, softWrap = false)
                            }
                            OutlinedButton(
                                onClick = onImportResourcePack,
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Text("Pack", maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        } else if (isLoading) {
            item(key = "modrinth_loading", contentType = "loading") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
        } else if (errorMessage != null) {
            item(key = "modrinth_error", contentType = "error") {
                Card(
                    shape = TileCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                ) {
                    Text(
                        text = errorMessage ?: "Network error",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        } else if (hits.isEmpty()) {
            item(key = "modrinth_empty", contentType = "empty") {
                Card(
                    shape = TileCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                ) {
                    Text(
                        text = "No matching ${modrinthSection.label.lowercase(Locale.US)} found for these filters.",
                        modifier = Modifier.padding(18.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else {
            items(
                items = hits,
                key = { it.projectId },
                contentType = { "project_card" },
            ) { hit ->
                val isDownloading = downloadingId == hit.projectId
                val fallbackIcon = when (modrinthSection) {
                    ModrinthSection.SHADERS -> Icons.Rounded.AutoAwesome
                    ModrinthSection.RESOURCE_PACKS -> Icons.Rounded.Layers
                    ModrinthSection.WORLDS -> Icons.Rounded.Explore
                }
                Surface(
                    onClick = { selectedProject = hit },
                    shape = TileCardShape,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RemoteCachedImage(
                                url = hit.iconUrl,
                                contentDescription = hit.title,
                                maxDimPx = 112,
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(14.dp)),
                                fallbackIcon = fallbackIcon,
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = hit.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = "by ${hit.author} • ${ModrinthClient.formatDownloads(hit.downloads)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            val isInstalled = sessionInstalledIds.contains(hit.projectId) ||
                                installedPackKeys.any { k ->
                                    k.contains(hit.slug.lowercase(Locale.US)) ||
                                        k.contains(hit.title.lowercase(Locale.US).take(12))
                                }
                            val btnState = when {
                                isDownloading -> 1
                                isInstalled -> 2
                                else -> 0
                            }
                            FilledTonalButton(
                                enabled = btnState == 0 && downloadingId == null,
                                onClick = {
                                    downloadingId = hit.projectId
                                    installStatus = null
                                    scope.launch {
                                        val targetDir = java.io.File(HorizonEngine.instanceDir(context), modrinthSection.subFolder)
                                        val res = ModrinthClient.downloadLatestProjectFile(
                                            projectId = hit.projectId,
                                            targetDir = targetDir,
                                            zipOnly = modrinthSection.worldsOnly,
                                        )
                                        res.onSuccess { saved ->
                                            withContext(Dispatchers.IO) {
                                                val engRef = HorizonEngine(context)
                                                engRef.recordInstalledModrinthProject(hit.projectId, saved.name)
                                                hit.iconUrl?.let { iconUrl ->
                                                    ModrinthClient.downloadIconToFile(iconUrl, engRef.packIconCacheFile(saved.name))
                                                }
                                            }
                                            sessionInstalledIds = sessionInstalledIds + hit.projectId
                                            installStatus = "Installed ${saved.name} into ${modrinthSection.subFolder}/"
                                            onRefreshPacks()
                                        }.onFailure { err ->
                                            installStatus = "Download failed: ${err.message}"
                                        }
                                        downloadingId = null
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            ) {
                                AnimatedContent(targetState = btnState, label = "install_btn_morph") { st ->
                                    when (st) {
                                        1 -> CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        2 -> Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Installed", maxLines = 1, softWrap = false, fontWeight = FontWeight.Bold)
                                        }
                                        else -> Text("Install", maxLines = 1, softWrap = false, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        if (hit.description.isNotBlank()) {
                            Text(
                                text = hit.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModrinthProjectDetailDialog(
    hit: ModrinthProjectHit,
    subFolder: String,
    zipOnly: Boolean = false,
    onDismiss: () -> Unit,
    onInstalled: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var details by remember(hit.projectId) { mutableStateOf<ModrinthProjectDetails?>(null) }
    var versions by remember(hit.projectId) { mutableStateOf<List<ModrinthVersionEntry>>(emptyList()) }
    var loadingDetails by remember(hit.projectId) { mutableStateOf(true) }
    var downloadingVersionId by remember { mutableStateOf<String?>(null) }
    var dialogStatus by remember { mutableStateOf<String?>(null) }
    var previewGalleryUrl by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(hit.projectId) {
        loadingDetails = true
        val dRes = ModrinthClient.fetchProjectDetails(hit.projectId)
        val vRes = ModrinthClient.fetchProjectVersions(hit.projectId, zipOnly = zipOnly)
        dRes.onSuccess { details = it }
        vRes.onSuccess { versions = it }
        loadingDetails = false
    }

    val bannerUrl = details?.gallery?.firstOrNull { it.featured }?.url
        ?: details?.gallery?.firstOrNull()?.url
        ?: hit.featuredGalleryUrl
        ?: hit.iconUrl

    var installedFileNames by remember(subFolder) {
        mutableStateOf(
            java.io.File(HorizonEngine.instanceDir(context), subFolder)
                .listFiles()
                ?.map { it.name.lowercase(Locale.US) }
                ?.toSet()
                .orEmpty(),
        )
    }

    val downloadFile: (String, ModrinthVersionFile) -> Unit = { versionId, file ->
        downloadingVersionId = versionId
        dialogStatus = null
        scope.launch {
            val targetDir = java.io.File(HorizonEngine.instanceDir(context), subFolder)
            ModrinthClient.downloadVersionFile(file, targetDir).onSuccess { saved ->
                withContext(Dispatchers.IO) {
                    val engRef = HorizonEngine(context)
                    engRef.recordInstalledModrinthProject(hit.projectId, saved.name)
                    hit.iconUrl?.let { iconUrl ->
                        ModrinthClient.downloadIconToFile(iconUrl, engRef.packIconCacheFile(saved.name))
                    }
                }
                installedFileNames = installedFileNames + saved.name.lowercase(Locale.US)
                dialogStatus = "Installed ${saved.name}"
                onInstalled(saved.name)
            }.onFailure { err ->
                dialogStatus = "Download failed: ${err.message}"
            }
            downloadingVersionId = null
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    item(key = "detail_hero") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp),
                        ) {
                            RemoteCachedImage(
                                url = bannerUrl,
                                contentDescription = hit.title,
                                maxDimPx = 640,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Black.copy(alpha = 0.25f),
                                                Color.Black.copy(alpha = 0.85f),
                                            ),
                                        ),
                                    ),
                            )
                            FilledTonalIconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp)
                                    .size(36.dp),
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                            }
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                RemoteCachedImage(
                                    url = hit.iconUrl,
                                    contentDescription = hit.title,
                                    maxDimPx = 160,
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .border(1.5.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = hit.title,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    val followersText = details?.let { " • ${ModrinthClient.formatDownloads(it.followers)} followers" }.orEmpty()
                                    Text(
                                        text = "by ${hit.author} • ${ModrinthClient.formatDownloads(hit.downloads)}$followersText",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White.copy(alpha = 0.82f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }

                    item(key = "detail_latest_action") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            val latestVer = versions.firstOrNull { it.primaryFile != null }
                            val isLatestInstalled = latestVer?.primaryFile?.filename?.lowercase(Locale.US) in installedFileNames
                            val isDownloadingLatest = downloadingVersionId == "latest"
                            val sizeLabel = latestVer?.primaryFile?.let { ModrinthClient.formatFileSize(it.sizeBytes) }.orEmpty()
                            val mcBadge = latestVer?.gameVersions?.firstOrNull().orEmpty()
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(2.dp),
                                    ) {
                                        Text(
                                            text = latestVer?.versionNumber ?: "Latest Release",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(
                                            text = listOfNotNull(
                                                mcBadge.takeIf { it.isNotBlank() }?.let { "MC $it" },
                                                sizeLabel.takeIf { it.isNotBlank() },
                                            ).joinToString(" • ").ifBlank { "Fetching release metadata..." },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            val file = latestVer?.primaryFile
                                            if (file != null) {
                                                downloadFile("latest", file)
                                            }
                                        },
                                        enabled = latestVer?.primaryFile != null && downloadingVersionId == null,
                                        shape = RoundedCornerShape(50),
                                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                                    ) {
                                        if (isDownloadingLatest) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = MaterialTheme.colorScheme.onPrimary,
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Installing", fontWeight = FontWeight.Bold, maxLines = 1)
                                        } else if (isLatestInstalled) {
                                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Installed", fontWeight = FontWeight.Bold, maxLines = 1)
                                        } else {
                                            Icon(Icons.Rounded.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Install", fontWeight = FontWeight.Bold, maxLines = 1)
                                        }
                                    }
                                }
                            }

                            if (dialogStatus != null) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = dialogStatus ?: "",
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    )
                                }
                            }
                        }
                    }

                    val galleryItems = details?.gallery.orEmpty()
                    if (galleryItems.isNotEmpty()) {
                        item(key = "detail_gallery") {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    text = "Gallery (${galleryItems.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                )
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    items(galleryItems, key = { it.url }) { gItem ->
                                        Box(
                                            modifier = Modifier
                                                .width(230.dp)
                                                .height(132.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                                .clickable { previewGalleryUrl = gItem.url },
                                        ) {
                                            RemoteCachedImage(
                                                url = gItem.url,
                                                contentDescription = gItem.title,
                                                maxDimPx = 480,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize(),
                                            )
                                            if (gItem.title.isNotBlank() && !gItem.title.equals("null", ignoreCase = true)) {
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomStart)
                                                        .fillMaxWidth()
                                                        .background(Color.Black.copy(alpha = 0.55f))
                                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                                ) {
                                                    Text(
                                                        text = gItem.title,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = Color.White,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item(key = "detail_description") {
                        var descExpanded by remember { mutableStateOf(false) }
                        val rawText = details?.body?.takeIf { it.isNotBlank() } ?: hit.description
                        val cleanedText = remember(rawText) {
                            rawText
                                .replace(Regex("\[\s*]\([^)]*\)"), "")
                                .replace(Regex("\n{3,}"), "

")
                                .trim()
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "About",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateContentSize(spring(dampingRatio = 0.85f, stiffness = 420f)),
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Text(
                                        text = if (descExpanded) cleanedText.take(2400) else cleanedText.take(360),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = if (descExpanded) Int.MAX_VALUE else 6,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    if (cleanedText.length > 360) {
                                        TextButton(
                                            onClick = { descExpanded = !descExpanded },
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                        ) {
                                            Text(
                                                text = if (descExpanded) "Show less" else "Read more",
                                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item(key = "detail_versions_header") {
                        Text(
                            text = "Versions (${versions.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp),
                        )
                    }

                    if (loadingDetails && versions.isEmpty()) {
                        item(key = "detail_versions_loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 2.5.dp)
                            }
                        }
                    } else {
                        items(versions.take(25), key = { it.id }) { ver ->
                            val isThisDownloading = downloadingVersionId == ver.id
                            val isVerInstalled = ver.primaryFile?.filename?.lowercase(Locale.US) in installedFileNames
                            val mcTags = ver.gameVersions.take(3).joinToString(", ")
                            val sizeLabel = ver.primaryFile?.let { ModrinthClient.formatFileSize(it.sizeBytes) }.orEmpty()
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isVerInstalled) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = ver.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        val meta = listOfNotNull(
                                            ver.versionNumber.takeIf { it.isNotBlank() },
                                            mcTags.takeIf { it.isNotBlank() },
                                            sizeLabel.takeIf { it.isNotBlank() },
                                            ver.datePublished.takeIf { it.isNotBlank() },
                                        ).joinToString(" • ")
                                        Text(
                                            text = meta,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                    FilledTonalButton(
                                        enabled = ver.primaryFile != null && downloadingVersionId == null,
                                        onClick = {
                                            ver.primaryFile?.let { f -> downloadFile(ver.id, f) }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    ) {
                                        if (isThisDownloading) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        } else if (isVerInstalled) {
                                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Installed", maxLines = 1, softWrap = false, fontWeight = FontWeight.Bold)
                                        } else {
                                            Icon(Icons.Rounded.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(5.dp))
                                            Text("Get", maxLines = 1, softWrap = false, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                previewGalleryUrl?.let { fullUrl ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.92f))
                            .clickable { previewGalleryUrl = null },
                        contentAlignment = Alignment.Center,
                    ) {
                        RemoteCachedImage(
                            url = fullUrl,
                            contentDescription = "Screenshot Preview",
                            maxDimPx = 1024,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                        )
                        FilledTonalIconButton(
                            onClick = { previewGalleryUrl = null },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(14.dp),
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close Preview")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PortraitNavigationBar(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 0.dp,
    ) {
        Destinations.forEachIndexed { index, dest ->
            val selected = selectedTab == index
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(index) },
                icon = {
                    val iconScale by animateFloatAsState(
                        targetValue = if (selected) 1.12f else 1f,
                        animationSpec = spring(dampingRatio = 0.62f, stiffness = 500f),
                        label = "nav_icon_scale",
                    )
                    Icon(
                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                        contentDescription = dest.label,
                        modifier = Modifier.graphicsLayer {
                            scaleX = iconScale
                            scaleY = iconScale
                        },
                    )
                },
                label = {
                    Text(
                        text = dest.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.onSurface,
                    indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}

@Composable
private fun LandscapeNavigationRail(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .width(74.dp)
            .fillMaxHeight(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
        ) {
            Destinations.forEachIndexed { index, dest ->
                val selected = selectedTab == index
                Surface(
                    onClick = { onSelectTab(index) },
                    shape = RoundedCornerShape(14.dp),
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Icon(
                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                            contentDescription = dest.label,
                            tint = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            text = dest.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 800)
@Composable
private fun LauncherPortraitPreview() {
    LauncherScreen()
}


@Composable
private fun VerifyAuditDialog(
    report: HorizonEngine.Companion.VerificationAuditReport,
    onDismiss: () -> Unit,
    onRunSetupAgain: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Verify & Setup Audit",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (report.readyToPlay) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.errorContainer
                    },
                ) {
                    Text(
                        text = "Grade: ${report.grade} (${report.scorePercent}%)",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = if (report.readyToPlay) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onErrorContainer
                        },
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = report.summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                report.items.forEach { item ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Text(
                                    text = item.detail,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Icon(
                                imageVector = if (item.passed) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = if (item.passed) Color(0xFF2EA043) else MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val ctx = LocalContext.current
            val dlgScope = rememberCoroutineScope()
            var repairing by remember { mutableStateOf(false) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!report.readyToPlay && report.scorePercent >= 50) {
                    FilledTonalButton(
                        enabled = !repairing,
                        onClick = {
                            repairing = true
                            dlgScope.launch {
                                withContext(Dispatchers.IO) {
                                    HorizonEngine(ctx).quickRepairMissingComponents()
                                }
                                repairing = false
                                onDismiss()
                            }
                        },
                    ) {
                        Text(if (repairing) "Repairing..." else "Quick Repair")
                    }
                }
                Button(onClick = onRunSetupAgain) {
                    Icon(Icons.Rounded.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (report.readyToPlay) "Run Setup Again" else "Download & Repair")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
    )
}

@Composable
private fun CrashDetectorWindowDialog(
    crash: CrashReportData,
    onExportSaf: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.errorContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.BugReport,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        },
        title = {
            Column {
                Text(
                    text = crash.title,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                )
                Text(
                    text = "${crash.source} • ${crash.reportFile.name}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = crash.errorSummary,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 300.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(rememberScrollState())
                            .padding(10.dp),
                    ) {
                        Text(
                            text = crash.fullReportText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onExportSaf) {
                Icon(Icons.Rounded.IosShare, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export .txt via SAF")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss")
            }
        },
    )
}

@Composable
private fun AppLauncherIconBadge(size: androidx.compose.ui.unit.Dp) {
    val context = LocalContext.current
    val iconBitmap = remember(context) {
        ContextCompat.getDrawable(context, R.mipmap.ic_launcher)
            ?.toBitmap(128, 128)
            ?.asImageBitmap()
    }
    Surface(
        modifier = Modifier.size(size),
        shape = SquircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (iconBitmap != null) {
                Image(
                    bitmap = iconBitmap,
                    contentDescription = "Diamond Launcher",
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}
