package com.logosforgestudios.diamond.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.logosforgestudios.diamond.auth.DeviceCodeResponse
import com.logosforgestudios.diamond.auth.DevicePollResult
import com.logosforgestudios.diamond.auth.MicrosoftAuthClient
import com.logosforgestudios.diamond.auth.MinecraftCapeInfo
import com.logosforgestudios.diamond.engine.HorizonAccount
import com.logosforgestudios.diamond.engine.HorizonEngine
import com.logosforgestudios.diamond.ui.theme.DiamondLauncherTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import kotlin.math.cos
import kotlin.math.sin

class ProfileManagerActivity : ComponentActivity() {
    companion object {
        const val EXTRA_START_MSA_LOGIN = "extra_start_msa_login"

        fun launch(context: Context, startMsaLogin: Boolean = false) {
            val intent = Intent(context, ProfileManagerActivity::class.java).apply {
                putExtra(EXTRA_START_MSA_LOGIN, startMsaLogin)
            }
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        )
        val autoMsa = intent?.getBooleanExtra(EXTRA_START_MSA_LOGIN, false) == true
        setContent {
            ProfileManagerScreen(
                startMsaLogin = autoMsa,
                onBack = { finish() },
            )
        }
    }
}

@Composable
private fun ProfileManagerScreen(
    startMsaLogin: Boolean,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember(context) { HorizonEngine(context) }
    val settings = remember { engine.loadSettings() }

    var accountsState by remember { mutableStateOf(engine.loadAccounts()) }
    val accounts = accountsState.first
    val selectedUuid = accountsState.second
    val activeAccount = remember(accounts, selectedUuid) {
        accounts.firstOrNull { it.uuid == selectedUuid } ?: accounts.firstOrNull()
    }

    var statusBanner by remember { mutableStateOf<String?>(null) }
    var busyMessage by remember { mutableStateOf<String?>(null) }
    var skinReloadTick by remember { mutableIntStateOf(0) }
    var skinBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var capeBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var showAddOfflineDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showMsaDialog by remember { mutableStateOf(startMsaLogin) }
    var showMsaInfoDialog by remember { mutableStateOf(false) }

    val capes: List<MinecraftCapeInfo> = remember(activeAccount?.capesJson) {
        MicrosoftAuthClient.parseCapesJson(activeAccount?.capesJson.orEmpty())
    }
    val activeCapeUrl = remember(capes, activeAccount?.activeCapeId) {
        capes.firstOrNull { it.id == activeAccount?.activeCapeId && it.id.isNotBlank() }?.url.orEmpty()
    }
    val isSlim = remember(activeAccount?.skinModel) {
        activeAccount?.skinModel?.contains("slim", ignoreCase = true) == true
    }

    LaunchedEffect(activeAccount?.uuid, activeAccount?.skinUrl, skinReloadTick) {
        val loaded = withContext(Dispatchers.IO) {
            val acc = activeAccount
            val remoteUrl = acc?.skinUrl.orEmpty()
            val bmp = if (acc?.userType == "msa" && remoteUrl.isNotBlank()) {
                val safeUrl = remoteUrl.replace("http://", "https://")
                runCatching {
                    val conn = (URL(safeUrl).openConnection() as java.net.HttpURLConnection).apply {
                        connectTimeout = 10000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", "DiamondLauncher/1.0")
                    }
                    try {
                        conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    } finally {
                        conn.disconnect()
                    }
                }.getOrNull()
            } else {
                val f = engine.customSkinFile()
                if (f.isFile && f.length() > 64L) {
                    runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull()
                } else {
                    null
                }
            }
            bmp ?: createDefaultSteveBitmap()
        }
        skinBitmap = loaded
    }

    LaunchedEffect(activeCapeUrl) {
        capeBitmap = if (activeCapeUrl.isNotBlank()) {
            withContext(Dispatchers.IO) {
                val safeUrl = activeCapeUrl.replace("http://", "https://")
                runCatching {
                    val conn = (URL(safeUrl).openConnection() as java.net.HttpURLConnection).apply {
                        connectTimeout = 10000
                        readTimeout = 15000
                        setRequestProperty("User-Agent", "DiamondLauncher/1.0")
                    }
                    try {
                        conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    } finally {
                        conn.disconnect()
                    }
                }.getOrNull()
            }
        } else {
            null
        }
    }

    val skinPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        val acc = activeAccount ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            scope.launch {
                busyMessage = "Updating skin..."
                val imported = withContext(Dispatchers.IO) { engine.importCustomSkinPng(uri) }
                imported.onSuccess { file ->
                    if (acc.userType == "msa" && acc.accessToken.length > 10) {
                        val up = MicrosoftAuthClient.uploadSkin(acc.accessToken, file, slimModel = isSlim)
                        up.onSuccess {
                            MicrosoftAuthClient.fetchProfile(acc.accessToken, acc.refreshToken, acc.xuid).onSuccess { fresh ->
                                engine.saveMicrosoftAccount(fresh)
                                accountsState = engine.loadAccounts()
                            }
                            statusBanner = "Uploaded new skin to your Microsoft account."
                            skinReloadTick++
                        }.onFailure { err ->
                            statusBanner = err.message ?: "Skin upload failed."
                        }
                    } else {
                        statusBanner = "Saved custom offline skin (horizon-skin.png)."
                        skinReloadTick++
                    }
                }.onFailure { err ->
                    statusBanner = err.message ?: "Could not import PNG."
                }
                busyMessage = null
            }
        }
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    DiamondLauncherTheme(
        darkTheme = settings.darkTheme,
        dynamicColor = settings.dynamicColor,
        amoledDark = settings.amoledDark,
        accentColorName = settings.accentColorName,
        expressiveMotion = settings.expressiveMotion,
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    FilledTonalIconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Profile & Skin Studio",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = activeAccount?.let {
                                val badge = if (it.userType == "msa") "Microsoft Account" else "Offline Account"
                                "${it.name} • $badge"
                            } ?: "No active profile",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                    FilledTonalButton(
                        onClick = {
                            if (activeAccount?.userType == "msa") {
                                showMsaInfoDialog = true
                            } else {
                                showMsaDialog = true
                            }
                        },
                        shape = RoundedCornerShape(50),
                    ) {
                        Icon(Icons.Rounded.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (activeAccount?.userType == "msa") "Account Info" else "Microsoft",
                            maxLines = 1,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }

                if (statusBanner != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = statusBanner.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = { statusBanner = null }) {
                                Text("OK")
                            }
                        }
                    }
                }

                val modelStage: @Composable (Modifier) -> Unit = { mod ->
                    InteractivePlayerModelCard(
                        modifier = mod,
                        skinBitmap = skinBitmap,
                        capeBitmap = capeBitmap,
                        isSlim = isSlim,
                        accountName = activeAccount?.name ?: "Steve",
                        isMicrosoft = activeAccount?.userType == "msa",
                    )
                }

                val controlsPane: @Composable (Modifier) -> Unit = { mod ->
                    Column(
                        modifier = mod.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(
                                    text = "Skin & Model",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Button(
                                        onClick = { skinPicker.launch(arrayOf("image/png", "image/*")) },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Change Skin PNG", maxLines = 1)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            val acc = activeAccount ?: return@OutlinedButton
                                            val next = if (isSlim) "Classic (Steve)" else "Slim (Alex)"
                                            engine.updateAccountSkinModel(acc.uuid, next)
                                            accountsState = engine.loadAccounts()
                                            statusBanner = "Switched model to $next."
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                    ) {
                                        Text(if (isSlim) "Slim" else "Classic", maxLines = 1)
                                    }
                                }
                                if (activeAccount?.userType != "msa") {
                                    TextButton(
                                        onClick = {
                                            engine.clearCustomSkin()
                                            skinReloadTick++
                                            statusBanner = "Reset offline skin to default."
                                        },
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    ) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Reset to Default Skin")
                                    }
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "Capes",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    )
                                    Text(
                                        text = if (activeAccount?.userType == "msa") "${capes.size} owned" else "Microsoft only",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                if (activeAccount?.userType == "msa") {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        FilterChip(
                                            selected = activeAccount.activeCapeId.isBlank(),
                                            onClick = {
                                                scope.launch {
                                                    busyMessage = "Hiding cape..."
                                                    MicrosoftAuthClient.setActiveCape(activeAccount.accessToken, null)
                                                        .onSuccess {
                                                            engine.updateAccountActiveCape(activeAccount.uuid, "")
                                                            accountsState = engine.loadAccounts()
                                                            statusBanner = "Cape hidden."
                                                        }
                                                        .onFailure { statusBanner = it.message }
                                                    busyMessage = null
                                                }
                                            },
                                            label = { Text("None") },
                                        )
                                        capes.forEach { cape ->
                                            FilterChip(
                                                selected = activeAccount.activeCapeId == cape.id,
                                                onClick = {
                                                    scope.launch {
                                                        busyMessage = "Equipping ${cape.alias}..."
                                                        MicrosoftAuthClient.setActiveCape(activeAccount.accessToken, cape.id)
                                                            .onSuccess {
                                                                engine.updateAccountActiveCape(activeAccount.uuid, cape.id)
                                                                accountsState = engine.loadAccounts()
                                                                statusBanner = "Equipped ${cape.alias} cape."
                                                            }
                                                            .onFailure { statusBanner = it.message }
                                                        busyMessage = null
                                                    }
                                                },
                                                label = { Text(cape.alias) },
                                            )
                                        }
                                    }
                                } else {
                                    Text(
                                        text = "Sign in with a Microsoft account to equip your official Minecraft capes.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Player Name",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        )
                                        Text(
                                            text = activeAccount?.name ?: "None",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                    FilledTonalButton(
                                        onClick = { showRenameDialog = true },
                                        enabled = activeAccount != null,
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Change Name")
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                Text(
                                    text = "Saved Accounts (${accounts.size})",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                accounts.forEach { acc ->
                                    val isSel = acc.uuid == activeAccount?.uuid
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                engine.selectAccount(acc.uuid)
                                                engine.writeHorizonPlayerName(acc.name)
                                                accountsState = engine.loadAccounts()
                                                skinReloadTick++
                                            },
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f),
                                            ) {
                                                Icon(
                                                    imageVector = if (acc.userType == "msa") Icons.Rounded.Verified else Icons.Rounded.Person,
                                                    contentDescription = null,
                                                    tint = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                                Column {
                                                    Text(
                                                        text = acc.name,
                                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                        color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                                    )
                                                    Text(
                                                        text = if (acc.userType == "msa") "Microsoft • ${acc.skinModel}" else "Offline • ${acc.skinModel}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (isSel) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.CheckCircle,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        engine.removeAccount(acc.uuid)
                                                        accountsState = engine.loadAccounts()
                                                        skinReloadTick++
                                                    },
                                                ) {
                                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove")
                                                }
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Button(
                                        onClick = { showMsaDialog = true },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                    ) {
                                        Icon(Icons.Rounded.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Microsoft Login", maxLines = 1)
                                    }
                                    OutlinedButton(
                                        onClick = { showAddOfflineDialog = true },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                    ) {
                                        Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Add Offline", maxLines = 1)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                if (isLandscape) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        modelStage(Modifier.weight(0.42f).fillMaxHeight())
                        controlsPane(Modifier.weight(0.58f).fillMaxHeight())
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        modelStage(Modifier.fillMaxWidth().height(265.dp))
                        controlsPane(Modifier.weight(1f).fillMaxWidth())
                    }
                }
            }

            if (busyMessage != null) {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Working...", fontWeight = FontWeight.Bold) },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp)
                            Text(busyMessage.orEmpty())
                        }
                    },
                    confirmButton = {},
                )
            }

            if (showAddOfflineDialog) {
                var offlineName by remember { mutableStateOf("") }
                var offlineErr by remember { mutableStateOf<String?>(null) }
                AlertDialog(
                    onDismissRequest = { showAddOfflineDialog = false },
                    title = { Text("Add Offline Account", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = offlineName,
                                onValueChange = {
                                    offlineName = it
                                    offlineErr = null
                                },
                                label = { Text("Username (3-16 chars)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            if (offlineErr != null) {
                                Text(offlineErr.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val res = engine.createOfflineAccount(offlineName)
                                res.onSuccess { acc ->
                                    engine.writeHorizonPlayerName(acc.name)
                                    accountsState = engine.loadAccounts()
                                    showAddOfflineDialog = false
                                    skinReloadTick++
                                    statusBanner = "Active account set to ${acc.name}."
                                }.onFailure { err ->
                                    offlineErr = err.message
                                }
                            },
                        ) {
                            Text("Create")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAddOfflineDialog = false }) { Text("Cancel") }
                    },
                )
            }

            if (showRenameDialog && activeAccount != null) {
                var newName by remember { mutableStateOf(activeAccount.name) }
                var renameErr by remember { mutableStateOf<String?>(null) }
                AlertDialog(
                    onDismissRequest = { showRenameDialog = false },
                    title = {
                        Text(
                            text = if (activeAccount.userType == "msa") "Change Microsoft IGN" else "Rename Offline Account",
                            fontWeight = FontWeight.Bold,
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newName,
                                onValueChange = {
                                    newName = it
                                    renameErr = null
                                },
                                label = { Text("New Username") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            if (activeAccount.userType == "msa") {
                                Text(
                                    text = "Mojang enforces a 30-day cooldown between Microsoft username changes.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            if (renameErr != null) {
                                Text(renameErr.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                scope.launch {
                                    if (activeAccount.userType == "msa") {
                                        busyMessage = "Updating Mojang profile name..."
                                        MicrosoftAuthClient.changeProfileName(activeAccount.accessToken, newName)
                                            .onSuccess {
                                                engine.renameAccount(activeAccount.uuid, newName)
                                                accountsState = engine.loadAccounts()
                                                showRenameDialog = false
                                                statusBanner = "Username changed to ${newName.trim()}."
                                            }
                                            .onFailure { renameErr = it.message }
                                        busyMessage = null
                                    } else {
                                        engine.renameAccount(activeAccount.uuid, newName)
                                            .onSuccess {
                                                accountsState = engine.loadAccounts()
                                                showRenameDialog = false
                                                statusBanner = "Renamed to ${newName.trim()}."
                                            }
                                            .onFailure { renameErr = it.message }
                                    }
                                }
                            },
                        ) {
                            Text("Save")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") }
                    },
                )
            }

            if (showMsaInfoDialog && activeAccount != null) {
                AlertDialog(
                    onDismissRequest = { showMsaInfoDialog = false },
                    icon = { Icon(Icons.Rounded.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    title = { Text("Microsoft Account Info", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text("Username: ${activeAccount.name}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("UUID: ${activeAccount.dashedUuid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (activeAccount.xuid.isNotBlank()) {
                                Text("Xbox XUID: ${activeAccount.xuid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("Skin Model: ${activeAccount.skinModel}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Owned Capes: ${capes.size}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showMsaInfoDialog = false
                                scope.launch {
                                    busyMessage = "Refreshing Microsoft profile..."
                                    MicrosoftAuthClient.fetchProfile(activeAccount.accessToken, activeAccount.refreshToken, activeAccount.xuid)
                                        .onSuccess { fresh ->
                                            engine.saveMicrosoftAccount(fresh)
                                            accountsState = engine.loadAccounts()
                                            skinReloadTick++
                                            statusBanner = "Refreshed skin & capes for ${fresh.name}."
                                        }
                                        .onFailure { statusBanner = it.message ?: "Refresh failed." }
                                    busyMessage = null
                                }
                            },
                        ) {
                            Text("Refresh Skin")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showMsaInfoDialog = false }) { Text("Close") }
                    },
                )
            }

            if (showMsaDialog) {
                MicrosoftDeviceLoginDialog(
                    onDismiss = { showMsaDialog = false },
                    onSignedIn = { profile ->
                        engine.saveMicrosoftAccount(profile)
                        accountsState = engine.loadAccounts()
                        skinReloadTick++
                        showMsaDialog = false
                        statusBanner = "Signed in as ${profile.name} (Microsoft)."
                    },
                )
            }
        }
    }
}

@Composable
private fun MicrosoftDeviceLoginDialog(
    onDismiss: () -> Unit,
    onSignedIn: (com.logosforgestudios.diamond.auth.MinecraftProfileResult) -> Unit,
) {
    val context = LocalContext.current
    var deviceResp by remember { mutableStateOf<DeviceCodeResponse?>(null) }
    var stageText by remember { mutableStateOf("Requesting Microsoft device code...") }
    var errorText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val codeRes = MicrosoftAuthClient.requestDeviceCode()
        codeRes.onFailure { err ->
            errorText = err.message ?: "Failed to contact Microsoft login servers."
            return@LaunchedEffect
        }
        val dc = codeRes.getOrThrow()
        deviceResp = dc
        stageText = "Waiting for sign-in confirmation..."
        val deadline = System.currentTimeMillis() + dc.expiresInSeconds * 1000L
        while (System.currentTimeMillis() < deadline) {
            delay(dc.intervalSeconds * 1000L)
            when (val poll = MicrosoftAuthClient.pollDeviceCodeToken(dc.deviceCode)) {
                is DevicePollResult.Pending -> continue
                is DevicePollResult.Error -> {
                    errorText = poll.message
                    return@LaunchedEffect
                }
                is DevicePollResult.Success -> {
                    stageText = "Authenticating Xbox Live & Minecraft profile..."
                    val prof = MicrosoftAuthClient.completeMinecraftLogin(poll.accessToken, poll.refreshToken)
                    prof.onSuccess { result ->
                        onSignedIn(result)
                    }.onFailure { err ->
                        errorText = err.message ?: "Xbox/Minecraft login failed."
                    }
                    return@LaunchedEffect
                }
            }
        }
        errorText = "Code expired. Close and try again."
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("Sign in with Microsoft", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                val dc = deviceResp
                if (errorText != null) {
                    Text(
                        text = errorText.orEmpty(),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else if (dc == null) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                    Text(stageText, style = MaterialTheme.typography.bodySmall)
                } else {
                    Text(
                        text = "Enter this code on Microsoft's sign-in page:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = dc.userCode,
                            modifier = Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 4.sp,
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                    Button(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cm?.setPrimaryClip(ClipData.newPlainText("Microsoft Code", dc.userCode))
                            runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(dc.verificationUri)))
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Text("Copy Code & Open microsoft.com/link", fontWeight = FontWeight.Bold)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text(stageText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun InteractivePlayerModelCard(
    modifier: Modifier,
    skinBitmap: Bitmap?,
    capeBitmap: Bitmap?,
    isSlim: Boolean,
    accountName: String,
    isMicrosoft: Boolean,
) {
    var yawDeg by remember { mutableFloatStateOf(-24f) }
    var pitchDeg by remember { mutableFloatStateOf(10f) }
    var walkAnim by remember { mutableStateOf(true) }
    var animPhase by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(walkAnim) {
        while (walkAnim) {
            delay(16L)
            animPhase = (animPhase + 0.055f) % 62.83185f
        }
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
                            MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                    ),
                )
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        yawDeg = (yawDeg + dragAmount.x * 0.55f) % 360f
                        pitchDeg = (pitchDeg - dragAmount.y * 0.35f).coerceIn(-45f, 45f)
                    }
                },
        ) {
            val bmp = skinBitmap
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (bmp == null) return@Canvas
                val cx = size.width * 0.5f
                val cy = size.height * 0.45f
                val scale = (minOf(size.width, size.height) / 42f).coerceIn(3.5f, 12f)
                val swing = if (walkAnim) sin(animPhase) * 0.42f else 0f
                val armW = if (isSlim) 3f else 4f
                val yaw = Math.toRadians(yawDeg.toDouble()).toFloat()
                val pitch = Math.toRadians(pitchDeg.toDouble()).toFloat()

                val faces = mutableListOf<ProjectedFace>()

                fun addBox(
                    ox: Float,
                    oy: Float,
                    oz: Float,
                    w: Float,
                    h: Float,
                    d: Float,
                    rotX: Float,
                    pivotY: Float,
                    uvs: BoxUvs,
                    tex: Bitmap,
                    doubleSided: Boolean = false,
                ) {
                    val hw = w * 0.5f
                    val hh = h * 0.5f
                    val hd = d * 0.5f
                    val localVerts = arrayOf(
                        floatArrayOf(-hw, -hh, hd),
                        floatArrayOf(hw, -hh, hd),
                        floatArrayOf(hw, hh, hd),
                        floatArrayOf(-hw, hh, hd),
                        floatArrayOf(-hw, -hh, -hd),
                        floatArrayOf(hw, -hh, -hd),
                        floatArrayOf(hw, hh, -hd),
                        floatArrayOf(-hw, hh, -hd),
                    )
                    val crx = cos(rotX)
                    val srx = sin(rotX)
                    val cyaw = cos(yaw)
                    val syaw = sin(yaw)
                    val cp = cos(pitch)
                    val sp = sin(pitch)

                    val pts = Array(8) { idx ->
                        val lx = localVerts[idx][0]
                        val ly = localVerts[idx][1] - pivotY
                        val lz = localVerts[idx][2]
                        val rxY = ly * crx - lz * srx + pivotY
                        val rxZ = ly * srx + lz * crx
                        val wx = lx + ox
                        val wy = rxY + oy
                        val wz = rxZ + oz
                        val yx = wx * cyaw + wz * syaw
                        val yz = -wx * syaw + wz * cyaw
                        val py = wy * cp - yz * sp
                        val pz = wy * sp + yz * cp
                        val persp = 140f / (140f - pz)
                        floatArrayOf(cx + yx * scale * persp, cy + py * scale * persp, pz)
                    }

                    val quads = arrayOf(
                        Pair(intArrayOf(0, 1, 2, 3), uvs.front),
                        Pair(intArrayOf(5, 4, 7, 6), uvs.back),
                        Pair(intArrayOf(4, 0, 3, 7), uvs.left),
                        Pair(intArrayOf(1, 5, 6, 2), uvs.right),
                        Pair(intArrayOf(4, 5, 1, 0), uvs.top),
                        Pair(intArrayOf(3, 2, 6, 7), uvs.bottom),
                    )
                    for ((q, uv) in quads) {
                        val p0 = pts[q[0]]
                        val p1 = pts[q[1]]
                        val p2 = pts[q[2]]
                        val p3 = pts[q[3]]
                        val cross = (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p1[1] - p0[1]) * (p2[0] - p0[0])
                        if (!doubleSided && cross <= 0f) continue
                        val avgZ = (p0[2] + p1[2] + p2[2] + p3[2]) * 0.25f
                        faces.add(
                            ProjectedFace(
                                z = avgZ,
                                dst = floatArrayOf(p0[0], p0[1], p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]),
                                srcRect = uv,
                                bitmap = tex,
                            ),
                        )
                    }
                }

                val is64 = bmp.height >= 64
                addBox(
                    0f, -12f, 0f, 8f, 8f, 8f, 0f, 0f,
                    BoxUvs(
                        front = Rect(8, 8, 16, 16),
                        back = Rect(24, 8, 32, 16),
                        left = Rect(0, 8, 8, 16),
                        right = Rect(16, 8, 24, 16),
                        top = Rect(8, 0, 16, 8),
                        bottom = Rect(16, 0, 24, 8),
                    ),
                    bmp,
                )
                addBox(
                    0f, -2f, 0f, 8f, 12f, 4f, 0f, 0f,
                    BoxUvs(
                        front = Rect(20, 20, 28, 32),
                        back = Rect(32, 20, 40, 32),
                        left = Rect(16, 20, 20, 32),
                        right = Rect(28, 20, 32, 32),
                        top = Rect(20, 16, 28, 20),
                        bottom = Rect(28, 16, 36, 20),
                    ),
                    bmp,
                )
                addBox(
                    -(4f + armW * 0.5f), -2f, 0f, armW, 12f, 4f, swing, -5f,
                    BoxUvs(
                        front = Rect(44, 20, 44 + armW.toInt(), 32),
                        back = Rect(48 + armW.toInt(), 20, 48 + armW.toInt() * 2, 32),
                        left = Rect(40, 20, 44, 32),
                        right = Rect(44 + armW.toInt(), 20, 48 + armW.toInt(), 32),
                        top = Rect(44, 16, 44 + armW.toInt(), 20),
                        bottom = Rect(44 + armW.toInt(), 16, 44 + armW.toInt() * 2, 20),
                    ),
                    bmp,
                )
                addBox(
                    4f + armW * 0.5f, -2f, 0f, armW, 12f, 4f, -swing, -5f,
                    if (is64) {
                        BoxUvs(
                            front = Rect(36, 52, 36 + armW.toInt(), 64),
                            back = Rect(40 + armW.toInt(), 52, 40 + armW.toInt() * 2, 64),
                            left = Rect(32, 52, 36, 64),
                            right = Rect(36 + armW.toInt(), 52, 40 + armW.toInt(), 64),
                            top = Rect(36, 48, 36 + armW.toInt(), 52),
                            bottom = Rect(36 + armW.toInt(), 48, 36 + armW.toInt() * 2, 52),
                        )
                    } else {
                        BoxUvs(
                            front = Rect(44, 20, 48, 32),
                            back = Rect(52, 20, 56, 32),
                            left = Rect(40, 20, 44, 32),
                            right = Rect(48, 20, 52, 32),
                            top = Rect(44, 16, 48, 20),
                            bottom = Rect(48, 16, 52, 20),
                        )
                    },
                    bmp,
                )
                addBox(
                    -2f, 10f, 0f, 4f, 12f, 4f, -swing * 0.85f, -6f,
                    BoxUvs(
                        front = Rect(4, 20, 8, 32),
                        back = Rect(12, 20, 16, 32),
                        left = Rect(0, 20, 4, 32),
                        right = Rect(8, 20, 12, 32),
                        top = Rect(4, 16, 8, 20),
                        bottom = Rect(8, 16, 12, 20),
                    ),
                    bmp,
                )
                addBox(
                    2f, 10f, 0f, 4f, 12f, 4f, swing * 0.85f, -6f,
                    if (is64) {
                        BoxUvs(
                            front = Rect(20, 52, 24, 64),
                            back = Rect(28, 52, 32, 64),
                            left = Rect(16, 52, 20, 64),
                            right = Rect(24, 52, 28, 64),
                            top = Rect(20, 48, 24, 52),
                            bottom = Rect(24, 48, 28, 52),
                        )
                    } else {
                        BoxUvs(
                            front = Rect(4, 20, 8, 32),
                            back = Rect(12, 20, 16, 32),
                            left = Rect(0, 20, 4, 32),
                            right = Rect(8, 20, 12, 32),
                            top = Rect(4, 16, 8, 20),
                            bottom = Rect(8, 16, 12, 20),
                        )
                    },
                    bmp,
                )

                if (is64) {
                    addBox(
                        0f, -12f, 0f, 8.6f, 8.6f, 8.6f, 0f, 0f,
                        BoxUvs(
                            front = Rect(40, 8, 48, 16),
                            back = Rect(56, 8, 64, 16),
                            left = Rect(32, 8, 40, 16),
                            right = Rect(48, 8, 56, 16),
                            top = Rect(40, 0, 48, 8),
                            bottom = Rect(48, 0, 56, 8),
                        ),
                        bmp,
                    )
                    addBox(
                        0f, -2f, 0f, 8.5f, 12.5f, 4.5f, 0f, 0f,
                        BoxUvs(
                            front = Rect(20, 36, 28, 48),
                            back = Rect(32, 36, 40, 48),
                            left = Rect(16, 36, 20, 48),
                            right = Rect(28, 36, 32, 48),
                            top = Rect(20, 32, 28, 36),
                            bottom = Rect(28, 32, 36, 36),
                        ),
                        bmp,
                    )
                    addBox(
                        -(4f + armW * 0.5f), -2f, 0f, armW + 0.45f, 12.45f, 4.45f, swing, -5f,
                        BoxUvs(
                            front = Rect(44, 36, 44 + armW.toInt(), 48),
                            back = Rect(48 + armW.toInt(), 36, 48 + armW.toInt() * 2, 48),
                            left = Rect(40, 36, 44, 48),
                            right = Rect(44 + armW.toInt(), 36, 48 + armW.toInt(), 48),
                            top = Rect(44, 32, 44 + armW.toInt(), 36),
                            bottom = Rect(44 + armW.toInt(), 32, 44 + armW.toInt() * 2, 36),
                        ),
                        bmp,
                    )
                    addBox(
                        4f + armW * 0.5f, -2f, 0f, armW + 0.45f, 12.45f, 4.45f, -swing, -5f,
                        BoxUvs(
                            front = Rect(52, 52, 52 + armW.toInt(), 64),
                            back = Rect(56 + armW.toInt(), 52, 56 + armW.toInt() * 2, 64),
                            left = Rect(48, 52, 52, 64),
                            right = Rect(52 + armW.toInt(), 52, 56 + armW.toInt(), 64),
                            top = Rect(52, 48, 52 + armW.toInt(), 52),
                            bottom = Rect(52 + armW.toInt(), 48, 52 + armW.toInt() * 2, 52),
                        ),
                        bmp,
                    )
                    addBox(
                        -2f, 10f, 0f, 4.45f, 12.45f, 4.45f, -swing * 0.85f, -6f,
                        BoxUvs(
                            front = Rect(4, 36, 8, 48),
                            back = Rect(12, 36, 16, 48),
                            left = Rect(0, 36, 4, 48),
                            right = Rect(8, 36, 12, 48),
                            top = Rect(4, 32, 8, 36),
                            bottom = Rect(8, 32, 12, 36),
                        ),
                        bmp,
                    )
                    addBox(
                        2f, 10f, 0f, 4.45f, 12.45f, 4.45f, swing * 0.85f, -6f,
                        BoxUvs(
                            front = Rect(4, 52, 8, 64),
                            back = Rect(12, 52, 16, 64),
                            left = Rect(0, 52, 4, 64),
                            right = Rect(8, 52, 12, 64),
                            top = Rect(4, 48, 8, 52),
                            bottom = Rect(8, 48, 12, 52),
                        ),
                        bmp,
                    )
                }

                if (capeBitmap != null) {
                    val cw = capeBitmap.width
                    val ch = capeBitmap.height
                    val sx = (cw / 64f).coerceAtLeast(1f)
                    val sy = (ch / 32f).coerceAtLeast(1f)
                    fun cr(l: Int, t: Int, r: Int, b: Int) = Rect(
                        (l * sx).toInt().coerceIn(0, cw),
                        (t * sy).toInt().coerceIn(0, ch),
                        (r * sx).toInt().coerceIn(0, cw),
                        (b * sy).toInt().coerceIn(0, ch),
                    )
                    addBox(
                        0f, 0f, -2.8f, 10f, 16f, 0.9f, -0.18f - kotlin.math.abs(swing) * 0.24f, -8f,
                        BoxUvs(
                            front = cr(12, 1, 22, 17),
                            back = cr(1, 1, 11, 17),
                            left = cr(0, 1, 1, 17),
                            right = cr(11, 1, 12, 17),
                            top = cr(1, 0, 11, 1),
                            bottom = cr(11, 0, 21, 1),
                        ),
                        capeBitmap,
                        doubleSided = true,
                    )
                }

                faces.sortBy { it.z }
                val paint = Paint().apply { isFilterBitmap = false }
                val mat = Matrix()
                drawIntoCanvas { canvas ->
                    val nc = canvas.nativeCanvas
                    for (f in faces) {
                        val r = f.srcRect
                        val w = (r.right - r.left).coerceAtLeast(1)
                        val h = (r.bottom - r.top).coerceAtLeast(1)
                        if (r.left < 0 || r.top < 0 || r.right > f.bitmap.width || r.bottom > f.bitmap.height) continue
                        val patch = Bitmap.createBitmap(f.bitmap, r.left, r.top, w, h)
                        val srcPts = floatArrayOf(0f, 0f, w.toFloat(), 0f, w.toFloat(), h.toFloat(), 0f, h.toFloat())
                        mat.reset()
                        if (mat.setPolyToPoly(srcPts, 0, f.dst, 0, 4)) {
                            nc.drawBitmap(patch, mat, paint)
                        }
                        patch.recycle()
                    }
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                ) {
                    Text(
                        text = if (isMicrosoft) "$accountName • MSA" else "$accountName • Drag 360°",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = walkAnim,
                    onClick = { walkAnim = !walkAnim },
                    label = { Text(if (walkAnim) "Walking" else "Idle") },
                )
                FilterChip(
                    selected = false,
                    onClick = { yawDeg = (yawDeg + 180f) % 360f },
                    label = { Text("Flip") },
                )
                FilterChip(
                    selected = false,
                    onClick = {
                        yawDeg = -24f
                        pitchDeg = 10f
                    },
                    label = { Text("Reset") },
                )
            }
        }
    }
}

private data class BoxUvs(
    val front: Rect,
    val back: Rect,
    val left: Rect,
    val right: Rect,
    val top: Rect,
    val bottom: Rect,
)

private data class ProjectedFace(
    val z: Float,
    val dst: FloatArray,
    val srcRect: Rect,
    val bitmap: Bitmap,
)

private fun createDefaultSteveBitmap(): Bitmap {
    val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = Paint()
    fun fill(x: Int, y: Int, w: Int, h: Int, color: Int) {
        p.color = color
        c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), p)
    }
    fill(0, 0, 64, 64, android.graphics.Color.rgb(189, 145, 108))
    fill(0, 0, 32, 8, android.graphics.Color.rgb(66, 44, 28))
    fill(0, 8, 8, 3, android.graphics.Color.rgb(66, 44, 28))
    fill(16, 8, 16, 3, android.graphics.Color.rgb(66, 44, 28))
    fill(8, 8, 8, 2, android.graphics.Color.rgb(66, 44, 28))
    fill(9, 11, 2, 1, android.graphics.Color.WHITE)
    fill(10, 11, 1, 1, android.graphics.Color.rgb(68, 56, 160))
    fill(13, 11, 2, 1, android.graphics.Color.WHITE)
    fill(13, 11, 1, 1, android.graphics.Color.rgb(68, 56, 160))
    fill(11, 13, 2, 1, android.graphics.Color.rgb(138, 92, 66))
    fill(16, 16, 24, 16, android.graphics.Color.rgb(0, 168, 176))
    fill(40, 16, 16, 6, android.graphics.Color.rgb(0, 168, 176))
    fill(32, 48, 16, 6, android.graphics.Color.rgb(0, 168, 176))
    fill(0, 16, 16, 16, android.graphics.Color.rgb(54, 64, 152))
    fill(16, 48, 16, 16, android.graphics.Color.rgb(54, 64, 152))
    fill(0, 29, 16, 3, android.graphics.Color.rgb(92, 92, 96))
    fill(16, 61, 16, 3, android.graphics.Color.rgb(92, 92, 96))
    return bmp
}
